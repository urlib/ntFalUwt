﻿
function PageInit(){
	  get_CCCXInfo()
}
//请求产品信息
function get_CCCXInfo(){
	setIX({"funcid":"L2620200","funcname":'ret_CCCXInfo',"CUST_CODE":User.khh,"CUACCT_CODE":'',"TA_ACCT":'',"ISS_CODE":'',"INST_ID":'',"PAGE_RECNUM":'0',"PAGE_RECCNT":'500'})
}
//应答产品信息
function ret_CCCXInfo(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
		{
			proInfo("您还未开设理财帐户，请先开户");
		}
		else
		{
			proError(data.ErrorInfo)	
		}
		//$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]		
	 	create_easygrid("份额查询",{},{})
	 	upDate("load",data)
	}
}

function createCCCXinfo(){
	var mygrid=$("<div id='load'></div>").appendTo($("#tdx_center"));
	mygrid.datagrid({
		singleSelect:true,
		fitColumns:true,
		width:840,
		scrollbarSize:0,
		loadMsg:'',
		border:false,
		remoteSort: false,

		columns:[[
			{field:'INST_CODE',title:'产品代码',halign:'center',align:'right',width:120},
			{field:'INST_SNAME',title:'产品名称',halign:'center',align:'right',width:120},
			{field:'CUST_CODE',title:'OTC账号',halign:'center',align:'right',width:120},
			{field:'INST_BLN',title:'库存份额',h_Calign:'center',align:'right',width:120},
			{field:'INST_AVL',title:'可用份额',halign:'center',align:'right',width:120},
			{field:'MKT_VAL',title:'最新市值',halign:'center',align:'right',width:120},
			{field:'NET_VAL',title:'盈利',halign:'center',align:'right',width:120}	
		]]  	   	
	});	
}

