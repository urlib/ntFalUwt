

var glob={
	"stbm":[],// 试题编码
	"stbh":[],// 试题编号
	"xxbm":[],// 选项编码
	"xxnr":[],// 选项内容
	"stnr":[],// 试题内容	
	"xxlx":[]// 选项类型
};
var glob3={
	"tsjgdm":[],// 发行机构
	"jgjc":[],	// 发行机构简称
	"jgqc":[],	//发行机构名称	
	"stlx":[],	// 问卷编码
	"jglb":[],	// 产品机构类别
	"flage":[]	// 标志
};
var count=0;
var totalnum=0;
var tmzs=0;
var nextNum=0;
var globIndex = 0;
var stbhArray = {};
var glob2={
	"ansstbm":[], // 实体编码-答案
	"ansth":[],	  // 题号-答案
	"ansxxbm":[],	// 选项编码-答案
	"anszdzt":[]	// 作答状态 
}
 var zczh="";	// 资产账户
 var djjg="";	// 登记机构
 var djzh="";	// 登记账号
 var jyzh="";	// 交易账号
 var khtzsx=""; // 客户拓展属性
 var accStat="";// 账户状态
 var tmlb="";	// 题目类别
 var jgbz="";	// 机构标志
 var jgdm="";	// 机构代码
 var flag="";	// 标志
 var num=0;		// 用以区分是选择的第几项
 var totalNum1=0;
 var jlts=0;		// 记录条数
 var zjlb="";	// 证件类别
 var zjhm="";	// 证件号码
 var khxm="";	// 客户姓名
 var wjhm="";	// 问卷号码


function search(data,key)
{
	for(var i = 0 ; i < data.length;i++)
	{
		if(data[i] == key)
		{
			return true;
		}
	}
	return false;
}

function PageInit(){
	var obj2 = document.getElementById("btnNext");
		obj2.style.display = "none";
	// get_KhdzydsInfo()
	//get_khxx()
	get_Djjg()
}


//获取登记机构
function get_Djjg(){
	setIX({"funcid":"502048","funcname":'ret_Djjg',"FID_TADM":""})
	/*setIX({"funcid":"99001350","funcname":'ret_Djjg',"INT_ORG":"","SPEC_ORG_CODE":"","SPEC_ORG_TYPE":"1"})*/
}

function ret_Djjg(_fromid,_funid,_flagtype,data){
	//alert(data)
	/*if(_funid=="5010:SIMPLE.99001350"){*/
	if(_funid=="5010:SIMPLE.502048"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			//proError(data.ErrorInfo)
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到机构")
				return
			}
			else{

				for(var i=0; i<data.rows.length; i++)
				{
					if(data.rows[i].SURVEY_SN==0)continue;

					var Fxjg = data.rows[i].FID_TADM;
					
				//	if (Fxjg.indexOf("ZZ") == -1 )continue;
					
					
					
					glob3.tsjgdm[totalNum1]=data.rows[i].FID_TADM;//发行机构
					glob3.jgjc[totalNum1]=data.rows[i].FID_JGJC;// 发行机构简称
					glob3.jgqc[totalNum1]=data.rows[i].FID_JGMC;// 发行机构名称					
					glob3.stlx[totalNum1]=data.rows[i].FID_WJBM;	// 问卷编码
					glob3.jglb[totalNum1]=data.rows[i].FID_JGLB;	// 产品机构类别
					glob3.flage[totalNum1]=data.rows[i].FID_FLAG;	// 标志

					
					totalNum1++;

				}
					
			}
		}
				
	}


	var obj2=document.getElementById('cpjg');
	var jsonObj2=[];
	for(var k=0; k<totalNum1; k++)
	{
		var str=glob3.tsjgdm[k]+""+glob3.jgjc[k];
		jsonObj2[k]={id:k,value:str};		
		
	}
	for(var e=0; e<jsonObj2.length; e++)
	{
		obj2.add(new Option(jsonObj2[e].value,jsonObj2[e].id))
	}

}


function onStart(c)
{

	var obj = document.getElementById("lab1");
	var obj1 = document.getElementById("cpjg");
	var obj3 = document.getElementById("btnStart");

	obj.style.display = "none";
	obj1.style.display = "none";
	obj3.style.display = "none";

	var obj2 = document.getElementById("btnNext");
		obj2.style.display = "block";



	for(var i=0; i<obj1.options.length; i++ )
	{
		if(obj1.options[i].selected)
		{
			
			tmlb=glob3.stlx[i];		
			jgbz=glob3.jglb[i];		
			jgdm=glob3.tsjgdm[i];	
			flag=glob3.flage[i];
		
			break;
		}
	}


	//get_khxx()
	//get_KhdzydsInfo()
	//get_Wjbm()

	get_jgbz()
	
}



// 获取机构标志
function get_jgbz(){
	setIX({"funcid":"302001","funcname":'ret_jgbz',"FID_KHH":User.khh,"FID_EXFLG":"1"})
}

function ret_jgbz(_fromid,_funid,_flagtype,data){

	if (_funid=="5010:SIMPLE.302001") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			proError(data.ErrorInfo);
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到获取机构标志");
				return;
			}else{	
				
				jgbz=data.rows[0].FID_JGBZ;
				
				
			}
		}
	}
	
	get_Wjbm()
}





// 获取问卷编码
function get_Wjbm(){
	

	setIX({"funcid":"502750","funcname":'ret_Wjbm',"FID_WJBM":"","FID_JGBZ":jgbz,"FID_JGDM":jgdm})
}

function ret_Wjbm(_fromid,_funid,_flagtype,data){
	if (_funid=="5010:SIMPLE.502750") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			proError(data.ErrorInfo);
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到该机构的问卷编码");
				return;
			}else{				
				
				tmlb=data.rows[0].FID_WJBM;				
			}
		}
	}
	
	get_khxx()
	
}








// 获取客户信息
function get_khxx(){
	setIX({"funcid":"502012","funcname":'ret_Khxx',"FID_KHH":User.khh})
}

function ret_Khxx(_fromid,_funid,_flagtype,data){
	if (_funid=="5010:SIMPLE.502012") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			proError(data.ErrorInfo);
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到客户基本资料");
				return;
			}else{	
				zjlb=data.rows[0].FID_ZJLB
				zjhm=data.rows[0].FID_ZJBH
				khxm=data.rows[0].FID_KHXM
				
			}
		}
	}

	
	get_KhdzydsInfo()
}

// 查询风险测评问券	
function get_KhdzydsInfo(){
	/*setIX({"funcid":"99001100","funcname":'ret_KhdzydsInfo',"SURVEY_CLS":"7","SURVEY_SN":tmlb})*/
	/*setIX({"funcid":"502750","funcname":'ret_KhdzydsInfo',"FID_WJBM":tmlb,"FID_JGBZ":jgbz,"FID_JGDM":jgdm})*/

	
	setIX({"funcid":"502751","funcname":'ret_KhdzydsInfo',"FID_WJBM":tmlb,"FID_JGBZ":jgbz,"FID_JGDM":jgdm,"FID_FLAG":flag})
}

function ret_KhdzydsInfo(_fromid,_funid,_flagtype,data){

	
	/*if(_funid=="5010:SIMPLE.99001100"){*/
		if(_funid=="5010:SIMPLE.502751"){	
			
		data=FormatResult(data,1)		
		
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
		 	return;
		}
		else
		{			
			if(data.rows==undefined) data.rows=[];
			var j=0;
			for(var i=0;i<data.rows.length;i++)
			{
				
				var info=(data.rows[i].FID_TMDA).split(";")

			
				for(var k=0; k<info.length; k++)
				{
					var tmpValue=info[k]
					
					var infoXxbm=tmpValue.split("|");
				

					glob.stbm[j]=data.rows[i].FID_WJBM;// 试题编码
					glob.stbh[j]=data.rows[i].FID_TMHM;// 试题编号

					glob.xxbm[j]=infoXxbm[0];// 选项编码
					glob.xxnr[j]=infoXxbm[1];// 选项内容

					glob.stnr[j]=data.rows[i].FID_TMMS;// 试题内容
					glob.xxlx[j]=data.rows[i].FID_TMLX;// 选项类型

					wjhm=data.rows[i].FID_WJHM;// 问卷号码


				
					j++;

				}


				/*glob.stbm[i]=data.rows[i].FID_WJBM;// 试题编码
				glob.stbh[i]=data.rows[i].FID_TMHM;// 试题编号
				glob.xxbm[i]=data.rows[i].FID_TMHM;// 选项编码
				glob.xxnr[i]=data.rows[i].FID_TMDA;// 选项内容
				glob.stnr[i]=data.rows[i].FID_TMMS;// 试题内容
				glob.xxlx[i]=data.rows[i].FID_TMLX;// 选项类型*/
				
			}
			totalnum=data.rows.length-1;
			tmzs=data.rows.length;
			
		}
		onNext()

		}
}

function onNext(t)
{
	nextNum++;	

	if(nextNum  <= tmzs)
	{
		var radioObj = document.getElementById('group1');
		radioObj.checked = true;
		for(var i = 1; i <= 6; i++)
		{
			var obj = document.getElementById("group"+i+"_radio");
			obj.style.display = "none";
		}
	
		var radioList = document.getElementsByTagName('input');
		

		var i=4;
		$("#tital").text(glob.stbh[globIndex]+"、"+glob.stnr[globIndex])

		
		glob2.ansth[nextNum-1] = glob.stbh[globIndex]	
		

		
	
		var i = 1;
		
		while(glob.stbh[globIndex] == glob.stbh[globIndex + 1])
		{


			$("#label"+i).text(glob.xxnr[globIndex++]);
			var obj = document.getElementById("group"+i+"_radio");
			obj.style.display = "block";
			i++;




		}
		$("#label"+i).text(glob.xxnr[globIndex++]);
		var obj = document.getElementById("group"+i+"_radio");
		obj.style.display = "block";
	}

	glob2.ansxxbm[nextNum-1] = glob.xxbm[globIndex];


/*	glob2.ansstbm[nextNum-1] =  glob.stbm[globIndex];
	glob2.ansth[nextNum-1] = glob.stbh[globIndex]-1;
	glob2.ansxxbm[nextNum-1] = glob.xxbm[globIndex];*/

	
	
	if ((nextNum-1)==0 )
	{
		glob2.anszdzt[nextNum-1]=0
	}
	else if(nextNum == tmzs)
	{
		glob2.ansstbm[nextNum-1] =  glob.stbm[totalnum];

		

		//glob2.ansth[nextNum-1] = glob.stbh[totalnum];
		glob2.ansxxbm[nextNum-1] = 1;

		glob2.anszdzt[nextNum-1]=2
	}
	else
	{
		glob2.anszdzt[nextNum-1]=1
	}


	if(nextNum == tmzs)	
	{
		var obj3 = document.getElementById("btnNext");
		obj3.style.display = "none";

		var obj2 = document.getElementById("btnTj");
		obj2.style.display = "block";

		/*$("#btnNext").text("提交1");
		for(var j=0; j<(tmzs); j++ )
		{
			onTj(j);	
		}

		oncpjgcx();*/
		
	}


	
}

function onRadio(n)
{	
	if (n==1) 
	{
		glob2.ansxxbm[nextNum-1]="A"

	}
	else if (n==2) 
	{
		glob2.ansxxbm[nextNum-1]="B"
	
	}
	else if (n==3) 
	{
		glob2.ansxxbm[nextNum-1]="C"
		
	}
	else if (n==4) 
	{
		glob2.ansxxbm[nextNum-1]="D"
	
	}
	else if (n==5) 
	{
		glob2.ansxxbm[nextNum-1]="E"
		
	}
	else if (n==6) 
	{
		glob2.ansxxbm[nextNum-1]="F"
	
	}
	
}


function onTjcpjg()
{
	var EndAns="";
	for(var j=0; j<(tmzs); j++ )
	{
		if (glob2.ansxxbm[j]=="1")
		{
			glob2.ansxxbm[j]="A";
		}
		else if (glob2.ansxxbm[j]=="2")
		{
			glob2.ansxxbm[j]="B";
		}
		else if (glob2.ansxxbm[j]=="3")
		{
			glob2.ansxxbm[j]="C";
		}
		else if (glob2.ansxxbm[j]=="4")
		{
			glob2.ansxxbm[j]="D";
		}
		else if (glob2.ansxxbm[j]=="5")
		{
			glob2.ansxxbm[j]="E";
		}
		else if (glob2.ansxxbm[j]=="6")
		{
			glob2.ansxxbm[j]="F";
		}


		var tmpAns="";
		
		tmpAns=glob2.ansth[j]+"|"+glob2.ansxxbm[j]+";";	
		
		
		
		

			if (j==0)
			{
				EndAns=tmpAns;
			}
			else
			{
				EndAns=EndAns+tmpAns;
			}

				


	}
	
	//alert(EndAns)
	onTj(EndAns)

	/*for(var j=0; j<(tmzs); j++ )
	{
		onTj(j);	
	}

		oncpjgcx();*/
}


function onTj(j)
{	
	setIX({"funcid":"502701","funcname":"ret_tj","FID_KHH":User.khh,"FID_WJHM":wjhm,"FID_ZJLB":zjlb,"FID_ZJBH":zjhm,"FID_KHXM":khxm,"FID_TMDA":j})
}


function ret_tj(_fromid,_funid,_flagtype,data){	

	
	if(_funid=="5010:SIMPLE.502701"){
		data=FormatResult(data,1)
		
		if(data.ErrorCode!="0"){
			
			proError(data.ErrorInfo)
			return
		}else{
			//proInfo("您的测评结果已提交")
			proInfo("您的测评得分为"+data.rows[0].FID_SCORE+'\r\n'+"您的风险承受能力"+data.rows[0].FID_TZZFL);
			return;
		}
	}
}


function oncpjgcx()
{
	setIX({"funcid":"99001120","funcname":'ret_cpjgcx',"SURVEY_SN":glob2.ansstbm[0],"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
}


function ret_cpjgcx(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001120"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{

			proInfo("您的测评得分为"+data.rows[0].SURVEY_SCORE+'\r\n'+"您的风险级别为"+data.rows[0].RATING_LVL+data.rows[0].RATING_LVL_NAME)


			if(khtzsx.indexOf("2")==-1)
			{	
				
			}
			else
			{		
		
				get_khzlTbOtc();
			}
			//get_khzlTbOtc()
			
		}
	}
}


//请求资金信息
function get_khzlTbOtc(){
	setIX({"funcid":"99001341","funcname":'ret_khzlTbOtc',"CUST_CODE":User.khh,"CUACCT_CODES":"","OPERATION_TYPE":"22022"})
}
//应答资金信息
function ret_khzlTbOtc(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
			get_Xh()
	 	
	}
}



function get_Xh(){	
	setIX({"funcid":"99001335","funcname":'ret_Xh',"CUST_CODE":User.khh,"CUACCT_CODE":"","OTC_CODE":"","TRANS_ACCT ":""})

}


function ret_Xh(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.99001335"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){					
			proError(data.ErrorInfo)			
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号信息")
				return
			}
			else{
	
				if (data.rows[0].OTC_CODE=="")
				{

				}
				else
				{					
 					zczh=data.rows[0].CUACCT_CODE;
 					djjg=data.rows[0].OTC_CODE;
 					djzh=data.rows[0].OTC_ACCT;
 					jyzh=data.rows[0].TRANS_ACCT;
 					accStat=data.rows[0].ACCT_STAT;
 					get_djzhwh();
				}										
			}
		}

		
	}
}




function get_djzhwh(){

	setIX({"funcid":"99001334","funcname":'ret_djzhwh',"OPER_TYPE":"1","CUST_CODE":User.khh,"CUACCT_CODE":zczh,"OTC_CODE":djjg,
		"OTC_ACCT":djzh,"TRANS_ACCT":jyzh,"ACCT_STAT":accStat,"OPEN_DATE":"","CLOSE_DATE":""})

}


function ret_djzhwh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001334"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			if(data.rows==undefined) data.rows=[];
			
			proInfo("已成功同步");
			
	
		}
	}
}



