var glob={
	"fxjgmc":[],// 发行机构名称
	"fxjgdm":[],//  发行机构代码
	"cpbz":[],// 测评标志
	"wjbm":[],// 问卷编码
	"cpjglb":[],// 产品机构类别
	"cpqx":[],// 测评期限
	"sybz":[],// 适用币种
	"djkhcp":[]// 多金开户测评
};

var glob2={
	"zjzhbID":[],// 资金账号表的ID
	"ywxtID":[],//  业务系统ID
	"khh":[],// 客户号
	"bz":[],// 币种
	"zjzh":[],// 资金账号
	"zhmc":[],// 账户名称
	"zhzt":[],// 账户状态
	"khrq":[],// 开户日期
	"xhrq":[],// 销户日期
	"zzzzh":[],// 主资金账号
	"yyb":[]// 营业部
};
var CpfxjgNum=0;// 产品发行机构总数
var czlx="";// 操作类型
var fxjg="";// 发行机构
var fxjgdm="";// 发行机构代码
var jszh="";// 结算账户
var selectNum=0;//选择序号
var Wjbm="";// 问卷编码
var djkhce="";// 多金开户测评
var Fxcsnljb="";// 风险承受能力级别
var Fxcprq="";// 风险承受能力日期
var SFxyCp="";// 是否需要调查基金风险承受能力


var totalNum=0;


function PageInit(){
	setDlg("singlewt");	

	get_Jszh();	
};

function openURl()
{
	window.open("http://oa2.avicsec.com/jsp/admin/bb/otcfile/yds.htm")

	/*
	var iHeight=500;
	var iWidth=600;
	var iTop = (window.screen.availHeight-30-iHeight)/2; //获得窗口的垂直位置;
	var iLeft = (window.screen.availWidth-10-iWidth)/2; //获得窗口的水平位置;
	//var str1="http://oa2.avicsec.com/jsp/admin/bb/otcfile/dzqmyds.pdf";
	var str1="http://oa2.avicsec.com/jsp/admin/bb/otcfile/S59876/yds.htm";
	var name1="电子约定书";

	var srcArray = [ str1];
  	var titleArray = [name1];
  	var srcArg = srcArray.join(';');
  	var titleArg = titleArray.join(';');

  	window.open('./Demo.html?srcArg='+srcArg+'&titleArg='+titleArg,'testOpen','height='+iHeight+',width='+iWidth+',menubar=no,status=no,toolbar=no,titlebar=no,location=no,top='+iTop+',left='+iLeft);

*/
}

function setResult(result)
{	
		return;
	
}











//结算账户
/*function get_Khxx(){
	
	setIX({"funcid":"502012","funcname":'ret_Khxx',"FID_KHH":User.khh})
}

function ret_Khxx(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.502012"){
		
		data=FormatResult(data,1)
		
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)			
			return
		}else{
			if(data.rows==undefined) {
				data.rows=[];
			}
			else{		

					
			}
		}
	}

	

}

*/






//结算账户
function get_Jszh(){
	
	setIX({"funcid":"502027","funcname":'ret_Jszh',"FID_KHH":User.khh})
}

function ret_Jszh(_fromid,_funid,_flagtype,data){
	var KhzjzhRecord=0;
	if(_funid=="5010:SIMPLE.502027"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)			
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到结算账户")
				return
			}
			else{

				for(var i=0; i<data.rows.length; i++)
				{	
					var tmpZZhbz=data.rows[i].FID_ZZHBZ	
					if (tmpZZhbz.indexOf("1")==-1) {continue;}

					glob2.zjzhbID[KhzjzhRecord]=data.rows[i].FID_ID;
					glob2.ywxtID[KhzjzhRecord]=data.rows[i].FID_CPID;	
					glob2.khh[KhzjzhRecord]=data.rows[i].FID_KHH;	
					glob2.bz[KhzjzhRecord]=data.rows[i].FID_BZ;	
					glob2.zjzh[KhzjzhRecord]=data.rows[i].FID_ZJZH;	
					glob2.zhmc[KhzjzhRecord]=data.rows[i].FID_ZHMC;	
					glob2.zhzt[KhzjzhRecord]=data.rows[i].FID_ZHZT;	
					glob2.khrq[KhzjzhRecord]=data.rows[i].FID_KHRQ;	
					glob2.xhrq[KhzjzhRecord]=data.rows[i].FID_XHRQ;	
					glob2.zzzzh[KhzjzhRecord]=data.rows[i].FID_ZZHBZ;	
					glob2.yyb[KhzjzhRecord]=data.rows[i].FID_YYB;	
					KhzjzhRecord++;


				}
					
			}
		}

		var obj=document.getElementById('jszh');
		var jsonObj=[];
		for(var k=0; k<KhzjzhRecord; k++)
		{			
			jsonObj[k]={id:k,value:glob2.zjzh[k]};		
		
		}
		for(var e=0; e<jsonObj.length; e++)
		{
			obj.add(new Option(jsonObj[e].value,jsonObj[e].id))
		}
			
	}
	get_Cpfxjg();

}


// 查询CIF产品发行机构
function get_Cpfxjg(){
	setIX({"funcid":"502048","funcname":'ret_Cpfxjg',"FID_TADM":""})
}

function ret_Cpfxjg(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.502048"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)						
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到产品发行机构")
				return
			}
			else{
				

				for(var i=0; i<data.rows.length; i++)
				{	
					var tmpJgdm=data.rows[i].FID_TADM;
					//if (tmpJgdm.indexOf("ZZ")==-1) {continue;}		

					
					
					if (data.rows[i].FID_JGMC==undefined)
					{
						glob.fxjgmc[totalNum]="";
					}
					else
					{
						glob.fxjgmc[totalNum]=data.rows[i].FID_JGMC;	
					}

					
					glob.fxjgdm[totalNum]=data.rows[i].FID_TADM;
					glob.cpbz[totalNum]=data.rows[i].FID_CPBZ;
					glob.wjbm[totalNum]=data.rows[i].FID_WJBM;
					glob.cpjglb[totalNum]=data.rows[i].FID_JGLB;
					glob.cpqx[totalNum]=data.rows[i].FID_QX;
					glob.sybz[totalNum]=data.rows[i].FID_BZ;
					glob.djkhcp[totalNum]=data.rows[i].FID_FLAG;	

					
					totalNum++;			
	
				}
					
			}
		}
				
	}



	var obj=document.getElementById('fxjg');
	var jsonObj=[];
	for(var k=0; k<totalNum; k++)
	{
		var str=glob.fxjgdm[k]+""+glob.fxjgmc[k];
		jsonObj[k]={id:k,value:str};		
		
	}
	for(var e=0; e<jsonObj.length; e++)
	{
		obj.add(new Option(jsonObj[e].value,jsonObj[e].id))
	}

	get_CIFKhfxcsnlInfo()
}







//查询CIF客户风险承受能力
function get_CIFKhfxcsnlInfo(){
	
	setIX({"funcid":"502015","funcname":'ret_CIFKhfxcsnlInfo',"FID_KHH":User.khh})
}


//应答产品信息
function ret_CIFKhfxcsnlInfo(_fromid,_funid,_flagtype,data){	
	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		proError(data.ErrorInfo)						
			return
	}else{
		if(data.rows==undefined) data.rows=[]		

			Fxcsnljb=data.rows[0].FID_FXCSNL
			Fxcprq=data.rows[0].FID_JJFXPGRQ
			SFxyCp=data.rows[0].FID_CS1	
	 	 	

	 }

	// get_ZJInfo()
}



var haveZZ=false;
var bKhzt=false;
var bYjkh=false;

//请求登记账号
function get_ZJInfo(){
		setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":User.khh,"CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})

}
//应答登记账号信息
function ret_Djzh(_fromid,_funid,_flagtype,data){
	
	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		
	 //	return;
	}else{
		if(data.rows==undefined) data.rows=[]

		for(var i=0; i<data.rows.length; i++)
		{
			if (data.rows[i].TA_CODE==fxjgdm )
			{
				haveZZ==true;
				if (data.rows[i].ACCT_STAT=="0" || data.rows[i].ACCT_STAT=="A")
				{
					bKhzt=true;
					bYjkh=true;
					break;
				};
			};

		}
	 	
	}

	OnContinuesTj();
}









// 提交
function OnTj(){

	

	var obj=document.getElementById('czlx');
	var index=obj.selectedIndex;
	czlx=obj.options[index].value


	var obj2=document.getElementById('jszh');
	for(var i = 0 ; i < obj2.options.length;i++)
	{
		if(obj2.options[i].selected)
		{
			jszh=obj2.options[i].text;			
			break;
		}
	}
	

	var obj3=document.getElementById('fxjg');
	for(var j = 0 ; j < obj3.options.length;j++)
	{
		if(obj3.options[j].selected)
		{
			selectNum=j;
			fxjg=obj3.options[j].text;	
			fxjgdm=glob.fxjgdm[j]
			Wjbm=glob.wjbm[j]
			djkhce=glob.djkhcp[j]

			break;		
		}
	}

	
	get_ZJInfo()

	

}



function OnContinuesTj(){

	if (bYjkh==true)
	{
		proInfo("您已经开户，不予许重复开户");
		bYjkh=false;
		return;
	};

	if (SFxyCp=="1") 
	{
		if (Fxcsnljb=="0" || Fxcsnljb=="")
		{
			proInfo("您尚未做投资人风险承受能力评估，请前往基金标签下的基金风险承受能力测评界面做测评之后在进行此操作");
			return;
		}
		else
		{
			proInfo("您的投资人风险承受能力评估已过期，请前往基金标签下的基金风险承受能力测评界面做测评之后在进行此操作");
			return;
		}
	};
	if (Fxcsnljb=="" || Fxcsnljb==undefined)
	{
		proInfo("您尚未做投资人风险承受能力评估，请前往基金标签下的基金风险承受能力测评界面做测评之后在进行此操作");
		return;
	};

	
	get_jgbz()
	

	/*if (djkhce=="1")// 1|多步式--不需测评
	{
		$('#singlewt').dialog('open');
	}
	else// 0|单步式--必须测评
	{
		proInfo("请前往基金标签下的基金风险承受能力测评界面做测评之后在进行此操作");
		return;
	}*/
}



var jgbz="";


// 获取机构标志
function get_jgbz(){

	setIX({"funcid":"302001","funcname":'ret_jgbz',"FID_KHH":User.khh,"FID_EXFLG":"1"})
}

function ret_jgbz(_fromid,_funid,_flagtype,data){
	

	if (_funid=="5010:SIMPLE.302001") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			proError(data.ErrorInfo);
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到获取机构标志");
				return;
			}else{	
				
				jgbz=data.rows[0].FID_JGBZ;
				
				
			}
		}
	}

	
	get_Wjbm()
}

// 获取问卷编码
function get_Wjbm(){
	
	setIX({"funcid":"502750","funcname":'ret_Wjbm',"FID_WJBM":"","FID_JGBZ":jgbz,"FID_JGDM":fxjgdm})
}

function ret_Wjbm(_fromid,_funid,_flagtype,data){
	if (_funid=="5010:SIMPLE.502750") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			proError(data.ErrorInfo);
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到该机构的问卷编码");
				return;
			}else{				
				
				Wjbm=data.rows[0].FID_WJBM;				
			}
		}
	}
		
	get_CpwjInfo()
	
}





//查询调查问卷评测数据
function get_CpwjInfo(){
	
	//setIX({"funcid":"502063","funcname":'ret_CpwjInfo',"FID_KHH":User.khh,"FID_WJBM":Wjbm,"FID_FLAG":"0"})
	setIX({"funcid":"502063","funcname":'ret_CpwjInfo',"FID_KHH":User.khh,"FID_WJBM":"JJFXCSNL","FID_FLAG":"1"})

}
//应答查询调查问卷评测数据
function ret_CpwjInfo(_fromid,_funid,_flagtype,data){

	
	data=FormatResult(data,1)


	if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)						
			return
	}

	if (data.rows==undefined) 
	{
		proInfo("您尚未做投资人风险承受能力评估，请前往基金标签下的基金风险承受能力测评界面做测评之后在进行此操作");
		return;
	}
	else
	{


	if (data.rows.length>0)
	{

		if (djkhce=="1")// 1|多步式--不需测评
		{
			$('#singlewt').dialog('open');
		}
		else// 0|单步式--必须测评
		{
			proInfo("请前往基金标签下的基金风险承受能力测评界面做测评之后在进行此操作");
			return;
		}

	}
	else
	{
		proInfo("您尚未做投资人风险承受能力评估，请前往基金标签下的基金风险承受能力测评界面做测评之后在进行此操作");
		return;

	}
	

	}

	
}





function onSinOk(){
	$('#singlewt').dialog('close');
	get_kh();	
}
function onSinCance(){
	$('#singlewt').dialog('close');
}


// 开户
function get_kh(){	
	/*setIX({"funcid":"502131","funcname":'ret_kh',"FID_KHH":User.khh,"FID_JSZH":jszh,"FID_FXJG":fxjg,"FID_JMLX":"","FID_YHMM":"",
		"FID_TMDA":"","FID_ZY":"","FID_FXCSNL":""})*/

	setIX({"funcid":"502131","funcname":'ret_kh',"FID_KHH":User.khh,"FID_JSZH":jszh,"FID_FXJG":fxjgdm,"FID_JMLX":"","FID_YHMM":"",
		"FID_TMDA":"","FID_ZY":"","FID_FXCSNL":""})

}


function ret_kh(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.502131"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){					
			proError(data.ErrorInfo)			
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号信息")
				return
			}
			else{

				proInfo("您已成功开户,流水号:"+data.rows[0].FID_LSH);
					
										
			}
		}

		
	}
}


