
//判断Input只能输入数字和字母
function CheckNumChar(name,node,e){
	if(name=="keypress"){
		var k = window.event ? e.keyCode:e.which;
	    if (((k >= 48) && (k <= 57))||((k >= 65) && (k <= 90))||((k >= 97) && (k <= 122)) || k==8 || k==0){
	    	
	    }else{
	    	if(window.event) window.event.returnValue = false; 
			else e.preventDefault();
		}
	}
}

//判断Input只能输入整数
function CheckNum(name,node,e){
	if(name=="keypress"){
		var k = window.event ? e.keyCode:e.which;
	    if (((k >= 48) && (k <= 57)) || k==8 || k==0){
	    }else{
	    	if(window.event) window.event.returnValue = false; 
			else e.preventDefault();
		}
	}
}
//判断input只能输入浮点型
function CheckFloat(name,node,e){
	if(name=="keypress"){
		var k = window.event ? e.keyCode:e.which;
	    if (((k >= 48) && (k <= 57)) || k==8 || k==0||k==46){
	    	if(k==46){//"判断小数点"
	    		var val=$(node).attr("value")
	    		if(val.indexOf(".")!=-1)
	    			if(window.event) window.event.returnValue = false; 
					else e.preventDefault();
	    	}
	    }else{
	    	if(window.event) window.event.returnValue = false; 
			else e.preventDefault();
		}
	}
}


/*
选择表格中对应值的行
@param：field:需要查找的列名,id：表格ID,v:需要查找的值
@return：返回对应的行，没找到返回-1
*/

function selectRow(field){
	return function(v,id){
		var data=$("#"+id).datagrid("getRows")
		for(var i=0;i<data.length;i++){
			if(data[i][field]==v){
				$("#"+id).datagrid("selectRow",i)
				return [1,data[i]];
			}
		}
		return -1
	}
}
/*
*获取操作站点
*@return:ip地址+mac地址

*/
function getPcInfo(){
	var info=User.minfo.split(";")

	if(info.length!=12)
		return ""
	return info[7]+" "+info[8]
}
/*
*设置IX协议
*@param cfg为{},其中funcid和funcname2个key必须填入
*/
function setIX(cfg){
	var CurrTime=getCurRequstTime();
	var _ix = new IXContent();
	_ix.Set('F_FUNCTION', cfg.funcid);//功能号
	
	if ( cfg.funcid=="99001335" || cfg.funcid=="99001332" || cfg.funcid=="99001350" || cfg.funcid=="99001262" || cfg.funcid=="99001337"
		|| cfg.funcid=="99001341" || cfg.funcid=="99001345" || cfg.funcid=="99001334" || cfg.funcid=="99001120" || cfg.funcid=="99001110"
		|| cfg.funcid=="99001100" || cfg.funcid=="99001254" || cfg.funcid=="99001270" || cfg.funcid=="99001339" || cfg.funcid=="99001338" || cfg.funcid=="L2800920") 
	{
		_ix.Set('F_OP_USER', User.gydm);//操作用户代码
		//_ix.Set('F_OP_USER', "8888");//操作用户代码
		_ix.Set('F_OP_ROLE','2');//操作用户角色
	}
	else
	{
		_ix.Set('F_OP_USER', User.khh);//操作用户代码
		_ix.Set('F_OP_ROLE','1');//操作用户角色		
	}

	_ix.Set('F_TRD_PWD', User.otcjymm);//交易密码
	
	_ix.Set('F_OP_SITE', '');//操作站点
	_ix.Set('F_CHANNEL', '5');//操作渠道
	//_ix.Set('F_SESSION', '##SESSION##');//会话凭证
	_ix.Set('F_SESSION', '0000000011111111');//会话凭证
	//_ix.Set('F_RUNTIME','##RUNTIM##');//调用时间
	_ix.Set('F_RUNTIME',"");//调用时间
	_ix.Set('F_OP_SRC', '0');//操作用户来源
	_ix.Set('@MAC', User.minfo);
	_ix.Set('@COND', 'SELECT * from '+ cfg.funcid);
	$.each(cfg,function(key,val){
		if(key=="funcid"||key=="funcname"){}
		else{
			_ix.Set(key, val);
		}
	})

	Win_CallTQL(cfg.funcname, '5010:SIMPLE.'+cfg.funcid, _ix, '');
}
//获取当前请求时间
function getCurRequstTime(){
	var myDate = new Date();
	var mytime=myDate.toLocaleTimeString(); 
	var m=myDate.getMonth();
	var d=myDate.getDate()
	if(m<10)
		m="0"+(m+1);
	if(d.toString().length==1)
		d="0"+d;
	return myDate.getFullYear().toString()+m+d+" "+mytime
	}

/*
*单数转双数
*@param：整数
*@return:双数
*/

function sigtodow(i){
	if(i<10)
		return "0"+i
	else
		return i+""
}
/*
*获取input选中文本
*@param：inputDom：input节点
*@return:选中文本
*/
function getSelectedText(inputDom){ 
    if (document.selection) //IE
     {
        return document.selection.createRange().text;
    } 
    else { 
        return inputDom.value.substring(inputDom.selectionStart, 
                inputDom.selectionEnd); 
    } 
}
function hideLoading(){
	$(".tdx_loading").remove();
}



//判断字符串是否为空
function isNullStr(s){
	if(s.replace(/(^\s*)|(\s*$)/g, "").length==0)
		return 1;
	return 0;
}

//产品状态
function get_Stat(c){
	var stat=""
	if(c=="0")
		stat="募集前状态"
	else if(c=="1")
		stat="募集期"
	else if(c=="2")
		stat="开放期"
	else if(c=="3")
		stat="封闭期"
	else if(c=="4")
		stat="清盘"
	return stat
}

//风险级别
function get_RiskLvl(c){
	var Lvl=""
	if(c=="1")
		Lvl="低"
	else if(c=="2")
		Lvl="中低"
	else if(c=="3")
		Lvl="中"
	else if(c=="4")
		Lvl="中高"
	else if(c=="5")
		Lvl="高"
	else if(c=="0")
		Lvl="未评级"
	return Lvl
}

//客户风险级别
function get_KhRiskLvl(c){
	var Lvl=""
	if(c=="0")
		Lvl="未评级"
	else if(c=="1")
		Lvl="高抗风险"
	else if(c=="2")
		Lvl="较高抗风险"
	else if(c=="3")
		Lvl="中抗风险"
	else if(c=="4")
		Lvl="较低抗风险"
	else if(c=="5")
		Lvl="低抗风险"	
	return Lvl
}
//交易类别
function get_TraType(c){

	var tra=""
	if(c=="001")
		tra="开户"
	else if(c=="002")
		tra="销户"
	else if(c=="003")
		tra="变更"
	else if(c=="008")
		tra="注册"
	else if(c=="110")
		tra="认购"
	else if(c=="111")
		tra="申购"
	else if(c=="112")
		tra="赎回"
	else if(c=="20B")
		tra="买入"
	else if(c=="20S")
		tra="卖出"
	return tra
}

// 产品子类
function get_InstCls(c){
	var tra=""
	if(c=="10")
		tra="股票"
	else if(c=="20")
		tra="衍生品"
	else if(c=="30")
		tra="商品"
	else if(c=="40")
		tra="外汇"
	else if(c=="51")
		tra="信托融资"
	else if(c=="52")
		tra="信托投资"
	else if(c=="60")
		tra="券商理财"
	else if(c=="71")
		tra="一对一"
	else if(c=="72")
		tra="一对多"
	else if(c=="80")
		tra="有限合伙基金"
	else if(c=="90")
		tra="银行理财"
	else if(c=="A0")
		tra="保险理财"
	else if(c=="B0")
		tra="债券"
	return tra
}

//意向约定
function get_MatchType(c){
	var matchtype=""
	if (c=="0") 
		matchtype="可部分成交"
	else if (c=="1")
		matchtype="不可部分成交"
	return matchtype
}

function easyui_grid(cuscol,d,id,easyid){
	//cuscol:[[["字段名","字段标题"],["字段名2","字段标题2"]]]
	//如果列需要其它属性,则cuscol:格式为:[[["字段名","字段标题",{}],["字段名2","字段标题2",{}]]]

	id=id||"tdx_center"
	easyid=easyid||"load"
	cuscol=cuscol||[]
	var mygrid=$("<div id='"+easyid+"'></div>").appendTo($("#"+id));

	d=$.extend({},{
					singleSelect:true,
					fitColumns:true,
					scrollbarSize:0,
					loadMsg:'',
					border:false,
					remoteSort: false
				},d)
	if(d.onDblClickRow!=undefined)
		d.onDblClickRow=onDlbEasyGrid(d.onDblClickRow,easyid)
	var head=[]		
	for(var k=0;k<cuscol.length;k++){
	 	head.push([])
	 	for(var h=0;h<cuscol[k].length;h++){
	 		if(cuscol[k][h].length==3){
	 			head[k].push($.extend({},{halign:'center',align:'right',width:100},{field:cuscol[k][h][0],title:cuscol[k][h][1]},cuscol[k][h][2]))
	 		}
	 		else{
	 			head[k].push($.extend({},{halign:'center',align:'right',width:100},{field:cuscol[k][h][0],title:cuscol[k][h][1]}))
	 		}
	 	}
	 }
	 d.columns=head
	 mygrid.datagrid(d)
	 var _52d = $.data( $("#"+easyid)[0], "datagrid");
	 var dc = _52d.dc;
	 dc.body1.add(dc.body2).unbind("mouseover mouseout")
}



function create_easygrid(funname,easyhead,columns,did){
	//easyhead{key:value}
	//columns:{"field":{}}
	var eaid=(did==undefined)?{}:did
	eaid=$.extend({},{"id":"tdx_center","easyid":"load"},did)
	var head=getHead(funname)

	if(easyhead!=undefined){
		$.each(easyhead,function(k,v){

			head.easyhead[k]=v
		})
	}
	
	if(columns!=undefined){
		for(var i=0;i<head.columns.length;i++){
			for(var k=0;k<head.columns[i].length;k++){
				if(columns[head.columns[i][k][0]]!=undefined)
					if(head.columns[i][k].length==2)
						head.columns[i][k].push(columns[head.columns[i][k][0]])
					else{

						head.columns[i][k][2]=$.extend({},head.columns[i][k][2],columns[head.columns[i][k][0]])
					}
			}
		}
	}

	easyui_grid(head.columns,head.easyhead,eaid.id,eaid.easyid)	
}

/**
*功能:更新easy表格数据,表格无数据时加提示信息
*备注：表格第一列为check时不要调用这个函数
*参数:rt表格id,
	  data表格更新数据
	  opts：{}对象 {"info"}
	  		info:表格无数据的提示文本,默认"没有相应的查询信息"
*返回:无
*/
function upDate(rt,data,opts){

	
	var opt=$("#"+rt).datagrid("options")
	opt.hasData=1//表格是否有数据的标志,默认有数据
	opts=opts||{}
	var field=$("#"+rt).datagrid("getColumnFields")
	if(opt.columns[0][0]["talign"]==undefined)
		opt.columns[0][0]["talign"]=opt.columns[0][0].align
	else
		opt.columns[0][0].align=opt.columns[0][0]["talign"]
	if(opt.columns[0][0].tstyler==undefined)
		opt.columns[0][0]["tstyler"]=opt.columns[0][0].styler
	else if(opt.columns[0][0].tstyler=="null")
		opt.columns[0][0]["styler"]=undefined
	else
		opt.columns[0][0]["styler"]=opt.columns[0][0].tstyler
	
	if(data.rows==undefined||data.rows.length==0){		
		data={"total":0,"rows":[{}]}
		$.each(field,function(k,v){
			if(k==0)
				data.rows[0][v]=opts["info"]||"没有相应的查询信息"
			else
				data.rows[0][v]=""
		})
		if(opt.columns[0][0].styler==undefined)
			opt.columns[0][0]["tstyler"]="null"
		opt.columns[0][0].align="left"
		opt.columns[0][0].styler=function(){return "color:red;"}
		opt.hasData=0//表格是否有数据标志

	}
	$("#"+rt).datagrid("loadData",data);

	if(data.total==0)
		$("#"+rt).datagrid("mergeCells",{"index":0,"field":field[0],"colspan":field.length});
	
}

/**
*功能:处理弹出对话框拖动时与父节点的高度,
*备注：easyui的弹出对话框拖动时有bug,需要控制和父节点的高度
*参数:sid 弹出对话框的id,
	  top 距离父节点高度
*返回:无
*/
function setDlg(sid,top){
	sid=sid||"cdwt"
	top=top||10
	var dg=$.data($("#"+sid)[0], "window")			
	$("#"+sid).dialog("dialog").draggable("options").onDrag=function(e) {
		if(e.data.top<top){
			e.data.top=top
			dg.proxy.css({
				display: "block",
				left: e.data.left,
				top: e.data.top
			})
			return false;
		}else{
			dg.proxy.css({
				display: "block",
				left: e.data.left,
				top: e.data.top
			})
			return false;
		}
	}
}

/**
*功能:处理表格无数据时的双击事件
*参数:fDlbRow 双击时自定义的回调函数,
	  rt 表格ID
*返回:无
*/
function onDlbEasyGrid(fDlbRow,rt){
	return function(rowindex,rowdata){
		var opt=$("#"+rt).datagrid("options")
		if(opt.hasData==0)//表格是否有数据标志，0为无数据
			return
		fDlbRow(rowindex,rowdata)
	}
}
/**
*功能:弹出调试信息,相对于改进的alert
*参数:info要显示的信息,类型可以为字符串,[],{}
*返回:无
*/

function myAlert(info){
	alert(JSON.stringify(info))
}

/**
*功能:一般提示信息
*参数:txt为提示信息
*返回:无
*/
function proInfo(txt){
	$.messager.alert('提示',txt,"info");
}

/**
*功能:错误提示信息
*参数:txt为错误的信息
*返回:无
*/
function proError(txt){
	$.messager.alert('提示',txt,"error");
}


/**
*功能:返回当前日期
*参数:无　　　
*返回:当前日期 格式为yyyymmdd
*/
function getCur(){
	var d = new Date();
	var year = d.getFullYear();
	var month = d.getMonth()+1;
	month = (month<10)?('0'+month):month;
	var day = d.getDate();
	if(day<10) day = "0" + day;
	return year.toString()+month.toString()+day.toString();
}

/**
*功能:返回与当前日期相距N月的日期
*参数:delta类型可以为正负整数;　　　　
*返回:新的日期 格式为yyyymmdd
*/
function getAddMonth(delta){
	var d = new Date();
	d.setMonth(d.getMonth() + delta);
	var year = d.getFullYear();
	var month = d.getMonth()+1;
	month = (month<10)?('0'+month):month;
	var day = d.getDate();
	if(day<10) day = "0" + day;
	return year.toString()+month.toString()+day.toString();
}

function getTime(c){	
	return c.substring(11)	
}

function getAcctStat(c){
	var state;
	if (c=="0") {
		state="正常";
	}
	else if (c=="1") {
		state="冻结";
	}
	else if (c=="2") {
		state="挂失";
	}
	else if (c=="3") {
		state="司法冻结";
	}
	else if (c=="4") {
		state="休眠";
	}
	else if (c=="8") {
		state="异常";
	}
	else if (c=="9") {
		state="注销";
	}
	else if (c=="A") {
		state="开户中";
	}	
	else{
		state="";
	}
	return state;
}

function getIdType(c){
	var IdType=""
	if (c=="00") {
		IdType="身份证";
	}
	else if (c=="01") {
		IdType="护照";
	}
	else if (c=="02") {
		IdType="军官证";
	}
	else if (c=="03") {
		IdType="士兵证";
	}
	else if (c=="04") {
		IdType="港澳居民来往内地通行证";
	}
	else if (c=="05") {
		IdType="户口本";
	}
	else if (c=="06") {
		IdType="外国护照";
	}
	else if (c=="07") {
		IdType="其他";
	}
	else if (c=="08") {
		IdType="文职证";
	}
	else if (c=="09") {
		IdType="警官证";
	}
	else if (c=="0A") {
		IdType="台胞证";
	}
	else if (c=="10") {
		IdType="组织机构代码证";
	}
	else if (c=="11") {
		IdType="营业执照";
	}
	else if (c=="12") {
		IdType="行政机关";
	}
	else if (c=="13") {
		IdType="社会团体";
	}
	else if (c=="14") {
		IdType="军队";
	}
	else if (c=="15") {
		IdType="武警";
	}
	else if (c=="16") {
		IdType="下属机构";
	}
	else if (c=="17") {
		IdType="基金会";
	}
	else if (c=="18") {
		IdType="其他";
	}
	else{
		IdType="";
	}
	return IdType;
}

// 协议种类
function get_xyzl(c)
{
	var xyzl="";
	if(c=="201")
	{
		xyzl="OTC电子约定书"
	}
	else if(c=="202")
	{
		xyzl="OTC电子合同"
	}
	else if(c=="203")
	{
		xyzl="理财协议"
	}
	return xyzl;
}

// 签署类型
function get_qslx(c)
{
	var qslx="";

	if(c==0)
	{	
		qslx="数字证书"
	}
	else if(c==1)
	{
		qslx="动态令牌"
	}
	else if(c==2)
	{
		qslx="纸质"
	}
	return qslx;
}

// 产品大类
function get_cpdl(c)
{
	var cpdl="";
	if(c=="1")
	{
		cpdl="股票"
	}
	else if(c=="2")
	{
		cpdl="衍生品"
	}
	else if(c=="3")
	{
		cpdl="商品"
	}
	else if(c=="4")
	{
		cpdl="外汇"
	}
	else if(c=="5")
	{
		cpdl="信托"
	}
	else if(c=="6")
	{
		cpdl="券商理财"
	}
	else if(c=="7")
	{
		cpdl="公募基金"
	}
	else if(c=="8")
	{
		cpdl="有限合伙基金"
	}
	else if(c=="9")
	{
		cpdl="银行理财"
	}
	else if(c=="A")
	{
		cpdl="保险理财"
	}
	else if(c=="B")
	{
		cpdl="债券"
	}
	
	return cpdl;
}


// 产品子类
function get_cpzl(c)
{
	var cpzl="";
	if(c=="10")
	{
		cpzl=="股票"
	}
	else if(c=="20")
	{
		cpzl="衍生品"
	}
	else if(c=="30")
	{
		cpzl="商品"
	}
	else if(c=="40")
	{
		cpzl="外汇"
	}
	else if(c=="51")
	{
		cpzl="信托融资"
	}
	else if(c=="52")
	{
		cpzl="信托投资"
	}
	else if(c=="60")
	{
		cpzl="券商理财"
	}
	else if(c=="71")
	{
		cpzl="一对一"
	}
	else if(c=="72")
	{
		cpzl="一对多"
	}
	else if(c=="80")
	{
		cpzl="有限合伙基金"
	}
	else if(c=="90")
	{
		cpzl="银行理财"
	}
	else if(c=="A0")
	{
		cpzl="保险理财"
	}
	else if(c=="B0")
	{
		cpzl="债券"
	}
	
	return cpzl;
}

function get_orderstatus(c)
{
	var stat=""
	if(c=="0")
		stat="未报"
	else if(c=="1")
		stat="已报"
	else if(c=="2")
		stat="确认"
	else if(c=="3")
		stat="部撤"	
	else if(c=="4")
		stat="全撤"
	else if(c=="5")
		stat="部成"
	else if(c=="6")
		stat="全成"
	else if(c=="7")
		stat="废单"
	else if(c=="8")
		stat="已报待撤"
	else if(c=="9")
		stat="部成待撤"
	else if(c=="A")
		stat="待撤销"
	else if(c=="B")
		stat="TA确认"
	else if(c=="C")
		stat="TA失败"
	else if(c=="D")
		stat="待申报"
	else if(c=="E")
		stat="对手拒绝"
		
	return stat
}