var glob={
	"cpjz":"",//净值
	"cpljjz":""//累计净值
}


function PageInit(){
	get_CpJz()
	//get_CpInfo()
}





//获取产品净值
function get_CpJz(){
	setIX({"funcid":"L2620304","funcname":'ret_CpJz',"BGN_DATE":getCur(),"END_DATE":getCur(),"ISS_CODE":"","INST_CODE":"","INST_ID":"","LATEST_FLAG":"1","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}
function ret_CpJz(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2620304"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
		 	return;
		}else{
		 	if(data.rows==undefined) data.rows=[]
		 	var cp={}
		 	var cp1={}
		 	$.each(data.rows,function(k,v){
		 		cp[v.INST_ID]=v.LAST_NET
		 		cp1[v.INST_ID]=v.ACCU_NET
		 	})
		 	glob.cpjz=cp
		 	glob.cpljjz=cp1
		}
	}

	get_CpInfo()
	
}











//获取产品信息
function get_CpInfo(){
	setIX({"funcname":'ret_CpInfo',"funcid":"L2612001","ISS_CODE":"","INST_CODE":"","INST_ID":"","INST_TYPE":"","INST_CLS":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}
function ret_CpInfo(_fromid,_funid,_flagtype,data){
	hideLoading()
	if(_funid=="5010:SIMPLE.L2612001"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			//$.messager.alert('提示',data.ErrorInfo,"error");
		 	return;
		}else{
			if(data.rows==undefined) data.rows=[]
			create_easygrid("产品信息",{},{"ISS_STAT":{"formatter":get_Stat},"RISK_LVL":{"formatter":get_RiskLvl}})
			data.rows=$.grep(data.rows,function(v,i){
				if(v.ISS_STAT!="4")
				{
					if(glob.cpjz[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].LAST_NET=""
			 		else
			 			data.rows[i].LAST_NET=glob.cpjz[data.rows[i].INST_ID]

			 		if(glob.cpljjz[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].ACCU_NET=""
			 		else
			 			data.rows[i].ACCU_NET=glob.cpljjz[data.rows[i].INST_ID]

			 		return v
				}
					
			})
			data.total=data.rows.length
			upDate("load",data)
			var opt=$("#load").datagrid("options")
			opt.allData=data
		}
	}
}


var selectopt=[[{"value":"1","txt":"低"},{"value":"2","txt":"中低"},{"value":"3","txt":"中"},{"value":"4","txt":"中高"},{"value":"5","txt":"高"}],
				[{"value":"0","txt":"募集前状态"},{"value":"1","txt":"募集期"},{"value":"2","txt":"开放期"},{"value":"3","txt":"封闭期"}]]					
function onset(node){
	var selectedOption=node.options[node.selectedIndex];
	if($(node).attr("prevalue")==node.value)
		return
	$(node).attr("prevalue",node.value)
	var obj=document.getElementById('detail');
	obj.options.length=0;
	if(node.value=="0"){
		$.each(selectopt[0],function(i,val){
			obj.add(new Option(val.txt,val.value)); 
		})
	}else if(node.value=="1"){
		var obj=document.getElementById('detail');
		$.each(selectopt[1],function(i,val){
			obj.add(new Option(val.txt,val.value)); 
		})
	}
}

function onSubMit(){
	var obj=document.getElementById('detail');
	var val = obj.options[obj.selectedIndex].value;
	var obj1=document.getElementById('kkr_type');
	var val1 = obj1.options[obj1.selectedIndex].value;
	var opt=$("#load").datagrid("options")
	var data=opt.allData
	var updata={}
	var filtdata=[]

	if(val1=="0"){//按风险等级
		$.each(data.rows,function(k,v){
			if(v.RISK_LVL==val)
				filtdata.push(v)
		})
	}else if(val1=="1"){
		$.each(data.rows,function(k,v){
			if(v.ISS_STAT==val)
				filtdata.push(v)
		})
	}
	updata["total"]=filtdata.length
	updata["rows"]=filtdata
	upDate("load",updata)
}