﻿var TDX_DIC={
// Part.II 数据类型
//---------------------------------------------------------------------------
DATATYPE:{
	'1':'TDX_DT_CHAR',
	'2':'TDX_DT_SHORT',
	'3':'TDX_DT_LONG',
	'4':'TDX_DT_LONGLONG',
	'5':'TDX_DT_FLOAT',
	'6':'TDX_DT_DOUBLE',
	'7':'TDX_DT_LONGDOUBLE',
	'8':'TDX_DT_DATE',		
	'9':'TDX_DT_TIME',		
	'10':'TDX_DT_STRING',	
	'11':'TDX_DT_MEMO',		
	'12':'TDX_DT_BINARY',	
	'13':'TDX_DT_RECORDSET',
	'14':'TDX_DT_PASSWORD'
},


//---------------------------------------------------------------------------
// Part.III 对齐显示类型
//---------------------------------------------------------------------------
Align:{
'0':'right',		//TDX_DISP_TOP
'1':'left',			//TDX_DISP_LEFT
'2':'center',		//TDX_DISP_CENTER
'4':'right',		//TDX_DISP_RIGHT
'6':'vmiddle',		//TDX_DISP_VCENTER
'8':'vbottom',		//TDX_DISP_BOTTOM
'':''				//TDX_DISP_NONE
}

}
/*
* 转换IX的解析出来的数组
* json: 返回的IX数据
* type: 1-easyui
*/
function FormatResult(json,type){
	var data={};
	var list=getResultList(json,false);
	data["ErrorCode"]=list[0].ErrorCode;
	data["ErrorInfo"]=list[0].ErrorInfo;
	data["POS"]=list[0].POS;
	var config={};
	if(list.length>6){
		config["FieldName"]=list[1];
		config["HideFlag"]=list[2];
		config["Align"]=list[3];
		config["Width"]=list[4];
		config["DataType"]=list[5];
		config["CatheFlag"]=list[6];
	}

	if(type=="1"){
		if(list.length>7){
			var rows=[];
			for(var i=7;i<list.length;i++){
				if(i==7){
					var keys={};
					for(var key in list[i]){
						keys[key]=key;
					}
					config["FieldKey"]=keys;
				}
				rows[rows.length]=list[i];
			}
			data["total"]=rows.length;
			data["rows"]=rows;
		}
	}

	data["config"]=config;
	
	return data;
}
//全局变量
var User={
	khh:"",
	gydm:"",
	uname:"",
	zjzh:"",
	yyb:"",
	wtfs:"",
	token:"",
	otcjymm:"",
	minfo:""
}

/*获取基本信息*/
function getUserInfo(){
	//获取基本客户信息
	Win_CallTQL('ret_getkhxx', 'getkhxx', new IXContent() ,'');
}

function ret_getkhxx(_fromid,_funid,_flagtype,data) {
	//alert([_fromid,_funid,_flagtype,data]);
	
	if(_funid == 'getkhxx'){
		if(data!=""){
			var info=data.split("#");
			try{
				User.khh=info[2];
				User.zjzh=info[3];			
			}
			catch(e){
				alert("获取资金账号失败！\r\n"+data);
			}
		}
	}

	//获取营业部信息
	//Win_CallTQL('ret_getuname', 'getuname', new IXContent() ,'');
	
	getUserInfo2()
//	getUserCode()
}




/*获取基本信息*/
function getUserInfo2(){
	
	var _ix = new IXContent();
	_ix.Set('keyid', "F1227");//功能号
	
	Win_CallTQL('ret_getkhxx2', 'getuidxml', _ix ,'');
}

function ret_getkhxx2(_fromid,_funid,_flagtype,data) {

	//alert([_fromid,_funid,_flagtype,data]);
	
	if(_funid == 'getuidxml'){
		if(data!=""){				
			User.khh=data;	
				
		}
	}	
	//获取营业部信息
	getUserToken()
}




/*获取基本信息*/
function getUserToken(){
	
	var _ix = new IXContent();
	_ix.Set('keyid', "F250");//功能号
	
	Win_CallTQL('ret_UserToken', 'getuidxml', _ix ,'');
}

function ret_UserToken(_fromid,_funid,_flagtype,data) {
		//alert([_fromid,_funid,_flagtype,data]);
	
	if(_funid == 'getuidxml'){
		if(data!=""){				
			User.token=data;	
				
		}
	}

	
	//alert(User.token)
	//获取营业部信息
	getUserOTCJymm()
}




/*获取OTC交易密码信息*/
function getUserOTCJymm(){
	
	var _ix = new IXContent();
	_ix.Set('keyid', "F252");//功能号
	
	Win_CallTQL('ret_UserOTCJymm', 'getuidxml', _ix ,'');
}

function ret_UserOTCJymm(_fromid,_funid,_flagtype,data) {
		//alert([_fromid,_funid,_flagtype,data]);
	
	if(_funid == 'getuidxml'){
		if(data!=""){				
			User.otcjymm=data;	
				
		}
	}

	getUserCode()
}












/*获取配置文件配置的柜员代码*/
function getUserCode(){
	//获取柜员代码
	var _ix = new IXContent();
	_ix.Set("key", "USECODE")
	Win_CallTQL('ret_getUserCode', 'gettradeccf', _ix ,'');
}

function ret_getUserCode(_fromid,_funid,_flagtype,_json) 
{
	User.gydm = _json;
	
	//获取营业部信息
	Win_CallTQL('ret_getuname', 'getuname', new IXContent() ,'');	
}




function ret_getuname(_fromid,_funid,_flagtype,data){
	if(_funid == 'getuname'){
		if(data!=""){
				User.uname=data.split("[")[0];
		}
	}
	//获取营业部信息
	Win_CallTQL('ret_getbranchid', 'getbranchid', new IXContent() ,'');
}

function ret_getbranchid(_fromid,_funid,_flagtype,data) {
	//alert([_fromid,_funid,_flagtype,data]);

	if(_funid == 'getbranchid'){
		if(data!=""){
				User.yyb=data;
		}
	}

	//获取委托方式
	Win_CallTQL('ret_getopwtfs', 'getopwtfs', new IXContent() ,'');
}

function ret_getopwtfs(_fromid,_funid,_flagtype,data) {
	//alert([_fromid,_funid,_flagtype,data]);

	if(_funid == 'getopwtfs'){
		if(data!=""){
			User.wtfs=data;
		}
	}

	//获取机器信息
	Win_CallTQL('ret_getmachineinfo', 'getmachineinfo', new IXContent() ,'');
}

function ret_getmachineinfo(_fromid,_funid,_flagtype,data) {
	//alert([_fromid,_funid,_flagtype,data]);
	
	if(_funid == 'getmachineinfo'){
		if(data!=""){
			User.minfo=data;
		}
	}
	$('#mask').remove();
	try{PageInit();}catch(e){}
}

$(function(){
	$("body").append("<div id='mask' class='loading'></div>");
	getUserInfo();
	InitForm();
	//try{PageInit();}catch(e){}
})

function InitForm(){
	$(".form_disabled").attr("readonly",true);
	$(".tdx_form").each(function(){
		var sub_id=$(this).find(".tdx_submit").attr("id");
		if(sub_id){
			$(this).find(".form_input,select,.tdx_submit").keypress(function(){
				//传入 event 
				var e = e || window.event; 
					if(e.keyCode == 13){ alert('enter');
						$("#"+sub_id).click();
					}
			});
		}
	});
}


var pageNavs={};

//翻页控件
var PageNav=function(id){
	this.b_index=$("#"+id+" .pageIndex");
	this.b_prev=$("#"+id+" .prev_btn");
	this.b_next=$("#"+id+" .next_btn");
	this.pageIndex=0;
	this.pos="";
	this.dataCache=[];
	this.b_prev.click(function(){
		PageNav_Prev(id,$(this).attr("pindex"));
	});
	this.b_next.click(function(){
		PageNav_Next(id,$(this).attr("pindex"));
	});
	pageNavs[id]=this;
}

PageNav.prototype.LoadData=function(data){
	alert(data.rows.length);
	alert("请重载此函数！");
}

PageNav.prototype.Request=function(pos){
	alert(pos);
	alert("请重载此函数！");
}

PageNav.prototype.Clear=function(){
	this.b_prev.attr("pos","").attr("disabled","true");
	this.b_next.attr("pos","").attr("disabled","true");
	this.b_index.html("第 0 页").attr("disabled","true");
	this.pageIndex=0;
	this.pos="";
	this.dataCache=[];
}

PageNav.prototype.SetData=function(data){

	this.pos=data.POS;

	if(this.pos=="" && this.pageIndex==0){//如果第一次就返回空pos
		this.pageIndex=1;
		this.b_index.html("第 1 页").removeAttr("disabled");
		return;
	}

	//存储数据
	this.dataCache.push(data);
	this.pageIndex++;

	if(this.pageIndex>1){
		this.b_prev.removeAttr("disabled").attr("pindex",this.pageIndex-1)
	}
	
	this.b_next.removeAttr("disabled").attr("pindex","");//下一页的页码为空
	
	if(this.pos==""){//最后一页
		this.b_next.attr("disabled","true")
	}
	
	this.b_index.html("第 "+this.pageIndex+" 页").removeAttr("disabled");
}

function PageNav_Next(id,index){
	//下一页，请求数据，如果已经请求了所有页，则从缓存中取数据
	if(index==""){
		pageNavs[id].Request(pageNavs[id].pos);
	}
	else{
		pageNavs[id].LoadData(pageNavs[id].dataCache[index-1]);
		pageNavs[id].pageIndex++;
		pageNavs[id].b_index.html("第 "+pageNavs[id].pageIndex+" 页");
		pageNavs[id].b_prev.attr("pindex",pageNavs[id].pageIndex-1).removeAttr("disabled");
		if(pageNavs[id].dataCache[pageNavs[id].pageIndex-1]==undefined){
			pageNavs[id].b_next.attr("pindex","");
		}
		else{
			pageNavs[id].b_next.attr("pindex",pageNavs[id].pageIndex+1);
			if(pageNavs[id].pageIndex==pageNavs[id].dataCache.length){
				pageNavs[id].b_next.attr("disabled","true");
			}
		}
	}
}

function PageNav_Prev(id,index){
	//上一页，从缓存内拿数据
	pageNavs[id].LoadData(pageNavs[id].dataCache[index-1]);
	pageNavs[id].pageIndex--;
	pageNavs[id].b_index.html("第 "+pageNavs[id].pageIndex+" 页");
	pageNavs[id].b_prev.attr("pindex",pageNavs[id].pageIndex-1);
	pageNavs[id].b_next.attr("pindex",pageNavs[id].pageIndex+1).removeAttr("disabled");
	if(pageNavs[id].pageIndex==1){
		pageNavs[id].b_prev.attr("disabled","true");
	}
}