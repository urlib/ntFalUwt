
var glob={
	"stbm":[],// 试题编码
	"stbh":[],// 试题编号
	"xxbm":[],// 选项编码
	"xxnr":[],// 选项内容
	"stnr":[],// 试题内容
	"xxlx":[]// 选项类型
}

var configDcbdm="";
var khlx="";



function PageInit(){
	hideLoading()
	create_easygrid("风险测评信息查询",{},{"EVAL_LVL":{"formatter":get_KhRiskLvl}})
	get_CCCXInfo()
	// getDcbbm()
	
}




/*获取配置文件配置的柜员代码*/
/*function getDcbbm(){
	//获取柜员代码
	
	var _ix = new IXContent();
	_ix.Set("key", "dcbbm")
	Win_CallTQL('ret_getDcbbm', 'gettradeccf', _ix ,'');
}

function ret_getDcbbm(_fromid,_funid,_flagtype,_json) 
{
	configDcbdm = _json;
	//get_KhdzydsInfo()
	get_KhInfo()
}




// 客户信息查询接口
function get_KhInfo(){
	setIX({"funcid":"L2610002","funcname":'ret_KhInfo',"CUST_CODE":User.khh,"CUST_TYPE":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_KhInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610002"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			
		 	return;
		}
		else
		{
			if(data.rows==undefined) data.rows=[];
			
			khlx=data.rows[0].CUST_TYPE;
		}
	
		
		}
		get_KhdzydsInfo()
}









// 客户电子约定书信息查询
function get_KhdzydsInfo(){
	setIX({"funcid":"99001100","funcname":'ret_KhdzydsInfo',"SURVEY_CLS":"7"})
}

function ret_KhdzydsInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001100"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			
		 	return;
		}
		else
		{
			if(data.rows==undefined) data.rows=[];
			for(var i=0;i<data.rows.length;i++)
			{
				glob.stbm[i]=data.rows[i].SURVEY_SN;
				glob.stbh[i]=data.rows[i].SURVEY_COL;
				glob.xxbm[i]=data.rows[i].SURVEY_CELL;
				glob.xxnr[i]=data.rows[i].SURVEY_CELL_TEXT;
				glob.stnr[i]=data.rows[i].SURVEY_COL_TEXT;
				glob.xxlx[i]=data.rows[i].SURVEY_COL_OPT;
				
			}
			totalnum=data.rows.length-1;
			tmzs=data.rows[totalnum].SURVEY_COL;
		}
	
		get_FXCPInfo()
		}
}

//请求资金信息
function get_FXCPInfo(){
	//setIX({"funcid":"99001120","funcname":'ret_fxcpinfo',"SURVEY_SN":configDcbdm,"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
	var sn="0";
	if (khlx=="0")// 0个人
	{
		sn="3";
	}
	else if (khlx=="1") // 1机构
	{
		sn="4";
	}
	setIX({"funcid":"99001120","funcname":'ret_fxcpinfo',"SURVEY_SN":sn,"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
}
//应答资金信息
function ret_fxcpinfo(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		if(data.ErrorInfo.indexOf("没有查询数据")!=-1)
		{
			data.rows=[]
	 	
	 		upDate("load",data)
		}
		else
		{
			$.messager.alert('提示',data.ErrorInfo,"error");
		}
		
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
	 	
	 	upDate("load",data)
	}
}


*/



//查询客户风险等级信息
function get_CCCXInfo(){
	
	setIX({"funcid":"L2610003","funcname":'ret_CCCXInfo',"CUST_CODE":User.khh})
}


//应答产品信息
function ret_CCCXInfo(_fromid,_funid,_flagtype,data){
	
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		if(data.ErrorInfo.indexOf("没有查询数据")!=-1)
		{
			data.rows=[]
	 	
	 		upDate("load",data)
		}
		else
		{
			$.messager.alert('提示',data.ErrorInfo,"error");
		}
		
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
	 	
	 	upDate("load",data)
	}
}





