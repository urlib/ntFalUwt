﻿var glob={
	"djzh":"",//登记账号
	"djjg":"",//登记机构
	"jyzh":"",//交易账号
	"zczh":"",//资产账户
	"fxrdm":"",//发行人代码
	"cpbm":"",//产品编码
	"cpcode":"",
	"cpname":"",
	"zzrq":"",//产品终止日期
	"ksfe":"",//可赎份额
	"wtsl":"",//委托数量
	"cpjz":"",//产品净值
	"dlgflag":"0"//调用委托成交的对话框标志
	
}

var KhFxdj = "";
var CpFxdj="";	// 产品风险等级
var bFxts = false;
var KhFxdjmc="";
var configDcbdm="";
var khlx="";
var Cpyxrq="";
var Cprq="";


function PageInit(){
	setDlg()
	//setDlg("cdSucwt")
	hideLoading()
	create_easygrid("赎回",{onDblClickRow:onDblClickRow},{})
	// get_Djzh()
	//get_CpJz()
	getDcbbm()
}



/*获取配置文件配置的柜员代码*/
function getDcbbm(){
	//获取柜员代码
	
	var _ix = new IXContent();
	_ix.Set("key", "dcbbm")
	Win_CallTQL('ret_getDcbbm', 'gettradeccf', _ix ,'');
}

function ret_getDcbbm(_fromid,_funid,_flagtype,_json) 
{
	configDcbdm = _json;
	get_CpJz()
	//get_KhInfo()
	
}




// 客户信息查询接口
function get_KhInfo(){
	setIX({"funcid":"L2610002","funcname":'ret_KhInfo',"CUST_CODE":User.khh,"CUST_TYPE":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_KhInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610002"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			
		 	return;
		}
		else
		{
			if(data.rows==undefined) data.rows=[];
			
			khlx=data.rows[0].CUST_TYPE;
		}
	
		
		}
		get_CpJz()
}




//获取登记账号
function get_Djzh(){

	setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":User.khh,"CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
	
}

function ret_Djzh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610008"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{

				for(var i=0;i<data.rows.length;i++)
				{
					if (data.rows[i].TA_CODE == glob.djjg) 
					{
						glob.djzh=data.rows[i].TA_ACCT					
						glob.jyzh=data.rows[i].TRANS_ACCT
						glob.zczh=data.rows[i].CUACCT_CODE
					}
				}

				
				
			}
		}
		//get_CpJz()
		get_subXd()
	}
}

//获取产品净值
function get_CpJz(){

	setIX({"funcid":"L2620304","funcname":'ret_CpJz',"BGN_DATE":getCur(),"END_DATE":getCur(),"ISS_CODE":"","INST_CODE":"","INST_ID":"","LATEST_FLAG":"1","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}
function ret_CpJz(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2620304"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
		 	return;
		}else{
		 	if(data.rows==undefined) data.rows=[]
		 	var cp={}
		 	$.each(data.rows,function(k,v){
		 		cp[v.INST_ID]=v.LAST_NET
		 	})
		 	glob.cpjz=cp
		}
	}
	get_Cpzzrq()
}

function get_Cpzzrq(){

	setIX({"funcid":"L2612011","funcname":'ret_Cpzzrq',"ISS_CODE":"","INST_CODE":"","INST_ID":"","INST_TYPE":"","INST_CLS":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}
function ret_Cpzzrq(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2612011"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
		 	return;
		}else{
		 	if(data.rows==undefined) data.rows=[]
		 	var rq={}
			 var rq2={}
		 	$.each(data.rows,function(k,v){
		 		rq[v.INST_ID]=v.END_DATE
		 		rq2[v.INST_ID]=v.TA_CODE
		 	})
		 	glob.zzrq=rq
		 	glob.djjg=rq2
		}
	}
	get_Cpfe()
}

//请求产品份额
function get_Cpfe(){

	setIX({"funcid":"L2620200","funcname":'ret_Cpfe',"CUST_CODE":User.khh,"TA_ACCT":"","CUACCT_CODE":"","ISS_CODE":"","INST_CODE":"","INST_ID":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_Cpfe(_fromid,_funid,_flagtype,data){
	
	if(_funid=="5010:SIMPLE.L2620200"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
		 	return;
		}else{
			if(data.rows==undefined) data.rows=[]
		 	for(var i=0;i<data.rows.length;i++){
		 		if(glob.cpjz[data.rows[i].INST_ID]==undefined)
		 			data.rows[i].LAST_NET=""
		 		else
		 			data.rows[i].LAST_NET=glob.cpjz[data.rows[i].INST_ID]
		 		if(glob.zzrq[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].END_DATE=""
			 	else
			 		data.rows[i].END_DATE=glob.zzrq[data.rows[i].INST_ID]
			 	if(glob.zzrq[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].TA_CODE=""
			 		else			 		
			 			data.rows[i].TA_CODE=glob.djjg[data.rows[i].INST_ID]
		 	}
		 	upDate("load",data)
		}
	}
}
function onDblClickRow(rowindex,rowdata){
	$("#inst_code").attr("value",rowdata.INST_CODE)
	$("#inst_name").attr("value",rowdata.INST_SNAME)
	$("#ksfe").attr("value",rowdata.INST_AVL)
	$("#instjz").attr("value",rowdata.ISS_CODE)
	glob.cpbm=rowdata.INST_ID
	glob.fxrdm=rowdata.ISS_CODE
	glob.cpcode=rowdata.INST_CODE
	glob.cpname=rowdata.INST_SNAME
	glob.djjg=rowdata.TA_CODE
	CpFxdj = rowdata.RISK_LVL
	bFxts = false;
	get_CCCXInfo();
	//get_FXCPInfo()

}



//查询客户风险等级信息
function get_CCCXInfo(){
	
	setIX({"funcid":"L2610003","funcname":'ret_CCCXInfo',"CUST_CODE":User.khh})
}
//应答产品信息
function ret_CCCXInfo(_fromid,_funid,_flagtype,data){
	
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]		
	 	
	 	
	 	var num=0;
		var tmpEval_Date="";


		for(var i=0;i<data.rows.length;i++)
		{
			if (i==0)
			{
				tmpEval_Date=data.rows[0].EVAL_DATE;// 测评日期
			};
			Cprq=data.rows[i].EVAL_DATE;// 测评日期
			if (Cprq>=tmpEval_Date)
			{
				tmpEval_Date=Cprq;
				num=i;
			};
		}

	 
	 	
	 	KhFxdj=data.rows[num].EVAL_LVL;
		KhFxdjmc=get_KhRiskLvl(data.rows[num].EVAL_LVL);

		Cprq=data.rows[num].EVAL_DATE;// 测评日期
	 	Cpyxrq=data.rows[num].VALID_DATE;// 有效日期




	}
}




function get_FXCPInfo(){
	setIX({"funcid":"99001120","funcname":'ret_fxcpinfo',"SURVEY_SN":configDcbdm,"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
	var sn="0";
	if (khlx=="0")// 0个人
	{
		sn="3";
	}
	else if (khlx=="1") // 1机构
	{
		sn="4";
	}
	//setIX({"funcid":"99001120","funcname":'ret_fxcpinfo',"SURVEY_SN":sn,"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
}
//应答资金信息
function ret_fxcpinfo(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){		
		
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
	 	
	 	KhFxdj=data.rows[0].RATING_LVL;
		KhFxdjmc=data.rows[0].RATING_LVL_NAME;
	}
}





function onAll(t){
	$("#wtsl").attr("value",$("#ksfe").attr("value"))
}

//确认认购
function onSubmit(t){
	
	if(isNullStr($("#inst_code").attr("value"))){
		proError("产品代码不能为空")
		return;
	}
	if(isNullStr($("#wtsl").attr("value"))){
		proError("请输入委托数量")
		return;
	}
	if(parseFloat($("#wtsl").attr("value"))>parseFloat($("#ksfe").attr("value"))){
		proInfo("委托数量不能大于可赎数量")
		return;
	}

	glob.wtsl=$("#wtsl").attr("value")
	glob.cpcode=$("#inst_code").attr("value")
	glob.cpname=$("#inst_name").attr("value")

	get_Xd()
}

function get_Xd(){


	$('#cdwt').dialog('open');

	$("#cpcode").text(glob.cpcode)

	$("#cpname").text(glob.cpname)

	$("#wtwtsl").text(glob.wtsl)

}
var listdata=selectRow("INST_CODE")
function CheckCode(name,node,e){
	bFxts = false;
	if(name=="keyup"){
		if($(node).attr('value').length==6){
			var value = listdata($(node).attr('value'),"load");
			if (value!=-1){
				$("#inst_name").attr("value",value[1]["INST_SNAME"])
				$("#instjz").attr("value",value[1]["LAST_NET"])
				$("#ksfe").attr("value",value[1].INST_AVL)
				glob.cpbm=rowdata.INST_ID
				glob.fxrdm=rowdata.ISS_CODE
				glob.cpcode=rowdata.INST_CODE
				glob.cpname=rowdata.INST_SNAME
				
				
			}else{
				proInfo("没有该产品信息，请重新输入产品代码")
				
	    		return;
			}
		}else{
			
			$("#ksfe").attr("value","")
			$("#inst_name").attr("value","")
			$("#instjz").attr("value","")
			$("#wtsl").attr("value","")
		}
	}
}

function onOk(){

	glob.dlgflag="0"
	$('#cdwt').dialog('close');
	//$('#cdSucwt').dialog('open');
	get_Djzh()
	// get_subXd()
}
function onCance(){
	$('#cdwt').dialog('close');
}

/*function OnSucWt(){
	$('#cdSucwt').dialog('close');
}*/
function onSinOk(){
	glob.dlgflag="1"
	$('#singlewt').dialog('close');
	//$('#cdSucwt').dialog('open');
	get_Djzh()
	//get_subXd()
}
function onSinCance(){
	$('#singlewt').dialog('close');	
}

function get_subXd(){

	var CurrDay=getCur();
	if (KhFxdj=="" || KhFxdj==undefined || KhFxdj==null)
	{
		alert("您的还未做风险测评，请在理财标签下的理财风险测评选择对应的机构进行评测");
		return;
	};
	if (Cpyxrq<CurrDay)
	{
		alert("您的风险测评已过期，请在理财标签下的理财风险测评选择对应的机构进行评测");
		return;
	};



	if ((KhFxdj<CpFxdj) && (bFxts == false) )
	{
		var obj = document.getElementById("total2")		


		obj.innerHTML="根据您的风险测评结果，您的风险承受能力级别为"+KhFxdjmc+"，您与该产品的风险等级不匹配。<br>我们需要提醒您，如果购买与风险不匹配的产品，可能使您遭受超出风险承受能力范围的损失。<br>请您确认：理解并愿意承担超限购买产品的风险，由此引起的一切损失及风险与本公司无关。"

		$('#singlewt2').dialog('open');			
		return
	};

	setIX({"funcid":"L2620101","funcname":'ret_subXd',"CUST_CODE":User.khh,"CUACCT_CODE":glob.zczh,"TA_CODE":glob.djjg,"TA_ACCT":glob.djzh,"TRANS_ACCT":glob.jyzh,
				"ISS_CODE":glob.fxrdm,"INST_CODE":"","INST_ID":glob.cpbm,"TRD_QTY":glob.wtsl,"CNTR_NO":"","CNTR_REG_DATE":"","BIG_RED_FLAG":""})

}
function ret_subXd(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2620101"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{
			proInfo("委托已提交,委托编号:"+data.rows[0].APP_SNO)
			$("#wtsl").attr("value","")
			$("#ksfe").attr("value","")
			$("#instjz").attr("value","")
			$("#inst_name").attr("value","")
			$("#inst_code").attr("value","")



			get_Cpfe()
		}
	}
}




function onSinOk2(){
	bFxts = true;
	
	$('#singlewt2').dialog('close');
	get_subXd()
	
}
function onSinCance2(){
	bFxts = true;
	
	$('#singlewt2').dialog('close');
	get_subXd()	
}



function fmtFt(f){
	f=parseFloat(f)
	return isNaN(f)?0:f
}
