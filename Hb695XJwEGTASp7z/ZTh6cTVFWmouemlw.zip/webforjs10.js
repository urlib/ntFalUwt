var glob={
	"djzh":"",//登记账号
	"djjg":"",//登记机构
	"jyzh":"",//交易账号
	"zczh":"",//资产账户
	"yhdm":"",// 用户代码 
	"yhjs":"",// 用户角色
	"yhmc":"",// 用户名称 
	"yhlx":"",// 用户类型
	"jgdm":"",// 机构代码 
	"zjlx":"",// 证件类型 
	"zjhm":"",// 证件号码
	"fzjg":"",// 发证机关
	"yhqc":"",// 用户全称
	"yzbm":"",// 邮政编码 
	"lxdz":"",// 联系地址 
	"lxdh":"",// 联系电话 
	"czdh":"",// 传真电话 
	"dzyx":"",// 电子邮箱 
	"yddh":"",// 移动电话  
	"gj":"",// 国籍  
	"mz":"",// 民族 
	"xl":"",// 学历 
	"jg":"",// 籍贯/注册地 
	"xb":"",// 性别 
	"csrq":"",// 出生日期/注册日期
	"hyzk":"",// 婚姻状况 
	"xqah":"",// 兴趣爱好
	"bgdh":"",// 办公电话
	"bgdz":"",// 公司地址
	"zjyxrq":"" // 证件有效日期
}

function PageInit(){
	get_khxx()
}

// 获取客户信息
function get_khxx(){
	setIX({"funcid":"99001270","funcname":"ret_Khxx","USER_CODE":User.khh,"USER_ROLE":"1","OP_TYPE":"1"})
}

function ret_Khxx(_fromid,_funid,_flagtype,data){
	if (_funid=="5010:SIMPLE.99001270") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo);	
			}
			
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到客户基本资料");
				return;
			}else{				
				glob.yhdm=data.rows[0].USER_CODE
				glob.yhjs=data.rows[0].USER_ROLES
				glob.yhmc=data.rows[0].USER_NAME 
				glob.yhlx=data.rows[0].USER_TYPE
				glob.jgdm=data.rows[0].INT_ORG 
				glob.zjlx=data.rows[0].ID_TYPE
				glob.zjhm=data.rows[0].ID_CODE 
				glob.fzjg=data.rows[0].ID_ISS_AGCY
				glob.yhqc=data.rows[0].USER_FNAME
				glob.yzbm=data.rows[0].ZIP_CODE
				glob.lxdz=data.rows[0].ADDRESS
				glob.lxdh=data.rows[0].TEL
				glob.czdh=data.rows[0].FAX
				glob.dzyx=data.rows[0].EMAIL 
				glob.yddh=data.rows[0].MOBILE_TEL
				glob.gj=data.rows[0].CITIZENSHIP
				glob.mz=data.rows[0].NATIONALITY
				glob.xl=data.rows[0].EDUCATION
				glob.jg=data.rows[0].NATIVE_PLACE
				glob.xb=data.rows[0].SEX
				glob.csrq=data.rows[0].BIRTHDAY
				glob.hyzk=data.rows[0].MARRY
				glob.xqah=data.rows[0].AVOCATION
				glob.bgdh=data.rows[0].OFFICE_TEL
				glob.bgdz=data.rows[0].CORP_ADDR

			}
		}
	}

	$("#khh").attr("value",glob.yhdm)
	$("#name").attr("value",glob.yhmc)
	$("#email").attr("value",glob.dzyx)
	$("#id_kind").attr("value",get_idtype(glob.zjlx))
	$("#id_no").attr("value",glob.zjhm)
	$("#adder").attr("value",glob.lxdz)
	$("#phone").attr("value",glob.yddh)
	$("#post_no").attr("value",glob.yzbm)
	$("#tel").attr("value",glob.lxdh)
	$("#fax_tel").attr("value",glob.czdh)
	$("#national").attr("value",get_gj(glob.gj))
	$("#mz").attr("value",get_mz(glob.mz))
	$("#edu").attr("value",get_xl(glob.xl))
	$("#sex").attr("value",get_xb(glob.xb))

	get_Djzh()
}



//获取登记账号
function get_Djzh(){
	setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":User.khh,"CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_Djzh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610008"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{
					glob.djjg=data.rows[0].TA_CODE					
					glob.djzh=data.rows[0].TA_ACCT							
					glob.jyzh=data.rows[0].TRANS_ACCT
					glob.zczh=data.rows[0].CUACCT_CODE	
			}
		}
		// get_KhKyzj()
		//OnKh()
		
	}
}



//开户
function OnKh(){

	if(isNullStr($("#khh").attr("value")))
	{
		proError("客户号不能为空")
		return;
	}

	if(isNullStr($("#name").attr("value")))
	{
		proError("客户姓名不能为空")
		return;
	}
/*
	if(isNullStr($("#email").attr("value")))
	{
		proError("邮件地址不能为空")
		return;
	}*/

	if(isNullStr($("#id_kind").attr("value")))
	{
		proError("证件种类不能为空")
		return;
	}

	if(isNullStr($("#id_no").attr("value")))
	{
		proError("证件号码不能为空")
		return;
	}

	if(isNullStr($("#adder").attr("value")))
	{
		proError("联系地址不能为空")
		return;
	}

	if(isNullStr($("#phone").attr("value")))
	{
		proError("手机号码不能为空")
		return;
	}

	if(isNullStr($("#post_no").attr("value")))
	{
		proError("邮政编码不能为空")
		return;
	}

/*
	if(isNullStr($("#national").attr("value")))
	{
		proError("#国籍不能为空")
		return;
	}

	if(isNullStr($("#mz").attr("value")))
	{
		proError("民族不能为空")
		return;
	}
*/
	/*if(isNullStr($("#edu").attr("value")))
	{
		proError("#学历不能为空")
		return;
	}*/
/*
	if(isNullStr($("#sex").attr("value")))
	{
		proError("性别不能为空")
		return;
	}*/
/*
	var obj=document.getElementById('xl');
	var index=obj.selectedIndex; 
	glob.xl=obj.options[index].value;
	var obj2=document.getElementById('xb');
	var index2=obj2.selectedIndex; 
	glob.xb=obj.options[index2].value;*/

	get_zhzltbotcxt()
	//get_djzhwh()
}



function get_djzhwh(){
	

	setIX({"funcid":"99001334","funcname":'ret_djzhwh',"OPER_TYPE":"0","CUST_CODE":glob.yhdm,"CUACCT_CODE":glob.zczh,"OTC_CODE":glob.djjg,
		"OTC_ACCT":"","TRANS_ACCT":glob.jyzh,"ACCT_STAT":"","OPEN_DATE":"","CLOSE_DATE":""})

}


function ret_djzhwh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001334"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			if(data.rows==undefined) data.rows=[]	
			//proInfo("委托已提交")
			//get_zhzltbotcxt()			
		}
	}
}


// 账户资料同步OTC系统
function get_zhzltbotcxt(){	

	setIX({"funcid":"99001345","funcname":'ret_zhzltbotcxt',"CUST_CODE":glob.yhdm,"CUACCT_CODE":glob.zczh,"BANK_CODE":"",
		"BANK_ACCT ":"","PAY_WAY":"","PAY_ORG":"","OPERATION_TYPE":"0022"})

}


function ret_zhzltbotcxt(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001345"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			if(data.rows==undefined) data.rows=[]			
				proInfo("请求已提交")
		}
		get_djzhwh()
	}
}


/*

function get_subKh(){
	

	setIX({"funcid":"99001254","funcname":'ret_subKh',"CUST_CODE":glob.yhdm,"USER_NAME":glob.yhmc,"USER_TYPE ":glob.yhlx,"INT_ORG":glob.jgdm,"ID_TYPE":glob.zjlx,
				"ID_CODE":glob.zjhm,"USER_FNAME":glob.yhqc,"ID_ISS_AGCY":glob.fzjg,"ID_BEG_DATE":"","ID_EXP_DATE":glob.zjyxrq,"ID_ZIP_CODE":"","ID_ADDR":"","ZIP_CODE":glob.yzbm,
				"ADDRESS ":glob.lxdz,"TEL":glob.lxdh,"FAX ":glob.czdh,"EMAIL ":glob.dzyx,"MOBILE_TEL":glob.yddh,"CITIZENSHIP ":glob.gj,"NATIONALITY":glob.mz,"EDUCATION":glob.xl,"NATIVE_PLACE":glob.jg,
				"SEX":glob.xb,"BIRTHDAY":glob.csrq,"REMARK":"","MARRY":"","INTEREST":"","VEHICLE":"","HOUSE_OWNER":"","OFFICE_TEL":"","WELL_TEL":"",
				"LINKTEL_ORDER":"","OFFICE_ADDR":"","CORP_ADDR":"","LINKADDR_ORDER":"","CUST_CLS":"0","CUST_TYPE":"0","CHANNELS":"","CRITERION":"",
				"RISK_FACTOR":"","CREDIT_LVL":"","REMOTE_PROTOCOL":"","CUST_SOURCE":"","SERVICE_LVL":"","BSB_USER_FNAME":"","BSB_ID_TYPE":"","BSB_ID_CODE":"",
				"BSB_ID_EXP_DATE":"","CARD_ID":"","CHK_RIGHT_FLAG":"","AML_LVL":"","FILINGCABINET_NO":"","CUST_GRP":"","IDCARD_TYPE":"",
				"IDCARD_CHECK_FLAG":"","SUBSYS":""})

}


function ret_subKh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001254"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			proInfo("委托已提交")			
		}
	}
}

*/

function get_usertype(c)
{
	var usertype="";
	if(c=="0")
	{
		usertype="个人";
	}
	else if( c=="1" )
	{
		usertype="机构";
	}
	else if( c=="2")
	{
		usertype="设备";
	}
	return usertype;
}

function get_idtype(c)
{
	var idtype="";
	if(c=="00")
	{
		idtype="身份证";
	}
	else if( c=="01" )
	{
		idtype="护照";
	}
	else if( c=="02")
	{
		idtype="军官证";
	}
	else if( c=="03")
	{
		idtype="士兵证";
	}
	else if( c=="04")
	{
		idtype="港澳居民来往内地通行证";
	}
	else if( c=="05")
	{
		idtype="户口本";
	}
	else if( c=="06")
	{
		idtype="外国护照";
	}
	else if( c=="07")
	{
		idtype="其它";
	}
	else if( c=="08")
	{
		idtype="文职证";
	}
	else if( c=="09")
	{
		idtype="警官证";
	}
	else if( c=="0A")
	{
		idtype="台胞证";
	}
	else if( c=="10")
	{
		idtype="组织机构代码证";
	}
	else if( c=="11")
	{
		idtype="营业执照";
	}
	else if( c=="12")
	{
		idtype="行政机关";
	}
	else if( c=="13")
	{
		idtype="社会团体";
	}
	else if( c=="14")
	{
		idtype="军队";
	}
	else if( c=="15")
	{
		idtype="武警";
	}
	else if( c=="16")
	{
		idtype="下属机构";
	}
	else if( c=="17")
	{
		idtype="基金会";
	}
	else if( c=="18")
	{
		idtype="其它";
	}
	return idtype;
}

function get_gj(c)
{
	var gj="";
	if(c=="AUS")
	{
		gj="澳大利亚";
	}
	else if( c=="CAF" )
	{
		gj="中非";
	}
	else if( c=="CAN")
	{
		gj="加拿大";
	}
	else if( c=="CHN")
	{
		gj="中国";
	}
	else if( c=="CTN")
	{
		gj="中国台湾";
	}
	else if( c=="DEU")
	{
		gj="德国";
	}
	else if( c=="ESP")
	{
		gj="西班牙";
	}
	else if( c=="FRA")
	{
		gj="法国";
	}
	else if( c=="GBR")
	{
		gj="英国";
	}
	else if( c=="HKG")
	{
		gj="香港";
	}
	else if( c=="JPN")
	{
		gj="日本";
	}
	else if( c=="MAC")
	{
		gj="澳门";
	}
	else if( c=="USA")
	{
		gj="美国";
	}
	return gj;
}

function get_mz(c)
{
	var mz="";
	if(c=="00")
	{
		mz="汉族";
	}
	else if( c=="01" )
	{
		mz="蒙古族";
	}
	else if( c=="02")
	{
		mz="回族";
	}
	else if( c=="03")
	{
		mz="藏族";
	}
	else if( c=="04")
	{
		mz="维吾尔族";
	}
	else if( c=="05")
	{
		mz="苗族";
	}
	else if( c=="06")
	{
		mz="彝族";
	}
	else if( c=="07")
	{
		mz="壮族";
	}
	else if( c=="08")
	{
		mz="布依族";
	}
	else if( c=="09")
	{
		mz="朝鲜族";
	}
	else if( c=="10")
	{
		mz="满族";
	}
	else if( c=="11")
	{
		mz="侗族";
	}
	else if( c=="12")
	{
		mz="瑶族";
	}
	else if( c=="13")
	{
		mz="白族";
	}
	else if( c=="14")
	{
		mz="土家族";
	}
	else if( c=="15")
	{
		mz="哈尼族";
	}
	else if( c=="16")
	{
		mz="哈萨克族";
	}
	else if( c=="17")
	{
		mz="傣族";
	}
	else if( c=="18")
	{
		mz="黎族";
	}
	else if( c=="19")
	{
		mz="僳僳族";
	}
	else if( c=="20")
	{
		mz="佤族";
	}
	else if( c=="21")
	{
		mz="畲族";
	}
	else if( c=="22")
	{
		mz="高山族";
	}
	else if( c=="23")
	{
		mz="拉祜族";
	}
	else if( c=="24")
	{
		mz="水族";
	}
	else if( c=="25")
	{
		mz="东乡族";
	}
	else if( c=="26")
	{
		mz="纳西族";
	}
	else if( c=="27")
	{
		mz="景颇族";
	}
	else if( c=="28")
	{
		mz="柯尔克孜族";
	}
	else if( c=="29")
	{
		mz="土族";
	}
	else if( c=="30")
	{
		mz="达斡尔族";
	}
	else if( c=="31")
	{
		mz="仫佬族";
	}
	else if( c=="32")
	{
		mz="羌族";
	}
	else if( c=="33")
	{
		mz="布朗族";
	}
	else if( c=="34")
	{
		mz="撒拉族";
	}
	else if( c=="35")
	{
		mz="毛南族";
	}
	else if( c=="36")
	{
		mz="仡佬族";
	}
	else if( c=="37")
	{
		mz="锡伯族";
	}
	else if( c=="38")
	{
		mz="阿昌族";
	}
	else if( c=="39")
	{
		mz="普米族";
	}
	else if( c=="40")
	{
		mz="塔吉克族";
	}
	else if( c=="41")
	{
		mz="怒族";
	}
	else if( c=="42")
	{
		mz="乌孜别克族";
	}
	else if( c=="43")
	{
		mz="俄罗斯族";
	}
	else if( c=="44")
	{
		mz="鄂温克族";
	}
	else if( c=="45")
	{
		mz="德昂族";
	}
	else if( c=="46")
	{
		mz="保安族";
	}
	else if( c=="47")
	{
		mz="裕固族";
	}
	else if( c=="48")
	{
		mz="京族";
	}
	else if( c=="49")
	{
		mz="塔塔尔族";
	}
	else if( c=="50")
	{
		mz="独龙族";
	}
	else if( c=="51")
	{
		mz="鄂伦春族";
	}
	else if( c=="52")
	{
		mz="赫哲族";
	}
	else if( c=="53")
	{
		mz="门巴族";
	}
	else if( c=="54")
	{
		mz="珞巴族";
	}
	else if( c=="55")
	{
		mz="基诺族";
	}
	else if( c=="56")
	{
		mz="其它";
	}
	return mz;
}

function get_xl(c)
{
	var xl="";
	if( c=="0" )
	{
		xl="博士";
	}
	else if(c=="1")
	{
		xl="硕士";
	}
	else if(c=="2")
	{
		xl="学士";
	}
	else if(c=="3")
	{
		xl="大专";
	}
	else if(c=="4")
	{
		xl="中专";
	}
	else if(c=="5")
	{
		xl="高中";
	}
	else if(c=="6")
	{
		xl="初中及其以下";
	}
	else if(c=="7")
	{
		xl="其他";
	}
	return xl;
}

function get_xb(c)
{
	var xb="";

	if(c=="0")
	{
		xb="男性";
	}
	else if(c=="1")
	{
		xb="女性";
	}
	else if(c=="2")
	{
		xb="其他";
	}

	return xb;
}