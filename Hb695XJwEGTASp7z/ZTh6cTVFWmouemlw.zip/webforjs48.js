var glob={
	"djzh":"",//登记账号
	"djjg":"",//登记机构
	"jyzh":"",//交易账号
	"zczh":"",//资产账户
	"sqbh":null,//需要发送撤单的数据
	"wtflag":0,
	"cdcnt":0//撤单发送请求条数
}


function PageInit(){

	setDlg()
	setDlg("singlewt")
	//setDlg("cdSucwt")
	hideLoading()
	create_easygrid("电子约定书签署",{singleSelect:false,onDblClickRow:onDblClickRow},{"CONTRACT_CLS":{"formatter":get_xyzl},"SIGN_TYPE":{"formatter":get_qslx},"INST_TYPE":{"formatter":get_cpdl},"INST_CLS":{"formatter":get_cpzl}})
	// $("#load").datagrid("loadData",{"total":1,"rows":[{"ORD_AMT":"122"},{"ORD_AMT":"222"}]});
	get_KhdzydsInfo()
}

// 客户电子约定书信息查询
function get_KhdzydsInfo(){
	setIX({"funcid":"99001339","funcname":'ret_KhdzydsInfo',"SERIAL_NO":"","CONTRACT_CLS":"","VERSION":"","INT_ORG":"","ID_TYPE":"","ID_CODE":"","CUST_CODE":User.khh,
		"AGREEMENT_ID":"","INST_TYPE":"","INST_CLS":"","ISS_CODE":"","INST_CODE":"","INST_ID":"","EC_NO":""})
}

function ret_KhdzydsInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001339"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("没有查询数据")==-1)
			{
				if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
				{
					proInfo("您还未开设理财帐户，请先开户");
				}
				else
				{
					proError(data.ErrorInfo)	
				}
				//proInfo(data.ErrorInfo)
		 		return;
			}
			else
			{
				data.rows=[]
				upDate("load",data)
				$("#totalnum").text("共"+data.rows.length+"条")
				return;
			}
			
		}else{
			 if(data.rows==undefined) data.rows=[]
			 data.rows=$.grep(data.rows,function(v,i){
				if(v.CONTRACT_CLS=="201" || v.CONTRACT_CLS=="203"){					
					return v
				}
			})
		}

		upDate("load",data)
		$("#totalnum").text("共"+data.rows.length+"条")

	}
}

function onDblClickRow(rowindex,rowdata){
	$("#load").datagrid("uncheckAll")
	$("#load").datagrid("checkRow",rowindex)
	onSign(3)
}

var totalLen=0;
function onSign(i){
	
	if(i==0)
		get_KhdzydsInfo()
	else if(i==1)
		$("#load").datagrid("uncheckAll")
	else if(i==2)
		$("#load").datagrid("checkAll")
	else if(i==3){
		glob.wtflag=0		
		var rows=$("#load").datagrid("getChecked")	
		var len=rows.length
		if(len>1){
			totalLen=2;
			glob.sqbh=rows
			//$('#singlewt').dialog('open');
			$("#total").text("共有"+len+"份合同需要签署")
			glob.wtflag=2
			$('#singlewt2').dialog('open');
		}else{
			totalLen=1;
			glob.wtflag=1
			glob.sqbh=rows
		
			if(len<1)
			{
				glob.sqbh.length=1;
			}
			$('#singlewt2').dialog('open');
			/*$('#cdwt').dialog('open');
			$("#czfx").text(get_InstCls(rows[0].INST_CLS))
			$("#cpcode").text(rows[0].CUST_CODE)
			$("#cpname").text(get_qslx(rows[0].SIGN_TYPE))*/
			//$("#sigtext").text(rows[0].SIGN_TEXT)
		}/*else{
			glob.wtflag=0
			proInfo("请选择你需要签署电子约定书的产品")
			return
		}*/
	}

}

function onOk(){

	$('#cdwt').dialog('close');
	//$('#cdSucwt').dialog('open');
	glob.cdcnt=0

	get_Qy()
	
}
function onCance(){
	$('#cdwt').dialog('close');
	
}

function onSinOk(){
	$('#singlewt').dialog('close');
	//$('#cdSucwt').dialog('open');
	glob.cdcnt=0
	get_Qy()
	
}
function onSinCance(){
	$('#singlewt').dialog('close');
}


function onSinOk2(){
	var rows=$("#load").datagrid("getChecked")
	$('#singlewt2').dialog('close');

	if (totalLen==2)
	{
		$('#singlewt').dialog('open');
	}
	else if (totalLen==1)
	{
		$('#cdwt').dialog('open');
		//$("#czfx").text(get_InstCls(rows[0].INST_CLS))
		//$("#cpcode").text(rows[0].CUST_CODE)
		//$("#cpname").text(get_qslx(rows[0].SIGN_TYPE))
	}

	
	
}
function onSinCance2(){
	$('#singlewt2').dialog('close');
}

/*function OnSucWt(){
	$('#cdSucwt').dialog('close');
	glob.cdcnt=0
	get_Qy()
	
}*/

//撤单
var totalUse=0;
function get_Qy(){
	var contact="";
	if(totalUse==1)
	{	
		contact="203"
	}
	else
	{
		contact="201"
	}



	if(glob.cdcnt<glob.sqbh.length){

		totalUse++;
		
		setIX({"funcid":"99001338","funcname":'ret_Qy',"CONTRACT_CLS":contact,"VERSION":"1","ID_TYPE":"",
			"ID_CODE":"","CUST_CODE":User.khh,"SIGN_ORG":"0","SIGN_TYPE":"0",
			"SIGN_TEXT":"","SIGN_EXINFO":"","STRING":"","REMARK":"","AGREEMENT_ID":"",
			"INST_TYPE":"","INST_CLS":"","ISS_CODE":"","INST_CODE":"",
			"INST_ID":"","EC_NO":""})
		glob.cdcnt+=1;
	}else{
		proInfo("已提交")
		get_KhdzydsInfo()
		//get_khzlTbOtc()
		return
	}

}
function ret_Qy(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001338"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{	
			if (totalUse==1)
			{
				glob.cdcnt-=1;
			}	
			get_Qy()
		}
	}
}


//请求资金信息
function get_khzlTbOtc(){
	setIX({"funcid":"99001341","funcname":'ret_khzlTbOtc',"CUST_CODE":User.khh,"CUACCT_CODES":"","OPERATION_TYPE":"12222"})
}
//应答资金信息
function ret_khzlTbOtc(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
			get_KhdzydsInfo()
	 	
	}
}