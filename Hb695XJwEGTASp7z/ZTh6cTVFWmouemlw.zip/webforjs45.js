
function PageInit(){	
	
	hideLoading()	
	create_easygrid("当日成交查询",{},{"TRD_ID":{"formatter":get_TradId}})
	 get_CJCXInfo()
}

//请求产品信息
function get_CJCXInfo(){
	var start=$("#sdate").attr("value")
	var end=$("#edate").attr("value")
	setIX({"funcid":"L2620125","funcname":'ret_CJCXInfo',"BGN_DATE":getCur(),"END_DATE":getCur(),"CUST_CODE":User.khh,"CUACCT_CODE":'',
		"CURRENCY":'',"TA_ACCT":'',"ISS_CODE":'',"INST_CODE":'',"INST_ID":'',"APP_SNO":'',"PAGE_RECNUM":'0',"PAGE_RECCNT":'500'})
}
//应答产品信息
function ret_CJCXInfo(_fromid,_funid,_flagtype,data){
	hideLoading()	
	if(_funid=="5010:SIMPLE.L2620125"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			$("#total").text("共0条")
		 	return;
		}else{
		 	if(data.rows==undefined) data.rows=[]
	 		$("#total").text("共"+data.rows.length+"条")
	 	
	 		upDate("load",data)
		}
	}
}


function fmtDt(d){
	var dl=d.split("-")
	
	if(dl.length!=3)
		return ""
	var fl=$.map(dl,function(val){
		return sigtodow(parseInt(val))
	})
	return fl.join('')
	
}
function onQuery(){
	get_CJCXInfo()
}
// 交易类别
function get_TradId(c){
	var stat=""
	if(c=="001")
		stat="开户"
	else if(c=="002")
		stat="销户"
	else if(c=="003")
		stat="变更"
	else if(c=="008")
		stat="注册"
	else if(c=="110")
		stat="认购"	
	else if(c=="111")
		stat="申购"
	else if(c=="112")
		stat="赎回"
	else if(c=="20B")
		stat="买入"
	else if(c=="20S")
		stat="卖出"
	return stat
}