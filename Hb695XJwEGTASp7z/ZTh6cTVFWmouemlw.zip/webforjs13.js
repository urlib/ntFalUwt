var glob={
	"khdm":"",// 客户代码
	"khxm":"",// 客户姓名
	"zjlx":"",// 证件类型
	"zjhm":"",// 证件号码
	"lxdh":""// 联系电话
}
var glob2={
	"zczh":[],// 资产账号
	"djjg":[],// 登记机构
	"djzh":[],// 登记账号
	"jyzh":[]// 交易账号
}
var glob3={
	"zczh":[],// 资产账号
	"zfjg":[],// 支付机构
	"zfzh":[],// 支付账号
	"yhdm":[],// 银行代码
	"yhzh":[]// 银行账号
}

var totalNum=0;
var totalNum2=0;
var zffs="";
var zfjg="";
var yhdm="";
var zfzh="";
var yhzh="";
var czlx="";
var djjg="";
var jyzh="";
var zczh="";
var numIndex=0;

function PageInit(){
	get_khxx()
}

// 获取客户信息
function get_khxx(){
	setIX({"funcid":"99001270","funcname":"ret_Khxx","USER_CODE":User.khh,"USER_ROLE":"1","OP_TYPE":"1"})
}

function ret_Khxx(_fromid,_funid,_flagtype,data){
	if (_funid=="5010:SIMPLE.99001270") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到客户基本资料");
				return;
			}else{				
				glob.khdm=data.rows[0].USER_CODE
				glob.khxm=data.rows[0].USER_NAME
				glob.zjlx=data.rows[0].ID_TYPE 
				glob.zjhm=data.rows[0].ID_CODE 
				glob.lxdh=data.rows[0].TEL 	
			}
		}
	}

	$("#khh").attr("value",glob.khdm)
	$("#khmc").attr("value",glob.khxm)	
	$("#zjlx").attr("value",get_idtype(glob.zjlx))
	$("#zjhm").attr("value",glob.zjhm)
	$("#lxdh").attr("value",glob.lxdh)

	get_Djzh()
}



//获取登记账号
function get_Djzh(){
	setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":User.khh,"CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_Djzh(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.L2610008"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{
				
				for(var i=0; i<data.rows.length; i++)
				{
					totalNum2++;				
					glob2.zczh[i]=data.rows[i].CUACCT_CODE;
					glob2.djjg[i]=data.rows[i].TA_CODE;
					glob2.djzh[i]=data.rows[i].TA_ACCT;
					glob2.jyzh[i]=data.rows[i].TRANS_ACCT;

				}
					
			}
		}
	
		var obj2=document.getElementById('djjg');
		var jsonObj2=[];
		for(var k=0; k<data.rows.length; k++)
		{
			jsonObj2[k]={id:k,value:glob2.djjg[k]};		
			
		}
		for(var e=0; e<jsonObj2.length; e++)
		{
			obj2.add(new Option(jsonObj2[e].value,jsonObj2[e].id))
		}
			get_Zfzhinfo()				
		}
}

//查询客户签约信息
function get_Zfzhinfo(){
	setIX({"funcid":"99001262","funcname":'ret_Zfzhinfo',"CUACCT_CODE":"","CUST_CODE":User.khh,"FISL":"","CURRENCY":"0"})
}

function ret_Zfzhinfo(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.99001262"){
	
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{
			
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{

				for(var i=0; i<data.rows.length; i++)
				{					
					totalNum++;	
					glob3.zfzh[i]=data.rows[i].CUACCT_CODE;
					glob3.yhdm[i]=data.rows[i].EXT_ORG;
					glob3.yhzh[i]=data.rows[i].BANK_ACCT;
					
				}
					
			}
		}
	
		var obj2=document.getElementById("yhdm");
		var jsonObj=[];
		for(var j=0; j<data.rows.length; j++)
		{	
			jsonObj[j]={id:j,value:glob3.yhdm[j]};	
		}
		for(var e=0; e<jsonObj.length; e++)
		{
			obj2.add(new Option(jsonObj[e].value,jsonObj[e].id))
		}
			
		$("#yhzh").attr("value",glob3.yhzh[0]);
		$("#zfzh").attr("value",glob3.zfzh[0]);
		
		get_Zfjginfo()
	}
}

//特殊机构查询
function get_Zfjginfo(){
	setIX({"funcid":"99001350","funcname":'ret_Zfjginfo',"INT_ORG":"","SPEC_ORG_CODE":"","SPEC_ORG_TYPE":""})
}

function ret_Zfjginfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001350"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{

				for(var i=0; i<data.rows.length; i++)
				{
					
					glob3.zfjg[i]=data.rows[i].SPEC_ORG_SNAME;					

				}
					
			}
		}
	
		var obj2=document.getElementById("zfjg");
		var jsonObj=[];
		for(var j=0; j<data.rows.length; j++)
		{	
			jsonObj[j]={id:j,value:glob3.zfjg[j]};	
		}
		for(var e=0; e<jsonObj.length; e++)
		{
			obj2.add(new Option(jsonObj[e].value,jsonObj[e].id))
		}		
		
	}
}



//清除数据
function OnCleanUp(){	
	$("#lxdh").attr("value","");
	$("#zfzh").attr("value","");
	$("#yhzh").attr("value","");

}

//开户
function OnTj(){

	if(isNullStr($("#lxdh").attr("value")))
	{
		proError("联系电话不能为空")
		return;
	}

	if(isNullStr($("#zfzh").attr("value")))
	{
		proError("支付账号不能为空")
		return;
	}
	if(isNullStr($("#yhzh").attr("value")))
	{
		proError("银行账号不能为空")
		return;
	}

	var obj4=document.getElementById('djjg');
	for(var j = 0 ; j < obj4.options.length;j++)
	{
		if(obj4.options[j].selected)
		{			
			zczh=glob2.zczh[j]
			djjg=glob2.djjg[j]
			jyzh=glob2.jyzh[j]
			break;
		}
	}

	var obj = document.getElementById("zffs")
	var index = obj.selectedIndex;
	zffs=obj.options[index].value;
/*
	var obj1 = document.getElementById("zfjg")
	var index1 = obj1.selectedIndex;
	numIndex = index1;
	zfjg = obj1.options[index1].value;

	var obj2 = document.getElementById("yhdm")
	var index2= obj2.selectedIndex;
	yhdm = obj2.options[index2].value;*/

	var obj3 = document.getElementById("czlx")
	var index3 = obj3.selectedIndex;
	czlx = obj3.options[index3].value;
/*
	zfzh=$("#zfzh").attr("value");
	yhzh=$("#yhzh").attr("value");*/

	/*for( var k=0; k<totalNum2; k++ )
	{
		if (glob2.zczh[k]==glob3.zczh[numIndex]) 
		{
			djjg = glob2.djjg[k];
			jyzh = glob2.jyzh[k];
			break;
		}
	}*/

	get_zhzltbotcxt()
	
}


// 账户资料同步OTC系统
function get_zhzltbotcxt(){		
	var typeinfo="";
	if(czlx==0)
	{
		typeinfo="222202";
	}
	else
	{
		typeinfo="222212"; 
	}

	setIX({"funcid":"99001345","funcname":'ret_zhzltbotcxt',"CUST_CODE":glob.khdm,"CUACCT_CODES":zczh,"BANK_CODE":"",
		"BANK_ACCT ":"","PAY_WAY":zffs,"PAY_ORG":"","OPERATION_TYPE":typeinfo})

}


function ret_zhzltbotcxt(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001345"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			if(data.rows==undefined) data.rows=[]			
				proInfo("请求已提交")
		}
		get_djzhwh()
	}
}



function get_djzhwh(){
	

	setIX({"funcid":"99001334","funcname":'ret_djzhwh',"OPER_TYPE":czlx,"CUST_CODE":glob.khdm,"CUACCT_CODE":zczh,"OTC_CODE":djjg,
		"OTC_ACCT":"","TRANS_ACCT":jyzh,"ACCT_STAT":"","OPEN_DATE":"","CLOSE_DATE":""})

}


function ret_djzhwh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001334"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			if(data.rows==undefined) data.rows=[]	
			//proInfo("委托已提交")
			//get_zhzltbotcxt()			
		}
	}
}



function get_usertype(c)
{
	var usertype="";
	if(c=="0")
	{
		usertype="个人";
	}
	else if( c=="1" )
	{
		usertype="机构";
	}
	else if( c=="2")
	{
		usertype="设备";
	}
	return usertype;
}

function get_idtype(c)
{
	var idtype="";
	if(c=="00")
	{
		idtype="身份证";
	}
	else if( c=="01" )
	{
		idtype="护照";
	}
	else if( c=="02")
	{
		idtype="军官证";
	}
	else if( c=="03")
	{
		idtype="士兵证";
	}
	else if( c=="04")
	{
		idtype="港澳居民来往内地通行证";
	}
	else if( c=="05")
	{
		idtype="户口本";
	}
	else if( c=="06")
	{
		idtype="外国护照";
	}
	else if( c=="07")
	{
		idtype="其它";
	}
	else if( c=="08")
	{
		idtype="文职证";
	}
	else if( c=="09")
	{
		idtype="警官证";
	}
	else if( c=="0A")
	{
		idtype="台胞证";
	}
	else if( c=="10")
	{
		idtype="组织机构代码证";
	}
	else if( c=="11")
	{
		idtype="营业执照";
	}
	else if( c=="12")
	{
		idtype="行政机关";
	}
	else if( c=="13")
	{
		idtype="社会团体";
	}
	else if( c=="14")
	{
		idtype="军队";
	}
	else if( c=="15")
	{
		idtype="武警";
	}
	else if( c=="16")
	{
		idtype="下属机构";
	}
	else if( c=="17")
	{
		idtype="基金会";
	}
	else if( c=="18")
	{
		idtype="其它";
	}
	return idtype;
}

