var glob={
	"djzh":"",//登记账号
	"djjg":"",//登记机构
	"jyzh":"",//交易账号
	"zczh":"",//资产账户
	"sqbh":null,//需要发送撤单的数据
	"wtflag":0,
	"cdcnt":0//撤单发送请求条数
}

function PageInit(){

	setDlg()
	setDlg("singlewt")
	//setDlg("cdSucwt")
	hideLoading()
	create_easygrid("撤单",{singleSelect:false,onDblClickRow:onDblClickRow},{"ORD_STAT":{"formatter":get_orderstatus},"TRD_ID":{"formatter":get_TraType}})
	// $("#load").datagrid("loadData",{"total":1,"rows":[{"ORD_AMT":"122"},{"ORD_AMT":"222"}]});
	get_Djzh()
}

//获取登记账号
function get_Djzh(){
	setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":"","CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
	
}

function ret_Djzh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610008"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{
				glob.djzh=data.rows[0].TA_ACCT
				glob.djjg=data.rows[0].TA_CODE
				glob.jyzh=data.rows[0].TRANS_ACCT
				glob.zczh=data.rows[0].CUACCT_CODE
			}
		}
		get_RsgInfo()
	}
}
//认申购查询
function get_RsgInfo(){
	setIX({"funcid":"L2620105","funcname":'ret_RsgInfo',"BGN_DATE":getAddMonth(-2),"END_DATE":getCur(),"CUST_CODE":User.khh,"CUACCT_CODE":"","TA_ACCT":"","TRANS_ACCT":"","ISS_CODE":"",
		"INST_CODE":"","INST_ID":"","APP_SNO":"","CAN_CANCEL":"1","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_RsgInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2620105"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
		 	return;
		}else{
			 if(data.rows==undefined) data.rows=[]
		 	 $("#load").datagrid("loadData",{"total":1,"rows":data.rows});
		 	$("#totalnum").text("共"+data.rows.length+"条")
		}
	}
}

function onDblClickRow(rowindex,rowdata){
	$("#load").datagrid("uncheckAll")
	$("#load").datagrid("checkRow",rowindex)
	onSign(3)
}

function onSign(i){
	
	if(i==0)
		get_RsgInfo()
	else if(i==1)
		$("#load").datagrid("uncheckAll")
	else if(i==2)
		$("#load").datagrid("checkAll")
	else if(i==3){
		glob.wtflag=0
		var rows=$("#load").datagrid("getChecked")
		var len=rows.length
		if(len>1){
			glob.sqbh=rows
			$('#singlewt').dialog('open');
			$("#total").text("共有"+len+"笔委托需要撤单")
			glob.wtflag=2
		}else if(len==1){
			glob.wtflag=1
			glob.sqbh=rows
			$('#cdwt').dialog('open');
			$("#czfx").text(get_TraType(rows[0].TRD_ID))
			$("#cpcode").text(rows[0].INST_CODE)
			$("#cpname").text(rows[0].INST_SNAME)

			glob.zczh=rows[0].CUACCT_CODE
			glob.djzh=rows[0].TA_ACCT
			glob.jyzh=rows[0].TRANS_ACCT

		}else{
			glob.wtflag=0
			proInfo("请选择你需要撤销的产品代码")
			return
		}
	}

}

function onOk(){

	$('#cdwt').dialog('close');
	//$('#cdSucwt').dialog('open');
	glob.cdcnt=0
	get_Cd()
	
}
function onCance(){
	$('#cdwt').dialog('close');
	
}

function onSinOk(){
	$('#singlewt').dialog('close');
	//$('#cdSucwt').dialog('open');
	glob.cdcnt=0
	get_Cd()
	
}
function onSinCance(){
	$('#singlewt').dialog('close');
}

/*function OnSucWt(){
	$('#cdSucwt').dialog('close');
	glob.cdcnt=0
	get_Cd()
	
}*/
var Wtbh="";
//撤单
function get_Cd(){

	if(glob.cdcnt<glob.sqbh.length){
		
//		setIX({"funcid":"L2620102","funcname":'ret_CdInfo',"CUST_CODE":User.khh,"CUACCT_CODE":glob.zczh,"TA_ACCT":glob.djzh,"TRANS_ACCT":glob.jyzh,"ORI_APP_DATE":glob.sqbh[glob.cdcnt].APP_DATE,"ORI_APP_SNO":glob.sqbh[glob.cdcnt].APP_SNO})
		setIX({"funcid":"L2620102","funcname":'ret_CdInfo',"CUST_CODE":User.khh,"CUACCT_CODE":glob.sqbh[glob.cdcnt].CUACCT_CODE,"TA_ACCT":glob.sqbh[glob.cdcnt].TA_ACCT,"TRANS_ACCT":glob.sqbh[glob.cdcnt].TRANS_ACCT,"ORI_APP_DATE":glob.sqbh[glob.cdcnt].APP_DATE,"ORI_APP_SNO":glob.sqbh[glob.cdcnt].APP_SNO})
		glob.cdcnt+=1;
	}else{
		proInfo("撤单已提交,委托编号:"+Wtbh);
		get_RsgInfo()
		return
	}
}
function ret_CdInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2620102"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{
			Wtbh=data.rows[0].APP_SNO;			
			get_Cd()
		}
	}
}
