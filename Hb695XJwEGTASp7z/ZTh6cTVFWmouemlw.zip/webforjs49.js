﻿var glob={
	"djzh":"",//登记账号
	"djjg":"",//登记机构
	"jyzh":"",//交易账号
	"zczh":"",//资产账户
	"sqbh":null,//需要发送撤单的数据
	"wtflag":0,
	"cdcnt":0//撤单发送请求条数
}

var glob3={
	"dcbbm":"",//调查表编码
	"cpfxdj":"",//产品风险等级
	"pjjb":""//评级级别	
}

var glob4={
	"dzhtbh":"",//电子合同编号
	"qsrq":"",//签署日期
	"cpdm":"",//产品代码
	"yxrq":""//有效日期	
}

var khlx="";
var KhFxdjmc="";

var configDcbdm="";

var totalCodeNum=0;
var totalRecord=0;
var num=0;
var codeNum="";
var glob2={
	"cpdm":[],// 产品代码
	"cpwjmc":[],// 产品文件名称
	"url1":[],// URL1
	"url2":[],// URL2
	"url3":[],// URL3
	"url4":[]// URL4
};

var IssCode="";
var Instcode="";
var InstId="";


function PageInit(){

	setDlg()
	setDlg("singlewt")
	//setDlg("cdSucwt")
	hideLoading()
	create_easygrid("电子合同签署",{singleSelect:true/*,onDblClickRow:onDblClickRow*/},{"ISS_STAT":{"formatter":get_Stat},"MGR_STAT":{"formatter":get_MgrStat},"RISK_LVL":{"formatter":get_RiskLvl}})
	// $("#load").datagrid("loadData",{"total":1,"rows":[{"ORD_AMT":"122"},{"ORD_AMT":"222"}]});
	//get_KhdzydsInfo()

	getTotalNum()
	//get_KhInfo()
}






// 客户信息查询接口
function get_KhInfo(){
	setIX({"funcid":"L2610002","funcname":'ret_KhInfo',"CUST_CODE":User.khh,"CUST_TYPE":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_KhInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610002"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			
		 	return;
		}
		else
		{
			if(data.rows==undefined) data.rows=[];
			
			khlx=data.rows[0].CUST_TYPE;
		}
	
		
		}
		getTotalNum()
}









/*获取配置文件配置的获取协议书数量*/
function getTotalNum(){

	//获取协议书数量
	var _ix = new IXContent();
	_ix.Set("key", "LccpCode_Num")
	Win_CallTQL('ret_getTotalNum', 'gettradeccf', _ix ,'');
}

function ret_getTotalNum(_fromid,_funid,_flagtype,_json) 
{

	totalCodeNum = _json;
		
	for(var i=1; i<=totalCodeNum; i++)
	{
		getCode(i)
		getCodeName(i)
		getURl1(i)
		getURl2(i)
		getURl3(i)
		//getURl4(i)
		num++;
	}

	get_Khdzhtxx()
	//get_CpInfo()
}


/*获取配置文件配置的柜员代码*/
function getDcbbm(){
	//获取柜员代码
	
	var _ix = new IXContent();
	_ix.Set("key", "dcbbm")
	Win_CallTQL('ret_getDcbbm', 'gettradeccf', _ix ,'');
}

function ret_getDcbbm(_fromid,_funid,_flagtype,_json) 
{
	configDcbdm = _json;

	//get_Khfxxx()
}



/*获取配置文件配置的理财产品代码*/
function getCode(c){
	
	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c;
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getCode', 'gettradeccf', _ix ,'');
}

function ret_getCode(_fromid,_funid,_flagtype,_json) 
{

	glob2.cpdm[num]=_json

	
}

/*获取配置文件配置的URL产品名称*/
function getCodeName(c){
	
	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCodeName_"+c;
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getCodeName', 'gettradeccf', _ix ,'');
}

function ret_getCodeName(_fromid,_funid,_flagtype,_json) 
{

	glob2.cpwjmc[num]=_json

	
}


/*获取配置文件配置的柜员代码*/
function getURl1(c){

	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c+"_URL1";
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getURl1', 'gettradeccf', _ix ,'');
}

function ret_getURl1(_fromid,_funid,_flagtype,_json) 
{

	glob2.url1[num]=_json;

}


/*获取配置文件配置的柜员代码*/
function getURl2(c){

	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c+"_URL2";
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getURl2', 'gettradeccf', _ix ,'');
}

function ret_getURl2(_fromid,_funid,_flagtype,_json) 
{

	glob2.url2[num]=_json;

}

/*获取配置文件配置的柜员代码*/
function getURl3(c){
	
	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c+"_URL3";
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getURl3', 'gettradeccf', _ix ,'');
}

function ret_getURl3(_fromid,_funid,_flagtype,_json) 
{
	
	glob2.url3[num]=_json;
		
}

/*获取配置文件配置的柜员代码*/
/*function getURl4(c){
	
	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c+"_URL4";
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getURl4', 'gettradeccf', _ix ,'');
}

function ret_getURl4(_fromid,_funid,_flagtype,_json) 
{
	
	glob2.url4[num]=_json;
	
}
*/


//获取客户电子合同信息
function get_Khdzhtxx(){
	
	setIX({"funcid":"L2610005","funcname":'ret_Khdzhtxx',"CUST_CODE":User.khh,"ISS_CODE":"","INST_CODE":"","INST_ID":""})
}
function ret_Khdzhtxx(_fromid,_funid,_flagtype,data){
	
	if(_funid=="5010:SIMPLE.L2610005"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			
		}else{
		 	if(data.rows==undefined) data.rows=[]
		 	var rq={}
		 	var rq2={}
		 	var rq3={}
		 	var rq4={}
		 	$.each(data.rows,function(k,v){
		 		rq[v.INST_ID]=v.EC_NO
		 		rq2[v.INST_ID]=v.SIGN_TYPE
		 		rq3[v.INST_ID]=v.VALID_DATE
		 		rq4[v.INST_ID]=v.INST_CODE
		 	

		 	})
		 	glob4.dzhtbh=rq
		 	glob4.qsrq=rq2		 	
		 	glob4.yxrq=rq3
		 	glob4.cpdm=rq4
		 
		}
	}
	
	get_CpInfo()
}




//获取产品信息
function get_CpInfo(){
	
	setIX({"funcname":'ret_CpInfo',"funcid":"L2612001","ISS_CODE":"","INST_CODE":"","INST_ID":"","INST_TYPE":"","INST_CLS":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}
function ret_CpInfo(_fromid,_funid,_flagtype,data){

	
		data=FormatResult(data,1)
	
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			//proError(data.ErrorInfo)
		 	return;
		}else{
			 if(data.rows==undefined) data.rows=[]
			 	data.rows=$.grep(data.rows,function(v,i){

			 		if(v.ISS_STAT=="1")
			 		{
			 			if(glob4.cpdm[data.rows[i].INST_ID]==undefined)
			 		{
			 			data.rows[i].QSZT="未签署";

			 		}
			 		else
			 		{
		 				if(glob4.qsrq[data.rows[i].INST_ID]==undefined)
				 			data.rows[i].QSRQ=""
				 		else
				 			data.rows[i].QSRQ=glob4.qsrq[data.rows[i].INST_ID]


				 		if(glob4.yxrq[data.rows[i].INST_ID]==undefined)
				 			data.rows[i].YXRQ=""
				 		else			 		
				 			data.rows[i].YXRQ=glob4.yxrq[data.rows[i].INST_ID]


				 		if(data.rows[i].QSRQ>data.rows[i].YXRQ)
				 		{
				 			data.rows[i].QSZT="已过期";
				 		}
				 		else 
				 		{
				 			data.rows[i].QSZT="已签署";
				 		}

			 		}
				
				
			 		

					return v

			 		}

			 		
				
			})
		 	
		 	
		}
		upDate("load",data)
		totalRecord=data.rows.length;
	
		$("#totalnum").text("共"+data.rows.length+"条")
	

	getDcbbm()
}

/*
// 客户电子约定书信息查询
function get_KhdzydsInfo(){
	setIX({"funcid":"99001339","funcname":'ret_KhdzydsInfo',"SERIAL_NO":"","CONTRACT_CLS":"","VERSION":"","INT_ORG":"","ID_TYPE":"","ID_CODE":"","CUST_CODE":"",
		"AGREEMENT_ID":"","INST_TYPE":"","INST_CLS":"","ISS_CODE":"","INST_CODE":"","INST_ID":"","EC_NO":""})
}

function ret_KhdzydsInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001339"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
		 	return;
		}else{
			 if(data.rows==undefined) data.rows=[]
		 	 //$("#load").datagrid("loadData",{"total":1,"rows":data.rows});
		 	//$("#totalnum").text("共"+data.rows.length+"条")

			 data.rows=$.grep(data.rows,function(v,i){
				if(v.CONTRACT_CLS=="202"){
					
					return v
				}
			})
		}
		
		upDate("load",data)		
		$("#totalnum").text("共"+data.rows.length+"条")

	}
}



*/


/*


function onDblClickRow(rowindex,rowdata){
	$("#load").datagrid("uncheckAll")
	$("#load").datagrid("checkRow",rowindex)
	
	onSign(3)
}
*/


function openURl1()
{
	var strUrl1="";
	var rows=$("#load").datagrid("getChecked")
	if (rows.length==0) 
	{
		proInfo("请先选择要签署的产品在进行签署");
		return
	};
	codeNum=rows[0].INST_CODE

	for(var i=0; i<totalCodeNum;i++)
	{
		if (glob2.cpdm[i]==codeNum)
		{
			strUrl1=glob2.url1[i]			
			break;
		}
	}

	
	window.open(strUrl1)
	
	/*var iHeight=500;
	var iWidth=600;
	var iTop = (window.screen.availHeight-30-iHeight)/2; //获得窗口的垂直位置;
	var iLeft = (window.screen.availWidth-10-iWidth)/2; //获得窗口的水平位置;	
	var name1="产品说明书";

	var srcArray = [ strUrl1];
  	var titleArray = [name1];
  	var srcArg = srcArray.join(';');
  	var titleArg = titleArray.join(';');

  	window.open('./Demo.html?srcArg='+srcArg+'&titleArg='+titleArg,'testOpen','height='+iHeight+',width='+iWidth+',menubar=no,status=no,toolbar=no,titlebar=no,location=no,top='+iTop+',left='+iLeft);
*/
	

}


function openURl2()
{
	var strUrl2="";
	var rows=$("#load").datagrid("getChecked")
	if (rows.length==0) 
	{
		proInfo("请先选择要签署的产品在进行签署");
		return
	};	
	codeNum=rows[0].INST_CODE
	for(var i=0; i<totalCodeNum;i++)
	{
		if (glob2.cpdm[i]==codeNum)
		{
			strUrl2=glob2.url2[i]			
			break;
		}
	}



	window.open(strUrl2)

	/*var iHeight=500;
	var iWidth=600;
	var iTop = (window.screen.availHeight-30-iHeight)/2; //获得窗口的垂直位置;
	var iLeft = (window.screen.availWidth-10-iWidth)/2; //获得窗口的水平位置;	
	var name1="风险揭示书";

	var srcArray = [ strUrl2];
  	var titleArray = [name1];
  	var srcArg = srcArray.join(';');
  	var titleArg = titleArray.join(';');

  	window.open('./Demo.html?srcArg='+srcArg+'&titleArg='+titleArg,'testOpen','height='+iHeight+',width='+iWidth+',menubar=no,status=no,toolbar=no,titlebar=no,location=no,top='+iTop+',left='+iLeft);
*/
}


function openURl3()
{
	
	var strUrl3="";	
	var rows=$("#load").datagrid("getChecked")
	if (rows.length==0) 
	{
		proInfo("请先选择要签署的产品在进行签署");
		return
	};
	codeNum=rows[0].INST_CODE
	for(var i=0; i<totalCodeNum;i++)
	{
		if (glob2.cpdm[i]==codeNum)
		{
			strUrl3=glob2.url3[i]
			break;
		}
	}

	window.open(strUrl3)

	
	/*var iHeight=500;
	var iWidth=600;
	var iTop = (window.screen.availHeight-30-iHeight)/2; //获得窗口的垂直位置;
	var iLeft = (window.screen.availWidth-10-iWidth)/2; //获得窗口的水平位置;	
	var name1="认购协议";

	var srcArray = [ strUrl3];
  	var titleArray = [name1];
  	var srcArg = srcArray.join(';');
  	var titleArg = titleArray.join(';');

  	window.open('./Demo.html?srcArg='+srcArg+'&titleArg='+titleArg,'testOpen','height='+iHeight+',width='+iWidth+',menubar=no,status=no,toolbar=no,titlebar=no,location=no,top='+iTop+',left='+iLeft);

*/
	
}


var hResult = 0;
function onSign(i){
	
	if(i==0)
		get_Khdzhtxx()
		//get_CpInfo()
		//get_KhdzydsInfo()
	else if(i==1)
		$("#load").datagrid("uncheckAll")
	else if(i==2)
		$("#load").datagrid("checkAll")
	else if(i==3){

		if (totalRecord==0)
		{
			proInfo("您没有可以签署的产品")
			return
		}
		glob.wtflag=0
		var rows=$("#load").datagrid("getChecked")

		if (rows.length==0) 
		{
			proInfo("请先选择要签署的产品在进行签署");
			return
		};

		IssCode=rows[0].ISS_CODE;
		Instcode=rows[0].INST_CODE;
		InstId=rows[0].INST_ID;

		var CpQyzt="";
		CpQyzt=rows[0].QSZT;
		if (CpQyzt=="已签署")
		{
			proInfo("该产品您已经进行过签署，请不要重复进行签署");
			return
		};

		

		$('#cdwt').dialog('open');
		$("#cpcode").text(rows[0].INST_CODE)
		$("#cpname").text(rows[0].INST_SNAME)
		
		
	}

}

function setResult(result)
{
	return;	
}



function onSinOk2(){
	var rows=$("#load").datagrid("getChecked")
	
	$('#singlewt2').dialog('close');
	$('#cdwt').dialog('open');
	$("#cpcode").text(rows[0].INST_CODE)
	$("#cpname").text(rows[0].INST_SNAME)
	
}
function onSinCance2(){
	
	$('#singlewt2').dialog('close');
	return;
}




//查询历史问券情况
function get_Khfxxx(){

	setIX({"funcname":'ret_Khfxxx',"funcid":"99001120","SURVEY_SN":configDcbdm,"USER_CODE":User.khh,"BEGIN_DATE":"","END_DATE":""})
	var sn="0";
	if (khlx=="0")// 0个人
	{
		sn="3";
	}
	else if (khlx=="1") // 1机构
	{
		sn="4";
	}
	//setIX({"funcname":'ret_Khfxxx',"funcid":"99001120","SURVEY_SN":sn,"USER_CODE":User.khh,"BEGIN_DATE":"","END_DATE":""})
}
function ret_Khfxxx(_fromid,_funid,_flagtype,data){
	
	if(_funid=="5010:SIMPLE.99001120"){
		data=FormatResult(data,1)
	
		if(data.ErrorCode!="0"){			
				proError(data.ErrorInfo)			
		 	return;
		}else{
			 if(data.rows==undefined) data.rows=[]

			 glob3.dcbbm = data.rows[0].SURVEY_SN;
			 glob3.pjjb = data.rows[0].RATING_LVL;
			 KhFxdjmc=data.rows[0].RATING_LVL_NAME;
		}
		
	}
}






	
function onOk(){

	$('#cdwt').dialog('close');
	//$('#cdSucwt').dialog('open');
	glob.cdcnt=0	
	get_Qy()
	
}
function onCance(){
	$('#cdwt').dialog('close');
	
}

function onSinOk(){
	$('#singlewt').dialog('close');
	//$('#cdSucwt').dialog('open');
	glob.cdcnt=0
	get_Qy()
	
}
function onSinCance(){
	$('#singlewt').dialog('close');
}

var Wtbh="";



function get_Qy(){
	
			
	setIX({"funcid":"L2610101","funcname":'ret_Qy',"OPER_TYPE":"0","CUST_CODE":User.khh,
		"ISS_CODE":IssCode,"INST_CODE":Instcode,"INST_ID":InstId,"SIGN_TYPE":"1",
		"SIGN_DATE":getCur(),"VALID_DATE":getCur(),"EC_NO":""})
		
	
	
}
function ret_Qy(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610101"){
		
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			proError(data.ErrorInfo)
			return
		}else{	
			Wtbh = data.rows[0].SERIAL_NO

			proInfo("您已成功签约");
			get_Khdzhtxx()		
			
		}
	}
}


//产品管理状态
function get_MgrStat(c){
	var stat=""
	if(c=="00")
		stat="待评估"
	else if(c=="01")
		stat="待内部审查"
	else if(c=="02")
		stat="待上架"
	else if(c=="03")
		stat="在售"
	else if(c=="04")
		stat="已下架"
	else if(c=="05")
		stat="草稿"
	else if(c=="06")
		stat="入库审核未通过"
	else if(c=="07")
		stat="内部审查通过"
	else if(c=="08")
		stat="内部审查未通过"
	else if(c=="09")
		stat="评估未通过"
	else if(c=="10")
		stat="上架失败"
	else if(c=="11")
		stat="待上架复合"
	return stat
}
