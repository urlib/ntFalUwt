function PageInit(){
		
	hideLoading()
	
	create_easygrid("当日委托查询",{},{"ORD_STAT":{"formatter":get_wtStat},"TRD_ID":{"formatter":get_TraType},"APP_TIMESTAMP":{"formatter":getTime},"CANCEL_FLAG":{"formatter":getcancleflag}})
	get_WTInfo()
}
//请求产品信息
function get_WTInfo(){	
	
	setIX({"funcid":"L2620105","funcname":'ret_WTInfo',"BGN_DATE":getCur(),"END_DATE":getCur(),"CUST_CODE":User.khh,"CUACCT_CODE":'',
		"TA_ACCT":'',"TRANS_ACCT":'',"ISS_CODE":'',"INST_CODE":'',"INST_ID":'',"APP_SNO":'',"CAN_CANCEL":'',"PAGE_RECNUM":'0',"PAGE_RECCNT":'500'})
}
//应答产品信息
function ret_WTInfo(_fromid,_funid,_flagtype,data){
		
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		$("#total").text("共0条")
		if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
		{
			proInfo("您还未开设理财帐户，请先开户");
		}
		else
		{
			proError(data.ErrorInfo)	
		}
	//	$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
	 	$("#total").text("共"+data.rows.length+"条")
	 	
	 	upDate("load",data)
	}
}
var wtState={"0":"未报","1":"已报","2":"确认","3":"部撤","4":"全撤","5":"部成","6":"全成","7":"废单",
			"8":"已报待撤","9":"部成待撤","A":"待撤销","B":"TA确认","C":"TA失败","D":"待申报","E":"对手拒绝"}
// 委托状态
function get_wtStat(c){
	return wtState[c]==undefined?"":wtState[c]
}

function fmtDt(d){
	var dl=d.split("-")
	
	if(dl.length!=3)
		return ""
	var fl=$.map(dl,function(val){
		return sigtodow(parseInt(val))
	})
	return fl.join('')
	
}
function onQuery(){
	get_WTInfo()
}
function test3(){
	alert("1")
	return "1"
}

function getcancleflag(c)
{
	var cancleflag="";
	if(c=="0")
	{
		cancleflag="正常"
	}
	else if (c=="1")
	{
		cancleflag="撤单"
	}
	return cancleflag;
}


