function PageInit(){
	  get_ZJInfo()
}
//请求资金信息
function get_ZJInfo(){
	setIX({"funcid":'L2611203',"funcname":'ret_ZJInfo',"CUST_CODE":User.khh,"CUACCT_CODE":'',"CURRENCY":''})
}
//应答资金信息
function ret_ZJInfo(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
		{
			proInfo("您还未开设理财帐户，请先开户");
		}
		else
		{
			proError(data.ErrorInfo)	
		}
		//$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
	 	create_easygrid("资金查询",{},{"CURRENCY":{"formatter":get_moneyname}})
	 	upDate("load",data)
	}
}
// 获取币种名称
function get_moneyname(c){
	var name=""
	if(c=="0")
		name="人民币"
	else if(c=="1")
		name="美元"
	else if(c=="2")
		name="港币"	
	return name
}

