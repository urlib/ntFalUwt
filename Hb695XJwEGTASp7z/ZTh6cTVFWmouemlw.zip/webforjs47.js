
var glob={
	"djzh":[],//登记账号
	"djjg":[],//登记机构
	"jyzh":[],//交易账号
	"zczh":[]//资产账户
}

var glob2={	
	"data2":[]
}

var CuacctCode="";
var TransAcct="";


var num=0;

function PageInit(){	
	var today=getCur()
	var preweek=getAddMonth(-1)
	hideLoading()
	$("#sdate").attr("value",preweek.slice(0, 4)+"-"+preweek.slice(4, 6)+"-"+preweek.slice(6,8))
	$("#edate").attr("value",today.slice(0, 4)+"-"+today.slice(4, 6)+"-"+today.slice(6,8))
	create_easygrid("交割单",{},{"TRD_ID":{"formatter":get_TradId},"CURRENCY":{"formatter":get_moneyname},"PAY_WAY":{"formatter":get_payway}})
	
	 get_Djzh()
}

//获取登记账号
function get_Djzh(){
	setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":User.khh,"CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_Djzh(_fromid,_funid,_flagtype,data){	
	if(_funid=="5010:SIMPLE.L2610008"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("在系统内尚未开户") != -1)
			{
				//data.rows=[];
				//upDate("load",data);
				//$("#total").text("共0条")
				proInfo("您还未开设理财帐户，请先开户");
		 		return;
			}
			else if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
				return
			}
			else
			{
				proError(data.ErrorInfo)
				return
			}			
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{
			
				for(var i=0;i<data.rows.length;i++)
				{
					var Djjg=data.rows[i].TA_CODE;

					if (Djjg.indexOf("ZZ")!=-1 || Djjg.indexOf("zz")!=-1 )
					{
						CuacctCode=data.rows[i].CUACCT_CODE
						TransAcct=data.rows[i].TRANS_ACCT
					};
							
				
				
					glob.djzh[i]=data.rows[i].TA_ACCT		
									
					glob.jyzh[i]=data.rows[i].TRANS_ACCT
					
					glob.zczh[i]=data.rows[i].CUACCT_CODE
					
					glob.djjg[i]=data.rows[i].TA_CODE		
				}						
					
						
			}
			
		}


		get_CJCXInfo()
			
		
	}
}

//请求产品信息
function get_CJCXInfo(){	

	var start=$("#sdate").attr("value")
	var end=$("#edate").attr("value")
	setIX({"funcid":"L2800920","funcname":'ret_CJCXInfo',"BGN_DATE":fmtDt(start),"END_DATE":fmtDt(end),"CUACCT_CODE":CuacctCode,"TRANS_ACCT":TransAcct,"CURRENCY":'0',
		"PAGE_RECNUM":'0',"PAGE_RECCNT":'500'})
}
//应答产品信息
function ret_CJCXInfo(_fromid,_funid,_flagtype,data){
	
	hideLoading()	
	if(_funid=="5010:SIMPLE.L2800920"){		
		data=FormatResult(data,1)

		
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("在系统内尚未开户") != -1)
			{
				data.rows=[];
				upDate("load",data);
				$("#total").text("共0条")
		 		return;
			}
			else if( data.ErrorInfo.indexOf("没有查询数据") != -1)
			{
				data.rows=[];
				upDate("load",data);
				$("#total").text("共0条")
		 		return;
			}
			else if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
				return
			}
			else
			{
		 		proError(data.ErrorInfo)
				$("#total").text("共0条")
		 		return;
			}
			
		}else{
			
			if(data.rows==undefined) data.rows=[];
		//	glob2.data2.concat(data.rows);	
			//num++;
			//if(num==total)
			//{
		//		data.rows=glob2.data

				if (CuacctCode=="" || CuacctCode==undefined || TransAcct=="" || TransAcct==undefined)
				{
					data.rows=[];
					upDate("load",data);
				}
				else
				{
					data.total=data.rows.length;	
					$("#total").text("共"+data.rows.length+"条")	
		 			upDate("load",data);
				}


				
			//}




	 		/*$("#total").text("共"+data.rows.length+"条")
	 	
	 		upDate("load",data)*/
		}
	}
}



function fmtDt(d){

	
	var dl=d.split("-")
	var tmpdata=""
	
	if(dl.length!=3)
		return ""
	var fl=$.map(dl,function(val){
		tmpdata=tmpdata+val;
		return sigtodow(parseInt(val))
	})
	
	return tmpdata
	
}


function onQuery(){
	
	get_CJCXInfo()
		
}
// 交易类别
function get_TradId(c){
	var stat=""
	if(c=="001")
		stat="开户"
	else if(c=="002")
		stat="销户"
	else if(c=="003")
		stat="变更"
	else if(c=="004")
		stat="账户冻结"
	else if(c=="005")
		stat="账户解冻"
	else if(c=="008")
		stat="注册"
	else if(c=="009")
		stat="撤销交易账户"
	else if(c=="110")
		stat="认购"	
	else if(c=="111")
		stat="申购"
	else if(c=="112")
		stat="赎回"
	else if(c=="113")
		stat="快速赎回"
	else if(c=="114")
		stat="续期认购"
	else if(c=="115")
		stat="定时定额申购"
	else if(c=="125")
		stat="撤销确认"
	else if(c=="126")
		stat="转托管"
	else if(c=="127")
		stat="转托管入"
	else if(c=="128")
		stat="转托管出"
	else if(c=="129")
		stat="分红设置"
	else if(c=="130")
		stat="认购结果"
	else if(c=="131")
		stat="份额冻结"
	else if(c=="132")
		stat="份额解冻"
	else if(c=="133")
		stat="非交易过户"
	else if(c=="134")
		stat="非交易过户入"
	else if(c=="135")
		stat="非交易过户出"
	else if(c=="136")
		stat="转换"
	else if(c=="137")
		stat="转换入"
	else if(c=="138")
		stat="转换出"
	else if(c=="342")
		stat="强制赎回"
	else if(c=="343")
		stat="分红到账"
	else if(c=="344")
		stat="强增"
	else if(c=="345")
		stat="强减"
	else if(c=="346")
		stat="兑付"
	else if(c=="347")
		stat="扣款"	
	else if(c=="349")
		stat="募集失败"
	else if(c=="350")
		stat="清盘"
	else if(c=="20B")
		stat="买入"
	else if(c=="20S")
		stat="卖出"
	else if(c=="A01")
		stat="开户确认"
	else if(c=="A02")
		stat="销户确认"
	else if(c=="A03")
		stat="变更确认"
	else if(c=="A08")
		stat="注册确认"
	else if(c=="A29")
		stat="分红设置确认"
	else if(c=="401")
		stat="首次投保"
	else if(c=="402")
		stat="续期投保"
	else if(c=="403")
		stat="保险分红返款"
	else if(c=="404")
		stat="保险本金返款"
	else if(c=="C01")
		stat="资讯订阅"
	else if(c=="C02")
		stat="资讯退订"
	else if(c=="C03")
		stat="暂停推送"
	else if(c=="C04")
		stat="恢复推送"
	return stat
}

// 获取币种名称
function get_moneyname(c){
	var name=""
	if(c=="0")
		name="人民币"
	else if(c=="1")
		name="美元"
	else if(c=="2")
		name="港币"	
	return name
}

function get_payway(c){
	var payway=""
	if(c=="0")
		payway="保证金支付"
	else if(c=="1")
		payway="第三方支付"
	else if(c=="2")
		payway="线下支付（体外）"	
	return payway;
}