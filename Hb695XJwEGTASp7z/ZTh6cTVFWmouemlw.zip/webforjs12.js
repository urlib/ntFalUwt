var glob={
	"khdm":"",// 客户代码
	"khxm":"",// 客户姓名
	"zjlx":"",// 证件类型
	"zjhm":"",// 证件号码
	"khtzsx":"",// 客户拓展属性
	"lxdh":""// 联系电话
};
var glob2={
	"zczh":[],// 资产账号
	"djjg":[],// 登记机构
	"djzh":[],// 登记账号
	"jyzh":[]// 交易账号
};
var glob3={
	"tsjgdm":[],// 特殊机构代码
	"jgjc":[],	// 机构简称
	"jgqc":[],	//机构全称
	"jgqz":[],	// 机构前缀
	"jyzh":[],	// 交易账号
	"djzh":[],	// 登记账号
	"stlx":[],	// 试题类型
	"TAflag":[]	// TA返回指示
};
var glob4={
	"zczh":[],// 资产账号
	"zczhzt":[],// 资产账号状态
	"zzhbs":[]// 主账户标识	
};
var czlx="";
var zczh="";
var djjg="";
var jyzh="";
var djzh="";
var totalNum=0;
var num=0;
var stlx2="";
var retNum=0;
var zczhStatus="";


function PageInit(){
	setDlg("singlewt");
	get_khxx();
};

// 获取客户信息
function get_khxx(){
	setIX({"funcid":"99001270","funcname":"ret_Khxx","USER_CODE":User.khh,"USER_ROLE":"1","OP_TYPE":"1"});
}

function ret_Khxx(_fromid,_funid,_flagtype,data){
	if (_funid=="5010:SIMPLE.99001270") {
		data=FormatResult(data,1)
		if(data.ErrorCode!=0){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else if(data.ErrorInfo.indexOf("没有查询数据") != -1)
			{}
			else
			{
				proError(data.ErrorInfo)	
			}
			return;
		}
		else{
			if (data.rows==undefined) {
				proInfo("未获取到客户基本资料");
				return;
			}else{				
				glob.khdm=data.rows[0].USER_CODE
				glob.khxm=data.rows[0].USER_NAME
				glob.zjlx=data.rows[0].ID_TYPE 
				glob.zjhm=data.rows[0].ID_CODE 
				glob.lxdh=data.rows[0].TEL 	
				glob.khtzsx=data.rows[0].CUST_EXT_ATTR 
			}
		}
	}
	
	$("#khh").attr("value",glob.khdm)
	$("#khmc").attr("value",glob.khxm)	
	$("#zjlx").attr("value",get_idtype(glob.zjlx))
	$("#zjhm").attr("value",glob.zjhm)
	$("#lxdh").attr("value",glob.lxdh)

	get_Zczh()
}

//获取资产账号
function get_Zczh(){
	setIX({"funcid":"99001332","funcname":'ret_Zczh',"USER_CODE":User.khh,"CUACCT_CODE":""})
}

function ret_Zczh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001332"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else if(data.ErrorInfo.indexOf("没有查询数据") != -1)
			{}
			else
			{
				proError(data.ErrorInfo)	
			}
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到资产账号")
				return
			}
			else{

				for(var i=0; i<data.rows.length; i++)
				{					
					glob4.zczh[i]=data.rows[i].CUACCT_CODE;
					glob4.zzhbs[i]=data.rows[i].MAIN_FLAG;	
					glob4.zczhzt[i]=data.rows[i].CUACCT_STATUS;			

				}
					
			}
		}

		var obj=document.getElementById('zczh');
		var jsonObj=[];
		for(var k=0; k<data.rows.length; k++)
		{			
			jsonObj[k]={id:k,value:glob4.zczh[k]};		
		
		}
		for(var e=0; e<jsonObj.length; e++)
		{
			obj.add(new Option(jsonObj[e].value,jsonObj[e].id))
		}
			get_Djjg();	
	}

}

//获取登记机构
function get_Djjg(){
	setIX({"funcid":"99001350","funcname":'ret_Djjg',"INT_ORG":"","SPEC_ORG_CODE":"","SPEC_ORG_TYPE":"1"})
}

function ret_Djjg(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001350"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("没有查询数据") != -1)
			{}
			else
			{
				proError(data.ErrorInfo)
			}			
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到机构")
				return
			}
			else{

				for(var i=0; i<data.rows.length; i++)
				{
					totalNum++;
					glob3.tsjgdm[i]=data.rows[i].SPEC_ORG_CODE;
					glob3.jgjc[i]=data.rows[i].SPEC_ORG_SNAME;
					glob3.jgqc[i]=data.rows[i].SPEC_ORG_FNAME;
					glob3.TAflag[i]=data.rows[i].TA_FLAG;
					glob3.jgqz[i]=data.rows[i].ORG_PREFIX;	
					glob3.stlx[i]=data.rows[i].SURVEY_SN;			

				}
					
			}
		}
				
	}


	var obj2=document.getElementById('djjg');
	var jsonObj2=[];
	for(var k=0; k<totalNum; k++)
	{
		var str=glob3.tsjgdm[k]+""+glob3.jgjc[k];
		jsonObj2[k]={id:k,value:str};		
		
	}
	for(var e=0; e<jsonObj2.length; e++)
	{
		obj2.add(new Option(jsonObj2[e].value,jsonObj2[e].id))
	}

}

//清除数据
function OnCleanUp(){
	
	$("#djzh").attr("value","");
	$("#jyzh").attr("value","");

}
var num2=0;
//开户
function OnTj(){

	var obj=document.getElementById('czlx');
	var index=obj.selectedIndex;
	czlx=obj.options[index].value

	var obj2=document.getElementById('zczh');
	for(var i = 0 ; i < obj2.options.length;i++)
	{
		if(obj2.options[i].selected)
		{
			zczh=obj2.options[i].text;
			zczhStatus=glob4.zczhzt[i];
			break;
		}
	}
	

	var obj3=document.getElementById('djjg');
	for(var j = 0 ; j < obj3.options.length;j++)
	{
		if(obj3.options[j].selected)
		{
			num2=j;
			djjg=obj3.options[j].text;	
			break;		
		}
	}

	if(glob3.stlx[num2]!="0")
	{		
		stlx2=glob3.stlx[num2];
		oncpjgcx();	

	}
	else
	{
		onContinue()
	}
	
}

var bHave=false;
function onContinue()
{
		var str1=glob3.jgqz[num2];
		var str2=zczh;
		djjg=glob3.tsjgdm[num2]	
		jyzh=str1+str2;
		if(glob3.TAflag[num2]=="0")
		{
	
			djzh=jyzh;
		}
		else
		{
		
			djzh="";
		}

	
		get_Cx()		
		//setTimeout(,1000)
		if(bHave)
		{
			return;
		}
		else
		{
			if (czlx==0 || czlx==1)// 开户
			{
			
				$("#djzh").attr("value",djzh)
				$("#jyzh").attr("value",jyzh)	
				get_zhzltbotcxt()	
			}
			else// 销户
			{
				$('#singlewt').dialog('open');
				//get_Xh();
			}
		}

		

}






// 查询是否已经开户
function get_Cx(){	
	setIX({"funcid":"99001335","funcname":'ret_Cx',"CUST_CODE":glob.khdm,"CUACCT_CODE":zczh,"OTC_CODE":djjg,"TRANS_ACCT ":""})

}


function ret_Cx(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.99001335"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("没有查询数据") != -1)
			{}
			else
			{
				proError(data.ErrorInfo)
			}					
						
			return
		}else{
			if(data.rows==undefined) {
				bHave=false;
				return
			}
			else{					
					if(data.rows[0].OTC_CODE==undefined)
					{
						bHave=false;
					}
					else
					{
						bHave=true;
						proInfo("您已开通了该机构的登记帐号")
					}

			
			}
		}

		
	}
}




















function oncpjgcx()
{
	
	setIX({"funcid":"99001120","funcname":'ret_cpjgcx',"SURVEY_SN":stlx2,"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
}


function ret_cpjgcx(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.99001120"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			//proError(data.ErrorInfo)
			proInfo("您还未做理财风险测评，请先做理财风险测评")
			return
		}else{
	
			if(data.rows[0].RATING_LVL_NAME == undefined )
			{
				proInfo("您还未进行风险测评，请先进行风险测评之后再进行此操作")
				
			}
			else
			{			
				onContinue();
			}

			
		}
	}
}








function onSinOk(){
	$('#singlewt').dialog('close');
	get_Xh();	
}
function onSinCance(){
	$('#singlewt').dialog('close');
}


// 账户资料同步OTC系统
function get_zhzltbotcxt(){	

	var opertype="";	
	if(glob.khtzsx.indexOf("2")==-1)
	{	
		opertype="000000";
	}
	else
	{		
		
		opertype="222222";
	}

	setIX({"funcid":"99001345","funcname":'ret_zhzltbotcxt',"CUST_CODE":glob.khdm,"CUACCT_CODES":zczh,"BANK_CODE":"",
		"BANK_ACCT ":"","PAY_WAY":"","PAY_ORG":"","OPERATION_TYPE":opertype})

}


function ret_zhzltbotcxt(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001345"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			if(data.rows==undefined) data.rows=[]			
				proInfo("请重新登录网上交易软件使理财帐号生效")
		}
		get_djzhwh()
	}
}

// 销户
function get_Xh(){	
	setIX({"funcid":"99001335","funcname":'ret_Xh',"CUST_CODE":glob.khdm,"CUACCT_CODE":zczh,"OTC_CODE":djjg,"TRANS_ACCT ":""})

}


function ret_Xh(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.99001335"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){					
			proError(data.ErrorInfo)			
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号信息")
				return
			}
			else{
					jyzh=data.rows[0].TRANS_ACCT;
					djzh=data.rows[0].OTC_ACCT;

			
					$("#djzh").attr("value",djzh)
					$("#jyzh").attr("value",jyzh)	
										
			}
		}

		get_djzhwh();		
	}
}

function get_djzhwh(){

	var accstatue="";
	if (czlx==1) 
	{
		accstatue=zczhStatus;
	}

	setIX({"funcid":"99001334","funcname":'ret_djzhwh',"OPER_TYPE":czlx,"CUST_CODE":glob.khdm,"CUACCT_CODE":zczh,"OTC_CODE":djjg,
		"OTC_ACCT":djzh,"TRANS_ACCT":jyzh,"ACCT_STAT":accstatue,"OPEN_DATE":"","CLOSE_DATE":""})

}


function ret_djzhwh(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001334"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){			
			proError(data.ErrorInfo)
			return			
		}else{
			if(data.rows==undefined) data.rows=[];
			if (czlx==2) 
			{
				proInfo("请重新登录网上交易软件使理财帐号生效");
			}	

			//proInfo("委托已提交")
			//get_zhzltbotcxt()			
		}
	}
}



function get_usertype(c)
{
	var usertype="";
	if(c=="0")
	{
		usertype="个人";
	}
	else if( c=="1" )
	{
		usertype="机构";
	}
	else if( c=="2")
	{
		usertype="设备";
	}
	return usertype;
}

function get_idtype(c)
{
	var idtype="";
	if(c=="00")
	{
		idtype="身份证";
	}
	else if( c=="01" )
	{
		idtype="护照";
	}
	else if( c=="02")
	{
		idtype="军官证";
	}
	else if( c=="03")
	{
		idtype="士兵证";
	}
	else if( c=="04")
	{
		idtype="港澳居民来往内地通行证";
	}
	else if( c=="05")
	{
		idtype="户口本";
	}
	else if( c=="06")
	{
		idtype="外国护照";
	}
	else if( c=="07")
	{
		idtype="其它";
	}
	else if( c=="08")
	{
		idtype="文职证";
	}
	else if( c=="09")
	{
		idtype="警官证";
	}
	else if( c=="0A")
	{
		idtype="台胞证";
	}
	else if( c=="10")
	{
		idtype="组织机构代码证";
	}
	else if( c=="11")
	{
		idtype="营业执照";
	}
	else if( c=="12")
	{
		idtype="行政机关";
	}
	else if( c=="13")
	{
		idtype="社会团体";
	}
	else if( c=="14")
	{
		idtype="军队";
	}
	else if( c=="15")
	{
		idtype="武警";
	}
	else if( c=="16")
	{
		idtype="下属机构";
	}
	else if( c=="17")
	{
		idtype="基金会";
	}
	else if( c=="18")
	{
		idtype="其它";
	}
	return idtype;
}

