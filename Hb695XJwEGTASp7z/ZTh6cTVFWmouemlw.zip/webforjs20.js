﻿var glob={
	"djzh":"",//登记账号
	"djjg":"",//登记机构
	"jyzh":"",//交易账号
	"zczh":"",//资产账户
	"cpbm":"",//产品编码
	"cpcode":"",
	"cpname":"",
	"fxrdm":"",// 发行人代码
	"cpzl":"",// 产品子类
	"cpdl":"",// 产品大类
	"zzrq":"",//产品终止日期
	"kyzj":"",//可用金额
	"signflag":"",//电子合同标志
	"rgje":"",//认购金额
	"cpjz":"",//产品净值数据
	"dzhtflag":"",//电子合同标志
	"fxjs":"0",//风险揭示标志
	"dlgflag":"0"//调用委托成交的对话框标志
	
}

var hResult = 0;
var totalCodeNum=0;
var num=0;
var have=0;
var codeNum="";
var str1="";
var str2="";
var str3="";
var KhFxdj="";
var KhFxdjmc="";
var CpFxdj="";
var bFxts = false;
var configDcbdm="";
var qszq="";
var khlx="";
var Cpyxrq="";
var Cprq="";

var glob2={
	"cpdm":[],// 产品代码
	"url1":[],// URL1
	"url2":[],// URL2
	"url3":[]// URL3
};

var glob4={
	"dzhtbh":"",//电子合同编号
	"qsrq":"",//签署日期
	"cpdm":"",//产品代码
	"yxrq":""//有效日期	
}



function PageInit(){

	setDlg()
	//setDlg("cdSucwt")
	hideLoading()	
	create_easygrid("认购",{onDblClickRow:onDblClickRow},{"ISS_STAT":{"formatter":get_Stat},"RISK_LVL":{"formatter":get_RiskLvl}})
	//get_Djzh()
	//get_KhKyzj()
	//getTotalNum()
	getDcbbm()
}


/*获取配置文件配置的柜员代码*/
function getDcbbm(){
	//获取柜员代码
	
	var _ix = new IXContent();
	_ix.Set("key", "dcbbm")
	Win_CallTQL('ret_getDcbbm', 'gettradeccf', _ix ,'');
}

function ret_getDcbbm(_fromid,_funid,_flagtype,_json) 
{
	configDcbdm = _json;

	getTotalNum()
	//get_KhInfo()
}






// 客户信息查询接口
function get_KhInfo(){
	setIX({"funcid":"L2610002","funcname":'ret_KhInfo',"CUST_CODE":User.khh,"CUST_TYPE":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_KhInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2610002"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			
		 	return;
		}
		else
		{
			if(data.rows==undefined) data.rows=[];
			
			khlx=data.rows[0].CUST_TYPE;
		}
	
		
		}
		getTotalNum()
}







/*获取配置文件配置的柜员代码*/
function getTotalNum(){
	//获取柜员代码
	var _ix = new IXContent();
	_ix.Set("key", "LccpCode_Num")
	Win_CallTQL('ret_getTotalNum', 'gettradeccf', _ix ,'');
}

function ret_getTotalNum(_fromid,_funid,_flagtype,_json) 
{

	totalCodeNum = _json;
	
	for(var i=1; i<=totalCodeNum; i++)
	{
		getCode(i)
		getURl1(i)
		getURl2(i)
		getURl3(i)
		num++;
	}
	get_KhKyzj()
	
}


/*获取配置文件配置的柜员代码*/
function getCode(c){

	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c;
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getCode', 'gettradeccf', _ix ,'');
}

function ret_getCode(_fromid,_funid,_flagtype,_json) 
{

	glob2.cpdm[num]=_json
	
}


/*获取配置文件配置的柜员代码*/
function getURl1(c){

	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c+"_URL1";
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getURl1', 'gettradeccf', _ix ,'');
}

function ret_getURl1(_fromid,_funid,_flagtype,_json) 
{

	glob2.url1[num]=_json;
	
}


/*获取配置文件配置的柜员代码*/
function getURl2(c){

	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c+"_URL2";
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getURl2', 'gettradeccf', _ix ,'');
}

function ret_getURl2(_fromid,_funid,_flagtype,_json) 
{

	glob2.url2[num]=_json;

}

/*获取配置文件配置的柜员代码*/
function getURl3(c){
	
	//获取柜员代码
	var _ix = new IXContent();
	var tmp = "LccpCode_"+c+"_URL3";
	_ix.Set("key", tmp )
	Win_CallTQL('ret_getURl3', 'gettradeccf', _ix ,'');
}

function ret_getURl3(_fromid,_funid,_flagtype,_json) 
{
	
	glob2.url3[num]=_json;
	
}








//获取登记账号
function get_Djzh(){
	setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":User.khh,"CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}

function ret_Djzh(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.L2610008"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
			return
		}else{
			if(data.rows==undefined) {
				proInfo("未获取到登记账号")
				return
			}
			else{
					for(var i=0;i<data.rows.length;i++)
					{						
						
						if (data.rows[i].TA_CODE == glob.djjg) {

							glob.djzh=data.rows[i].TA_ACCT							
							glob.jyzh=data.rows[i].TRANS_ACCT
							glob.zczh=data.rows[i].CUACCT_CODE						
						}
					}
					
			
			}
		}
		// get_KhKyzj()
		get_subRg()
	}
}

//获取客户可用资金
function get_KhKyzj(){

	setIX({"funcid":"L2611203","funcname":'ret_KhKyzj',"CUST_CODE":User.khh,"CUACCT_CODE":"","CURRENCY":""})
}
function ret_KhKyzj(_fromid,_funid,_flagtype,data){

	if(_funid=="5010:SIMPLE.L2611203"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
		 	return;
		}else{
			if(data.rows==undefined){
				proInfo("未获取到可用金额")
				return
			}else{
		 		glob.kyzj=fmtFt(data.rows[0].FUND_AVL)
		 	}
		}
		get_CpJz()
	}
}


//获取产品净值
function get_CpJz(){
	setIX({"funcid":"L2620304","funcname":'ret_CpJz',"BGN_DATE":getCur(),"END_DATE":getCur(),"ISS_CODE":"","INST_CODE":"","INST_ID":"","LATEST_FLAG":"1","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}
function ret_CpJz(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2620304"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
		 	return;
		}else{
		 	if(data.rows==undefined) data.rows=[]
		 	var cp={}
		 	$.each(data.rows,function(k,v){
		 		cp[v.INST_ID]=v.LAST_NET
		 	})
		 	glob.cpjz=cp
		}
	}
	//get_CpInfo()
	get_CpFxzzrq()
}

//获取产品发行终止日期
function get_CpFxzzrq(){
	setIX({"funcid":"L2612011","funcname":'ret_CpFxzzrq',"ISS_CODE":"","INST_CODE":"","INST_ID":"","INST_TYPE":"","INST_CLS":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})
}
function ret_CpFxzzrq(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.L2612011"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
		 	return;
		}else{
		 	if(data.rows==undefined) data.rows=[]
		 	var rq={}
		 	var rq2={}
		 	var rq3={}
		 	$.each(data.rows,function(k,v){
		 		rq[v.INST_ID]=v.ISS_END_DATE
		 		rq2[v.INST_ID]=v.TA_CODE
		 		rq3[v.INST_ID]=v.EC_EFFECT_FLAG
		 	

		 	})
		 	glob.zzrq=rq
		 	glob.djjg=rq2
		 	
		 	glob.signflag=rq3
		 
		}
	}
	
	//get_CpInfo()
	get_Khdzhtxx()
}




//获取客户电子合同信息
function get_Khdzhtxx(){
	
	setIX({"funcid":"L2610005","funcname":'ret_Khdzhtxx',"CUST_CODE":User.khh,"ISS_CODE":"","INST_CODE":"","INST_ID":""})
}
function ret_Khdzhtxx(_fromid,_funid,_flagtype,data){
	
	if(_funid=="5010:SIMPLE.L2610005"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			
		}else{
		 	if(data.rows==undefined) data.rows=[]
		 	var rq={}
		 	var rq2={}
		 	var rq3={}
		 	var rq4={}
		 	$.each(data.rows,function(k,v){
		 		rq[v.INST_ID]=v.EC_NO
		 		rq2[v.INST_ID]=v.SIGN_TYPE
		 		rq3[v.INST_ID]=v.VALID_DATE
		 		rq4[v.INST_ID]=v.INST_CODE
		 	

		 	})
		 	glob4.dzhtbh=rq
		 	glob4.qsrq=rq2		 	
		 	glob4.yxrq=rq3
		 	glob4.cpdm=rq4
		 
		}
	}
	
	get_CpInfo()
}


//请求产品信息
function get_CpInfo(){
	L2612001({"funcname":'ret_CpInfo'})
}

function ret_CpInfo(_fromid,_funid,_flagtype,data){
	
	if(_funid=="5010:SIMPLE.L2612001"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
			{
				proInfo("您还未开设理财帐户，请先开户");
			}
			else
			{
				proError(data.ErrorInfo)	
			}
		 	return;
		}else{
		 	if(data.rows==undefined) data.rows=[]
	 		data.rows=$.grep(data.rows,function(v,i){
				if(v.ISS_STAT=="1" && (v.TRD_IDS.indexOf("110")!=-1)){

					if(glob.cpjz[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].LAST_NET=""
			 		else
			 			data.rows[i].LAST_NET=glob.cpjz[data.rows[i].INST_ID]
			 		if(glob.zzrq[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].ISS_END_DATE=""
			 		else
			 			data.rows[i].ISS_END_DATE=glob.zzrq[data.rows[i].INST_ID]
			 		if(glob.zzrq[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].TA_CODE=""
			 		else			 		
			 			data.rows[i].TA_CODE=glob.djjg[data.rows[i].INST_ID]
			 		if(glob.signflag[data.rows[i].INST_ID]==undefined)
			 			data.rows[i].EC_EFFECT_FLAG=""
			 		else			 		
			 			data.rows[i].EC_EFFECT_FLAG=glob.signflag[data.rows[i].INST_ID]





			 		if(glob4.cpdm[data.rows[i].INST_ID]==undefined)
			 		{
			 			data.rows[i].QSZT="0";//未签署

			 		}
			 		else
			 		{
		 				if(glob4.qsrq[data.rows[i].INST_ID]==undefined)
				 			data.rows[i].QSRQ=""
				 		else
				 			data.rows[i].QSRQ=glob4.qsrq[data.rows[i].INST_ID]


				 		if(glob4.yxrq[data.rows[i].INST_ID]==undefined)
				 			data.rows[i].YXRQ=""
				 		else			 		
				 			data.rows[i].YXRQ=glob4.yxrq[data.rows[i].INST_ID]


				 		if(data.rows[i].QSRQ>data.rows[i].YXRQ)
				 		{
				 			data.rows[i].QSZT="2";// 已过期
				 		}
				 		else 
				 		{
				 			data.rows[i].QSZT="1";// 已签署
				 		}

			 		}








					return v
				

				}
			})
		 	
		 	
		 	upDate("load",data)
		}
	}
}
function onDblClickRow(rowindex,rowdata){
	bFxts = false;
	$("#inst_code").attr("value",rowdata.INST_CODE)
	$("#inst_name").attr("value",rowdata.INST_SNAME)
	$("#avafund").attr("value",glob.kyzj)//可用金额
	$("#instjz").attr("value",rowdata.ISS_CODE)
	glob.cpbm=rowdata.INST_ID
	glob.cpcode=rowdata.INST_CODE
	glob.cpname=rowdata.INST_SNAME
	glob.djjg=rowdata.TA_CODE
	glob.signflag=rowdata.EC_EFFECT_FLAG
	glob.fxrdm=rowdata.ISS_CODE
	glob.cpdl=rowdata.INST_TYPE
	glob.cpzl=rowdata.INST_CLS	
	CpFxdj = rowdata.RISK_LVL
	qszt = rowdata.QSZT
	have=0;	
	
	get_CCCXInfo();
	//get_FXCPInfo();
}





//查询客户风险等级信息
function get_CCCXInfo(){
	
	setIX({"funcid":"L2610003","funcname":'ret_CCCXInfo',"CUST_CODE":User.khh})
}


//应答产品信息
function ret_CCCXInfo(_fromid,_funid,_flagtype,data){
		
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]

		var num=0;
		var tmpEval_Date="";


		for(var i=0;i<data.rows.length;i++)
		{
			if (i==0)
			{
				tmpEval_Date=data.rows[0].EVAL_DATE;// 测评日期
			};
			Cprq=data.rows[i].EVAL_DATE;// 测评日期
			if (Cprq>=tmpEval_Date)
			{
				tmpEval_Date=Cprq;
				num=i;
			};
		}

	 
	 	
	 	KhFxdj=data.rows[num].EVAL_LVL;
		KhFxdjmc=get_KhRiskLvl(data.rows[num].EVAL_LVL);

		Cprq=data.rows[num].EVAL_DATE;// 测评日期
	 	Cpyxrq=data.rows[num].VALID_DATE;// 有效日期

	 

		
	 	

	}
}


/*


function get_FXCPInfo(){
	setIX({"funcid":"99001120","funcname":'ret_fxcpinfo',"SURVEY_SN":configDcbdm,"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
	var sn="0";
	if (khlx=="0")// 0个人
	{
		sn="3";
	}
	else if (khlx=="1") // 1机构
	{
		sn="4";
	}
	//setIX({"funcid":"99001120","funcname":'ret_fxcpinfo',"SURVEY_SN":sn,"USER_CODE":User.khh,"APPT_SERIAL_NO":"","BGN_DATE":"","END_DATE":""})
}
//应答资金信息
function ret_fxcpinfo(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){		
		
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
	 	
	 	KhFxdj=data.rows[0].RATING_LVL;
		KhFxdjmc=data.rows[0].RATING_LVL_NAME;
	}
}


*/



//确认认购
function onSubmit(t){	

	if(isNullStr($("#inst_code").attr("value"))){
		proError("产品代码不能为空")
		return;
	}
	if(isNullStr($("#rgje").attr("value"))){
		proError("请输入需要认购的金额")
		return;
	}
	glob.rgje=$("#rgje").attr("value")
	glob.cpcode=$("#inst_code").attr("value")
	glob.cpname=$("#inst_name").attr("value")

	if (qszt=="0" )
	{
		proInfo("您还未签约该产品，请签约后再购买。谢谢!");
		return;
	}
	if (qszt=="2")
	{
		proInfo("您的签约已过期，请重新签约后再购买。谢谢!");	
		return;
	};



	if(glob.signflag=="1")
	{
	
		for( var i=0; i<totalCodeNum; i++)
		{
	
			if(glob2.cpdm[i]==glob.cpcode)
			{
				str1=glob2.url1[i]
				str2=glob2.url2[i]
				str3=glob2.url3[i]
				have=1;
				break;
			}
		}
	}
	else
	{		
		get_KhdzydsInfo()
	}

	
	
	//if (have==1) 
	if (glob.signflag=="1") 
	{
		tsdzhss()
	}
	else
	{
		get_subXd()
	}

	
}




// 客户电子约定书信息查询
function get_KhdzydsInfo(){
	have=0;
	setIX({"funcid":"99001339","funcname":'ret_KhdzydsInfo',"SERIAL_NO":"","CONTRACT_CLS":"202","VERSION":"",
		"INT_ORG":"","ID_TYPE":"","ID_CODE":"","CUST_CODE":User.khh,"INST_TYPE":glob.cpdl,
		"INST_CLS":glob.cpzl,"ISS_CODE":glob.fxrdm,"INST_CODE":glob.cpcode,"INST_ID":glob.cpbm,"EC_NO":""})
}

function ret_KhdzydsInfo(_fromid,_funid,_flagtype,data){
	if(_funid=="5010:SIMPLE.99001339"){
	
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){
			glob.dlgflag="0"
		
		 	return;
		}else{
		
			 if(data.rows==undefined) data.rows=[]
			 if (data.rows[0].SIGN_DATE==undefined) 
			 {
			 	glob.dlgflag="0"
			 }
			 else
			 {
			 	glob.dlgflag="1"
			 }
		
			 return;
		 	 
		}
	

	}
}

// 提示电子合同书
function tsdzhss()
{
	var iHeight=500;
	var iWidth=700;
	var iTop = (window.screen.availHeight-30-iHeight)/2; //获得窗口的垂直位置;
	var iLeft = (window.screen.availWidth-10-iWidth)/2; //获得窗口的水平位置;



	var srcArray = [ str1,str2,str3];
  	var titleArray = ['合同说明书1','合同说明书2','合同说明书3'];
  	var srcArg = srcArray.join(';');
  	var titleArg = titleArray.join(';');


  	 window.open('./Demo.html?srcArg='+srcArg+'&titleArg='+titleArg,'testOpen','height='+iHeight+',width='+iWidth+',menubar=no,status=no,toolbar=no,titlebar=no,location=no,top='+iTop+',left='+iLeft);




//	$("#singlewt2").dialog("open")
	//$("#total2").text("电子合同书")
	
}


function setResult(result)
{	
	hResult=result
	if (hResult==1) 
	{	
		glob.dlgflag="1"	
		get_subXd()
	}
	else 
	{		
		glob.dlgflag="0"
		get_subXd()
	}
	
	
}


function get_subXd(){
	have=0;
	
	$('#cdwt').dialog('open');
	$("#cpcode").text(glob.cpcode)
	$("#cpname").text(glob.cpname)
	$("#wtrgje").text(glob.rgje)
}

var listdata=selectRow("INST_CODE")
function CheckCode(name,node,e){
	bFxts = false;
	if(name=="keyup"){

		if($(node).attr('value').length==6){
			var value = listdata($(node).attr('value'),"load");
			if (value!=-1){
				$("#inst_name").attr("value",value[1]["INST_SNAME"])
				$("#instjz").attr("value",value[1]["LAST_NET"])
				glob.cpbm=value[1].INST_ID
				$("#avafund").attr("value",glob.kyzj)
				
				
			}else{
				proInfo("没有该产品信息，请重新输入产品代码")
				
	    		return;
			}
		}else{
			
			$("#minrg").attr("value","")
			$("#minapp").attr("value","")
			$("#inst_name").attr("value","")
			$("#instjz").attr("value","")
			$("#avafund").attr("value","")
		}
	}
}

function get_subRg(){

	var CurrDay=getCur();
	if (KhFxdj=="" || KhFxdj==undefined || KhFxdj==null)
	{
		alert("您的还未做风险测评，请在理财标签下的理财风险测评选择对应的机构进行评测");
		return;
	};
	if (Cpyxrq<CurrDay)
	{
		alert("您的风险测评已过期，请在理财标签下的理财风险测评选择对应的机构进行评测");
		return;
	};







	if ((KhFxdj<CpFxdj) && (bFxts == false)  &&(KhFxdj!=CpFxdj) )
	{
		var obj = document.getElementById("total2")		


		obj.innerHTML="根据您的风险测评结果，您的风险承受能力级别为"+KhFxdjmc+"，您与该产品的风险等级不匹配。<br>我们需要提醒您，如果购买与风险不匹配的产品，可能使您遭受超出风险承受能力范围的损失。<br>请您确认：理解并愿意承担超限购买产品的风险，由此引起的一切损失及风险与本公司无关。"


		$('#singlewt2').dialog('open');			
		return
	};



	var singflag=""
	if (glob.signflag=="1")
	{
		singflag="1";
	};

	setIX({"funcid":"L2620100","funcname":'ret_subRg',"CUST_CODE":User.khh,"CUACCT_CODE":glob.zczh,"TA_CODE":glob.djjg,"TA_ACCT":glob.djzh,"TRANS_ACCT":glob.jyzh,
				"ISS_CODE":"","INST_CODE":"","INST_ID":glob.cpbm,"TRD_ID":"110","TRD_AMT":glob.rgje,"PAY_WAY":"1","BANK_CODE":"","PAY_ORG":"",
				"PAID_AMT":"","FRZ_AMT":"","FRZ_SIZE":"","LATEST_PAY_DATE":"","RISK_REVEAL_METHOD":glob.fxjs,"REFERRER_CODE":"","EC_SIGN_FLAG":singflag})

}


function ret_subRg(_fromid,_funid,_flagtype,data){	

	if(_funid=="5010:SIMPLE.L2620100"){
		data=FormatResult(data,1)
		if(data.ErrorCode!="0"){


			ErrorMsg=data.ErrorInfo

			if( (ErrorMsg.indexOf("27050005") != -1) || (ErrorMsg.indexOf("27040010") != -1) )
			{
				proInfo("您尚未签约，请您在阅读确认产品说明书、风险揭示书、法律意见书（如有），签署产品合同之后，再进行交易。")
				return
			}

			if(ErrorMsg.indexOf("27030080") != -1)
			{
				var obj = document.getElementById("total2")		


				obj.innerHTML="根据您的风险测评结果，您的风险承受能力级别为"+KhFxdjmc+"，您与该产品的风险等级不匹配。<br>我们需要提醒您，如果购买与风险不匹配的产品，可能使您承受超出能力范围的损失。<br>请您确认：理解并愿意承担超限购买产品的风险，由此引起的一切损失及风险与本公司无关。"

				$('#singlewt2').dialog('open');			
				return
			}



			if(data.ErrorCode=="27030080"){
				$("#singlewt").dialog("open")
				$("#total").attr("value","客户风险承受能力与产品风险等级不匹配,是否继续委托交易")
				return
			}else if(data.ErrorCode=="27030084"){
				proInfo("客户风险承受能力与产品风险等级不匹配，该产品不允许强制下单")
				return
			}else{
				proError(data.ErrorInfo)
				return
			}
		}else{
			proInfo("委托已提交,委托编号:"+data.rows[0].APP_SNO)
			glob.kyzj=0
			$("#rgje").attr("value","")
			$("#inst_code").attr("value","")
			$("#inst_name").attr("value","")
			$("#instjz").attr("value","")
			$("#instjz").attr("value","")
			$("#avafund").attr("value","")
			get_KhKyzj()
		}
	}
}


function onOk(){
	glob.dlgflag="1"
	$('#cdwt').dialog('close');
	OnSucWt()
	//$('#cdSucwt').dialog('open');
}
function onCance(){
	$('#cdwt').dialog('close');
}

function OnSucWt(){
	//$('#cdSucwt').dialog('close');
	get_Djzh()
//	get_subRg()
	
}
function onSinOk(){
	
	glob.dlgflag="1"
	
	$('#singlewt').dialog('close');
	//$('#cdSucwt').dialog('open');
}
function onSinCance(){
	$('#singlewt').dialog('close');
	
}

function onSinOk2(){
	glob.fxjs="1";
	glob.dzhtflag="1"
	bFxts = true;
	$('#singlewt2').dialog('close');
	get_subXd()
	//$('#cdSucwt').dialog('open');
}
function onSinCance2(){
	glob.fxjs="0";
	glob.dzhtflag="0"
	bFxts = true;
	$('#singlewt2').dialog('close');
	get_subXd()	
}


//获取产品信息接口
function L2612001(d){
	d=$.extend({"funcid":"L2612001"},{"ISS_CODE":"","INST_CODE":"","INST_ID":"","INST_TYPE":"","INST_CLS":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"},d)
	
	setIX(d)
}
function L2612039(d){
	d=$.extend({"funcid":"L2612039"},{"ISS_CODE":"","INST_CODE":"","INST_ID":"","INST_TYPE":"","INST_CLS":"","USER_TYPE":""},d)
	setIX(d)
}
function fmtFt(f){
	f=parseFloat(f)
	return isNaN(f)?0:f
}