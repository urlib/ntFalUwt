function PageInit(){
	  get_ZJInfo()
}
//请求登记账号
function get_ZJInfo(){
		setIX({"funcid":"L2610008","funcname":'ret_Djzh',"CUST_CODE":User.khh,"CUACCT_CODE":"","INT_ORG":"","PAGE_RECNUM":"0","PAGE_RECCNT":"500"})

}
//应答登记账号信息
function ret_Djzh(_fromid,_funid,_flagtype,data){
	hideLoading()	
	data=FormatResult(data,1)
	if(data.ErrorCode!="0"){
		if(data.ErrorInfo.indexOf("后台统一认证失败")!=-1)
		{
				proInfo("您还未开设理财帐户，请先开户");
		}
		else
		{
			proError(data.ErrorInfo)	
		}
		//$.messager.alert('提示',data.ErrorInfo,"error");
	 	return;
	}else{
		if(data.rows==undefined) data.rows=[]
	 	create_easygrid("理财账号查询",{},{"ACCT_STAT":{"formatter":getAcctStat},"ID_TYPE":{"formatter":getIdType}})
	 	upDate("load",data)
	}
}

