



function PageInit()
{
	alert("5555555555")
	onload()
}


var time = 0;
  	var timer;
  	var hint;
  	 var agreeBtn;
  	 var messageObj;
  	 var count = 0;
  	 var srcArray = [ "http://www.chinalions.com/trade/lc_fgz2_fxjs.htm","http://www.chinalions.com/trade/lc_fgz2_readme.htm","http://www.chinalions.com/trade/华林证券富贵竹2号合同.pdf" ];
  	 var titleArray = ['合同说明书1','合同说明书2','合同说明书3'];
  	function setTime()
  	{
  		var timeObj = document.getElementById('time');
  		timeObj.innerHTML = time;
  		if(time == 0)
  		{
  			 agreeBtn.removeAttribute('disabled');
  			  clearInterval(timer);
  			  hint.style.display='none';
  			  messageObj.className='black';
  		}
  		 time--;

  	}

  	function onload()
  	{

  		var iframeObj = document.getElementById('iframe');
  		// var titleObj = document.getElementById('title');
  		iframeObj.src = srcArray[0];
  		document.title.innerHTML = titleArray[0];
  		var okBtn = document.getElementById('ok');
  		var cancelBtn = document.getElementById('cancel');
  		agreeBtn = document.getElementById('agree');
  		hint = document.getElementById('hint');
  		messageObj = document.getElementById('message');
  		timer = setInterval(setTime,1000);
  		setTime();
  		cancelBtn.onclick = function(){
  			window.close();
        return;
  		}
  		okBtn.onclick = function(){
  			count++;
  			 if(count >= srcArray.length)
  			{
  				window.opener.setResult(1);
  				window.close();
  				return;
  			}

  			 iframeObj.src=srcArray[count];
  			 document.title.innerHTML = titleArray[count];
  			time = 0;
  			okBtn.disabled = true;
  			agreeBtn.disabled = true;
  			 agreeBtn.checked = false;
  			hint.style.display='inline';
  			  messageObj.className='gray';
  			timer = setInterval(setTime,1000);
  			setTime();
  		}
  		agreeBtn.onclick = function(){
  			if(agreeBtn.checked)
  			{
  				 okBtn.disabled = false;
  			}
  			else
  			{
  				 okBtn.disabled = true;

  			}
  		}

  	}
  