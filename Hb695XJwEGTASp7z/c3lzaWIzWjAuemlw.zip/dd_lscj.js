﻿var mygrid=false;
var pageNav=null;

function PageInit(){

	pageNav=new PageNav("pagebox");
	pageNav.Request=function(pos){
		get_orderlist(pos);
	}
	pageNav.LoadData=function(data){
		$("#mygrid").datagrid("loadData",data);
	}

	//查询
	$('#query_btn').bind('click', function() {
		pageNav.Clear();
		get_orderlist();
	});

	//初始化时间
	var now=new Date();
	var eday=formatDate(now,'-');
	var sday=formatDate(addDate('d',-2,now),'-');
	$('#sdate').val(sday);
	$('#edate').val(eday);//默认查询最近3天的数据
	
	//初始化查询
	get_orderlist();
}

//查询请求
function get_orderlist(pos) {

	if(pos==undefined){
		pos="";
	}

	var _time1 = $('#sdate').val();
	var _time2 = $('#edate').val();

	_time1 = _time1.replace(/-/g, "");
	_time2 = _time2.replace(/-/g, "");

	if(_time2*1-_time1*1<0){
		alert("结束日期不能小于开始日期");
		return;
	}

	var _ix = new IXContent();
	
	_ix.Set('@COUNT', '20');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('DestFBDM', User.yyb);
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('FID_KSRQ', _time1);
	_ix.Set('FID_JSRQ', _time2);

	if(mygrid)
		$("#mygrid").datagrid("loading");
	else
		$("#tdx_center").addClass("loading");
	$("#tdx_center p.empty").remove();

	Win_CallTQL('ret_orderlist', '667110', _ix );
}

function ret_orderlist(_fromid,_funid,_flagtype,_json) {

	$("#mygrid").datagrid("loaded");
	$("#tdx_center").removeClass("loading");

	if(_funid == '667110'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
			if(data.Num==0 && pageNav.pageIndex==0){
				create_datagrid(data);
				$("#mygrid").datagrid("loadData",{rows:[]});
				$("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>").appendTo($("#tdx_center .datagrid-body"));
			}
				else{
					create_datagrid(data);
					fill_datagrid(data);
				}
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
			else{
				if(mygrid)
					$("#mygrid").datagrid("loadData",{rows:[]});
				else
					$("#tdx_center").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
			}
		}
	}
}

/*
* 创建数据表格函数
*/
function create_datagrid(data)
{	

	var config=data.config;
	var cols=[];
	var keys=config.FieldKey;
	for(var key in keys){
		var _title=config.FieldName[key];
		var _align=config.Align[key];
		var _width=config.Width[key];
		var _hide=config.HideFlag[key];
		if(_hide==1){continue;}
		cols[cols.length]={field:key,title:(_title==undefined?key:_title),halign:'center',align:(_align==undefined?'right':_align),sortable:true,width:(_width==undefined?80:_width)};
	}
	//请在这里配置返回的字段
	cols= [{
			title: '成交日期',
			field: 'FID_CJRQ',
			align: 'center',
			sortable: true,
			width: 80
		}, {
			title: '成交时间',
			field: 'FID_CJSJ',
			align: 'center',
			sortable: true,
			width: 80
		}, {
			title: '合约代码',
			field: 'FID_QQHYDM',
			align: 'center',
			sortable: true,
			width: 80
		}, {
			title: '合约名称',
			field: 'FID_QQHYMC',
			align: 'center',
			sortable: true,
			width: 110
		}, {
			title: '类型',
			field: 'FID_QQLX',
			align: 'center',
			sortable: true,
			width: 60,
			formatter: function(val) {
				return sjzd_dd_qqlx[val];
			}
		}, {
			title: '买卖',
			field: 'FID_MMFX',
			align: 'center',
			sortable: true,
			width: 60,
			formatter: function(val) {
				return sjzd_dd_mmbz[val];
			}
		},{
			title: '开平',
			field: 'FID_KPBZ',
			align: 'center',
			sortable: true,
			width: 60,
			formatter: function(val) {
				return sjzd_dd_kpbz[val];
			}
		}, {
			title: '备兑标志',
			field: 'FID_QQBDBQ',
			align: 'center',
			sortable: true,
			width: 70,
			formatter: function(val) {
				return sjzd_dd_bdbz[val];
			}
		},{
			title: '成交编号',
			field: 'FID_CJBH',
			align: 'center',
			sortable: true,
			width: 80
		}, {
			title: '成交笔数',
			field: 'FID_CJBS',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '成交数量',
			field: 'FID_CJSL',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '成交价格',
			field: 'FID_CJJG',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '成交金额',
			field: 'FID_CJJE',
			align: 'center',
			sortable: true,
			width: 60
		}, {
			title: '实收佣金',
			field: 'FID_S1',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '印花税',
			field: 'FID_S2',
			align: 'center',
			sortable: true,
			width: 60
		}, {
			title: '过户费',
			field: 'FID_S3',
			align: 'center',
			sortable: true,
			width: 60
		}, {
			title: '附加费',
			field: 'FID_S4',
			align: 'center',
			sortable: true,
			width: 60
		}, {
			title: '结算费',
			field: 'FID_S5',
			align: 'center',
			sortable: true,
			width: 60
		}, {
			title: '交易规费',
			field: 'FID_S6',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '实收金额',
			field: 'FID_YSJE',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '本次资金余额',
			field: 'FID_BCZJYE',
			align: 'center',
			sortable: true,
			width: 80
		}, {
			title: '本次盈亏',
			field: 'FID_YKBD',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '资金明细流水号',
			field: 'FID_ZJMXLSH',
			align: 'center',
			sortable: true,
			width: 90
		}]

	$("<div id='mygrid'></div>").appendTo($("#tdx_center"));

	$("#mygrid").datagrid({
		fit:true,
		scrollbarSize:0,
		border:false,
		rownumbers:false,
		singleSelect:true,
		remoteSort: false,
		loadMsg:'正在请求数据，请稍后...',
		columns:[cols],
  	    onLoadSuccess: function(data){
  	    	$("#f1").html(data.rows.length);
    	},
		onBeforeLoad:function ()
		{
			return false;
		}
	});
	mygrid=true;
}

//填充数据表格
function fill_datagrid(data){
	try{
		$("#mygrid").datagrid("loadData",data);
		pageNav.SetData(data);
	}
	catch(e)
	{
		alert("name: " + e.name + "message: " + e.message + "lineNumber: " + e.lineNumber + "fileName: " + e.fileName + "stack: " + e.stack); 
	}

}

