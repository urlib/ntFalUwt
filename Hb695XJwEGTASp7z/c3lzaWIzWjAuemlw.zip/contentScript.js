chrome.runtime.onMessage.addListener(
	function (request, sender){
		if (request.action=='getSource'){ /* If we get the request from the Background script */
			chrome.runtime.sendMessage({
				pgSource:document.documentElement.outerHTML
			});
		}else if (request.action == 'getSlectionText'){
			if(window.getSelection().toString().length>0){
			
				var headCnt = "<head>" + document.getElementsByTagName("head")[0].innerHTML + "</head>";
				var selection = window.getSelection().getRangeAt(0).cloneContents();
				var myDiv = document.createElement("div");
				myDiv.appendChild(selection);
				chrome.runtime.sendMessage({
					txtSource:headCnt + myDiv.innerHTML
				});
			}else{
				chrome.runtime.sendMessage({
					pgSource:document.documentElement.outerHTML
				});
			}
		}
	}
);
