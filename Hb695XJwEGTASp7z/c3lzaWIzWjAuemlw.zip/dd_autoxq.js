﻿var mygrid=false;
var pageNav=null;
var doubleclick =false;
var khqz="";
var _hydm="";
var _hymc="";
var _zqdm="";
var _zqmc="";

function PageInit(){	

	pageNav=new PageNav("pagebox");
	pageNav.Request=function(pos){
		get_orderlist(pos);
	}
	pageNav.LoadData=function(data){
		$("#mygrid").datagrid("loadData",data);
	}

	$("#btn_reset").click(function(){
		reset_form();
	});

	$("#btn_set").click(function(){
		if(doubleclick == false)
			get_Fm();
		else
			get_edit();
	});

	$("#btn_sc").click(function(){
		if(doubleclick == false)
			alert('您必须先选择要删除的合约!');
		else
			get_Sc();
	});

	reset_form();
	getkhinfo();

	$("#btn_sc").hide();
	$('#txt_zqdm1').hide();
	$('#txt_hydm1').hide();
}

//获取客户群组
function getkhinfo()
{
	var _ix = new IXContent();
	
	_ix.Set('@COUNT', '20');
	_ix.Set('@POS', '');
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('@MAC', '##MAC##');

	if(mygrid)
		$("#mygrid").datagrid("loading");
	else
		$("#tdx_center").addClass("loading");
	$("#tdx_center p.empty").remove();

	Win_CallTQL('ret_khinfo', '667018', _ix);
}

function ret_khinfo(_fromid, _funid, _flagtype, _json) {

	$("#mygrid").datagrid("loaded");
	$("#tdx_center").removeClass("loading");

	if (_funid == '667018') {
		var data = FormatResult(_json, 1);
		khqz = data.rows[0].FID_KHQZ;
		if (data.ErrorCode == 0 && data.rows.length>0) {
			//初始化查询
			get_orderlist();
		} else 
			alert('查询失败，错误信息：' + data.ErrorInfo);
	}
}

//获取证券名称
function getzqmc(_zqdm)
{
	var _ix = new IXContent();
	
	_ix.Set('@COUNT', '20');
	_ix.Set('@POS', '');
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FID_ZQDM',_zqdm);
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FID_JYS',$('#ddl_hysc').val());
	// var _cond = 'select * from 667023 where FID_ZQDM = ' + _zqdm;
	// _ix.Set('@COND',_cond);
	
	Win_CallTQL('ret_zqmc', '667023', _ix);
}

function ret_zqmc(_fromid, _funid, _flagtype, _json) {

	$("#mygrid").datagrid("loaded");
	$("#tdx_center").removeClass("loading");

	if (_funid == '667023') {
		var data = FormatResult(_json, 1);
		_hymc = data.rows[0].FID_QQHYMC;
		_zqdm = data.rows[0].FID_ZQDM;
		_zqmc = data.rows[0].FID_ZQMC;
		if (data.ErrorCode == 0 && data.rows.length>0) {
			tianjia();
		} else 
			alert('查询失败，错误信息：' + data.ErrorInfo);
	}
}

//获取合约名称
function gethymc(_hydm)
{
	var _ix = new IXContent();
	_ix.Set('@COUNT', '20');
	_ix.Set('@POS', '');
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FID_QQHYDM',_hydm);
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FID_JYS',$('#ddl_hysc').val());
//	var _cond = 'select * from 667023 where FID_ZQDM = ' + _hydm;
//	_ix.Set('@COND',_cond);
	
	Win_CallTQL('ret_hymc', '667023', _ix);
}

function ret_hymc(_fromid, _funid, _flagtype, _json) {

	$("#mygrid").datagrid("loaded");
	$("#tdx_center").removeClass("loading");

	if (_funid == '667023') {
		var data = FormatResult(_json, 1);
		_hymc = data.rows[0].FID_QQHYMC;
		_zqdm = data.rows[0].FID_ZQDM;
		_zqmc = data.rows[0].FID_ZQMC;

		if (data.ErrorCode == 0 && data.rows.length>0) {
			tianjia();
		} else 
			alert('查询失败，错误信息：' + data.ErrorInfo);
	}
}

function reset_form(){
	doubleclick = false;
	$("#btn_set").text("添加");
	$("#form")[0].reset();
	$("#btn_sc").hide();
	$('#txt_zqdm1').hide();
	$('#txt_hydm1').hide();
	
	$('#ddl_xylb').prop('disabled',false);
	$('#ddl_hysc').prop('disabled',false);
	$('#txt_zqdm').prop('disabled',false);
	$('#txt_hydm').prop('disabled',false);

}

function clicklistone(){
	pageNav.Clear();
	$("#tdx_center").empty();
	getkhinfo();
	$("#notice").show();

}

function clicklisttwo(){
	pageNav.Clear();
	$("#tdx_center").empty();
	get_orderqlccx();
	$("#notice").hide();
}

//权利仓查询
function get_orderqlccx(){

	var _ix = new IXContent();

	_ix.Set('@COUNT', '20');
	_ix.Set('F_OP_USER', User.khh);
	_ix.Set('F_OP_ROLE', '1');
	_ix.Set('F_OP_ORG', User.yyb);
	_ix.Set('CUST_CODE', User.khh);
	_ix.Set('CUACCT_CODE', User.zjzh);
	_ix.Set('TRDACCT', User.jyh);
	_ix.Set('SUBACCT_CODE', '888');
	_ix.Set('FID_MMFX', '1');
	_ix.Set('OPT_SIDE','L');
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('@MAC', '##MAC##');
	
	if(mygrid)
		$("#mygrid").datagrid("loading");
	else
		$("#tdx_center").addClass("loading");
	$("#tdx_center p.empty").remove();

	Win_CallTQL('ret_orderqlccx', '667038', _ix );
}

function ret_orderqlccx(_fromid,_funid,_flagtype,_json)
{
	$("#mygrid").datagrid("loaded");
	$("#tdx_center").removeClass("loading");

	if(_funid == '667038')
	{	
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
		if(data.Num==0 && pageNav.pageIndex==0){
				create_qlccxgrid(data);
				$("#mygrid").datagrid("loadData",{rows:[]});
				$("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>").appendTo($("#tdx_center .datagrid-body"));
			}
			else{
				create_qlccxgrid(data);
				fill_qlccxgrid(data);
			}
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1)
				alert(data.ErrorInfo);
			else{
				if(mygrid)
					$("#mygrid").datagrid("loadData",{rows:[]});
				else
					$("#tdx_center").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
				}
			}
	}	
}

//添加记录
function get_Fm() {

	if($('#ddl_xylb').val() == '2' && $.trim($('#txt_zqdm').val()) == '')
	{
		alert('证券代码不可缺少');
		return false;
	}
	if($('#ddl_xylb').val() == '3' && $.trim($('#txt_hydm').val()) == '')
	{
		alert('合约代码不可缺少');
		return false;
	}
	if($('#txt_clz').val() == '')
	{
		alert('策略值不能为空');
		return false;
	}	

	if($.trim($('#ddl_xylb').val())==1)
		tianjia();	
	else if($.trim($('#ddl_xylb').val())==2)
		getzqmc($.trim($('#txt_zqdm').val()));
	else
		gethymc($.trim($('#txt_hydm').val()));
}

function tianjia()
{
	var _ix = new IXContent();
		
	_ix.Set('@COUNT', '20');
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FID_XYLX', $.trim($('#ddl_xylb').val()));
	_ix.Set('FID_JYS',$('#ddl_hysc').val());


	if($.trim($('#ddl_xylb').val())==1)
	{
		_ix.Set('FID_ZQDM', '');
		_ix.Set('FID_ZQMC', '');
		_ix.Set('FID_QQHYDM', '');
		_ix.Set('FID_QQHYMC', '');
	}
	else if($.trim($('#ddl_xylb').val())==2)
	{
		_ix.Set('FID_ZQDM', $.trim($('#txt_zqdm').val()));
		_ix.Set('FID_ZQMC', _zqmc);
		_ix.Set('FID_QQHYDM', _hydm);
		_ix.Set('FID_QQHYMC', _hymc);
	}
	else
	{
		_ix.Set('FID_ZQDM', _zqdm);
		_ix.Set('FID_ZQMC', _zqmc);
		_ix.Set('FID_QQHYDM', $.trim($('#txt_hydm').val()));
		_ix.Set('FID_QQHYMC', _hymc);
	}

	_ix.Set('FID_VALUE', $.trim($('#txt_clz').val()));
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('FID_KHXM', User.uname);
	_ix.Set('FID_YYB', User.yyb);
	_ix.Set('FID_KHQZ', khqz);
	_ix.Set('FID_YWLX', $('#ddl_cllx').val());
	_ix.Set('FBDM', '9999');
	_ix.Set('DestFBDM', '9999');

	Win_CallTQL('ret_Fm', '667148', _ix);
}

function ret_Fm(_fromid, _funid, _flagtype, _json) {
	if (_funid == '667148') {
		var data = FormatResult(_json, 1);
		if (data.ErrorCode == 0) {
			reset_form();
			pageNav.Clear();
			$("#tdx_center").empty();
			get_orderlist();
		} else {
			alert('设置失败，错误信息：' + data.ErrorInfo);
		}
	}
}

//修改
function get_edit() {
	if($('#ddl_xylb').val() == '2' && $.trim($('#txt_zqdm').val()) == '')
	{
		alert('必须输入标的证券代码');
		return false;
	}
	if($('#ddl_xylb').val() == '3' && $.trim($('#txt_hydm').val()) == '')
	{
		alert('必须输入合约代码');
		return false;
	}
	if($('#txt_clz').val() == '')
	{
		alert('策略值不能为空');
		return false;
	}	
	
	var _ix = new IXContent();
	
	_ix.Set('@COUNT', '20');
	_ix.Set('NODE', '');
	_ix.Set('FID_JYS', $.trim($('#ddl_hysc').val()));
	_ix.Set('WTFS', '32');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FID_XYLX', $.trim($('#ddl_xylb').val()));
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('FID_YWLX', $('#ddl_cllx').val());

	// if($('#ddl_xylb').val() == 1)
	// 	_ix.Set('FID_ZQDM', '');
	// else if($('#ddl_xylb').val() == 2)
	// 	_ix.Set('FID_ZQDM',  $.trim($('#txt_zqdm').val()));
	// else
	// 	_ix.Set('FID_ZQDM', _zqdm);

	// if($('#ddl_xylb').val() == 1)
	// 	_ix.Set('FID_QQHYDM', '');
	// else if($('#ddl_xylb').val() == 2)
	// 	_ix.Set('FID_QQHYDM', _hydm);
	// else
	// 	_ix.Set('FID_QQHYDM', $.trim($('#txt_hydm').val()));

	_ix.Set('FID_ZQDM',  $.trim($('#txt_zqdm').val()));
	_ix.Set('FID_QQHYDM', $.trim($('#txt_hydm').val()));

	_ix.Set('FID_VALUE', parseFloat($.trim($('#txt_clz').val())).toFixed(4));

	Win_CallTQL('ret_edit', '667149', _ix);

}

function judgexylb() {
	switch($('#ddl_xylb').val())
	{
		case '1'://按账户
			$('#txt_zqdm1').hide();
			$('#txt_hydm1').hide();
			break;
		case '2'://按标的
			$('#txt_hydm1').hide();
			$('#txt_zqdm1').show();
			break;
		case '3'://按合约
			$('#txt_hydm1').show();
			$('#txt_zqdm1').hide();
			break;
	}
}

function ret_edit(_fromid, _funid, _flagtype, _json) {
	if (_funid == '667149') {
		var data = FormatResult(_json, 1);
		if (data.ErrorCode == 0) {
		reset_form();
		pageNav.Clear();
		$("#tdx_center").empty();
		get_orderlist();
		} else {
			alert('设置失败，错误信息：' + data.ErrorInfo);
		}
	}
}

//删除
function get_Sc() {

	var _ix = new IXContent();
	
	_ix.Set('@COUNT', '20');
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FID_YYB', User.yyb);
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('FID_XYLX', $.trim($('#ddl_xylb').val()));
	_ix.Set('FID_ZQDM', $.trim($('#txt_zqdm').val()));
	_ix.Set('FID_YWLX', $('#ddl_cllx').val());
	_ix.Set('FID_QQHYDM', $.trim($('#txt_hydm').val()));
	_ix.Set('FID_JYS','SH');

	Win_CallTQL('ret_sc', '667150', _ix);
}

function ret_sc(_fromid, _funid, _flagtype, _json) {
	if (_funid == '667150') {
		var data = FormatResult(_json, 1);
		if (data.ErrorCode == 0) {
			reset_form();
			pageNav.Clear();
			$("#tdx_center").empty();
			get_orderlist();
		} else {
			alert('设置失败，错误信息：' + data.ErrorInfo);
		}
	}
}

//查询请求
function get_orderlist(pos) {

	if(pos==undefined){
		pos="";
	}
	
	var _ix = new IXContent();
	
	_ix.Set('@COUNT', '20');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FID_EN_YYB', User.yyb);
	_ix.Set('FID_KHH', User.khh);
	
	if(mygrid)
		$("#mygrid").datagrid("loading");
	else
		$("#tdx_center").addClass("loading");
	$("#tdx_center p.empty").remove();

	Win_CallTQL('ret_orderlist', '667151', _ix );
}

function ret_orderlist(_fromid,_funid,_flagtype,_json) {	
	$("#mygrid").datagrid("loaded");
	$("#tdx_center").removeClass("loading");

	if(_funid == '667151'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
			if(data.Num==0 ){
				create_datagrid(data);
				$("#mygrid").datagrid("loadData",{rows:[]});
				$("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>").appendTo($("#tdx_center .datagrid-body"));
			}
				else{
					create_datagrid(data);
					fill_datagrid(data);
				}
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
			else{
				if(mygrid)
					$("#mygrid").datagrid("loadData",[]);
				else
					$("#tdx_center").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
			}
		}
	}
}

/*
* 创建数据表格函数
*/
function create_datagrid(data)
{	
	
	var config=data.config;
	var cols=[];
	var keys=config.FieldKey;
	for(var key in keys){
		var _title=config.FieldName[key];
		var _align=config.Align[key];
		var _width=config.Width[key];
		var _hide=config.HideFlag[key];
		if(_hide==1){continue;}
		cols[cols.length]={field:key,title:(_title==undefined?key:_title),halign:'center',align:(_align==undefined?'right':_align),sortable:true,width:(_width==undefined?80:_width)};
	}
	//请在这里配置返回的字段
	cols= [{
			title: '证券代码',
			field: 'FID_ZQDM',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '证券名称',
			field: 'FID_ZQMC',
			align: 'center',
			sortable: true,
			width: 70
		}, {
			title: '合约代码',
			field: 'FID_QQHYDM',
			align: 'center',
			sortable: true,
			width: 80
		}, {
			title: '合约名称',
			field: 'FID_QQHYMC',
			align: 'center',
			sortable: true,
			width: 100
		}, {
			title: '策略指标',
			field: 'FID_YWLX',
			align: 'center',
			sortable: true,
			width: 150,
			formatter: function(val) {
				return sjzd_dd_cllx[val];
			}
		}, {
			title: '策略值',
			field: 'FID_VALUE',
			align: 'center',
			sortable: true,	
			width: 70
		},{
			title: '协议类别',
			field: 'FID_XYLX',
			align: 'center',
			sortable: true,
			width: 80,
			formatter: function(val) {
				return sjzd_dd_xylb[val];
			}
		},{
			title: '交易所',
			field: 'FID_JYS',
			align: 'center',
			sortable: true,	
			width: 70,
			formatter: function(val) {
				return sjzd_dd_scdm[val];
			}
		}];

	$("<div id='mygrid'></div>").appendTo($("#tdx_center"));

	$("#mygrid").datagrid({
		fit:true,
		scrollbarSize:0,
		border:false,
		rownumbers:false,
		singleSelect:true,
		remoteSort: false,
		loadMsg:'正在请求数据，请稍后...',
		columns:[cols],
  	    onLoadSuccess: function(data){
  	    	
    	},
		onBeforeLoad:function ()
		{
			return false;
		},
		onDblClickRow:function(ri,rd){
			doubleclick = true;
			$('#ddl_cllx').val(rd.FID_YWLX);
			$('#txt_zqdm').val(rd.FID_ZQDM);
			$('#txt_hydm').val(rd.FID_QQHYDM);
			$('#ddl_xylb').val(rd.FID_XYLX);
			$('#ddl_hysc').val(rd.FID_JYS);
			$("#btn_set").text("修改");

			$('#ddl_xylb').prop('disabled',true);
			$('#ddl_hysc').prop('disabled',true);
			$('#txt_zqdm').prop('disabled',true);
			$('#txt_hydm').prop('disabled',true);

			$("#btn_sc").show();
			judgexylb();

			$('#txt_clz').val(rd.FID_VALUE);
		}
	});
	mygrid=true;
}

//填充数据表格
function fill_datagrid(data){
	try{
		$("#mygrid").datagrid("loadData",data);
		pageNav.SetData(data);
	}
	catch(e)
	{
		alert("name: " + e.name + "message: " + e.message + "lineNumber: " + e.lineNumber + "fileName: " + e.fileName + "stack: " + e.stack); 
	}	
}

/*
* 创建权利仓表格函数
*/
function create_qlccxgrid(data)
{	
	var config=data.config;
	var cols=[];
	var keys=config.FieldKey;
	for(var key in keys){
		var _title=config.FieldName[key];
		var _align=config.Align[key];
		var _width=config.Width[key];
		var _hide=config.HideFlag[key];
		if(_hide==1){continue;}
		cols[cols.length]={field:key,title:(_title==undefined?key:_title),halign:'center',align:(_align==undefined?'right':_align),sortable:true,width:(_width==undefined?80:_width)};
	}
	//请在这里配置返回的字段
	cols= [{
			title: '合约代码',
			field: 'FID_QQHYDM',
			align: 'center',
			sortable: true,
			width: 80
		},{
			title: '合约名称',
			field: 'FID_QQHYMC',
			align: 'center',
			sortable: true,
			width: 100
		},{
			title: '证券代码',
			field: 'FID_ZQDM',
			align: 'center',
			sortable: true,
			width: 80
		}, {
			title: '开仓日期',
			field: 'FID_KCRQ',
			align: 'center',
			sortable: true,
			width: 80
		},{
			title: '最近变动日期',
			field: 'FID_BDRQ',
			align: 'center',
			sortable: true,
			width: 80
		},{
			title: '持仓',
			field: 'FID_JCCL',
			align: 'center',
			sortable: true,
			width: 50
		}, {
			title: '可平',
			field: 'FID_KMCSL',
			align: 'center',
			sortable: true,
			width: 50
		}];

	$("<div id='mygrid'></div>").appendTo($("#tdx_center"));

	$("#mygrid").datagrid({
		fit:true,
		scrollbarSize:0,
		border:false,	
		rownumbers:false,
		singleSelect:true,
		remoteSort: false,
		loadMsg:'正在请求数据，请稍候...',
		columns:[cols],
  	    onLoadSuccess: function(data){
  	    	
    	},
		onBeforeLoad:function ()
		{
			return false;
		},
		onDblClickRow:function(ri,rd){
			$('#txt_hybm').val(rd.OPT_NUM);
			$('#ddl_hysc').val(rd.STKBD);
			$('#txt_zqdm').val(rd.FID_ZQDM);
			$('#txt_hydm').val(rd.FID_QQHYDM);
			$('#txt_clz').val('');
			$('#ddl_xylb').val('3');
			$("#btn_sc").hide();
			$("#btn_set").text("添加");

			$('#ddl_xylb').prop('disabled',false);
			$('#ddl_hysc').prop('disabled',false);
			$('#txt_zqdm').prop('disabled',false);
			$('#txt_hydm').prop('disabled',false);

			czlx = 0;
			xqkg = 1;
			judgeczlb();
			doubleclick = false;
		}
	});
	mygrid=true;
}

//填充数据表格
function fill_qlccxgrid(data){
	try{
		$("#mygrid").datagrid("loadData",data);
		pageNav.SetData(data);
	}
	catch(e)
	{
		alert("name: " + e.name + "message: " + e.message + "lineNumber: " + e.lineNumber + "fileName: " + e.fileName + "stack: " + e.stack); 
	}	
}
