chrome.contextMenus.create({
		title : "Clip To OneNote Selection",
		contexts : ["selection"],
		onclick : clipSelection
});

function clipSelection(info, tab)
{
	clipNow(tab, 'getSlectionText');
}

chrome.contextMenus.create({
		title : "Clip To OneNote This Page",
		contexts : ["page", "link", "editable", "image", "video", "audio"],
		onclick : clipPage
});

function clipPage(info, tab)
{
	clipNow(tab, 'getSource');
}

var pg_URL2, pg_Title2;
function clipNow(tab, opt){

	pg_URL2 = tab.url;
	pg_Title2 = tab.title;
	if ((/^opera:/).test(pg_URL2) || pg_URL2 == "about:blank")
	{
		alert("Not a valid page");
		return;
	}
	chrome.tabs.sendMessage(tab.id, {action: opt});
}

chrome.runtime.onMessage.addListener(
	function (request, sender) {
		if (request.pgSource){
			sendToOneNote(request.pgSource);
		}else if (request.txtSource){
			sendToOneNote(request.txtSource);
		}
	}
);

function sendToOneNote(source)
{
	if (source === undefined)
	{
		alert('This document does not have a valid HTML mark up');
		return;
	}

	var div = document.createElement('div');
    div.innerHTML = source;
    var scripts = div.getElementsByTagName('noscript');
    var i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }

	scripts = div.getElementsByTagName('script');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
	
	scripts = div.getElementsByTagName('link');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
	
	scripts = div.getElementsByTagName('noframes');
    i = scripts.length;
    while (i--) {
      scripts[i].parentNode.removeChild(scripts[i]);
    }
	
    source = div.innerHTML;

	if (source.length <= 0)
	{
		alert('Nothing to clip');
		return;
	}
	
	var pg_Title = "<cliptoonenote-pgTitle>" + pg_Title2 + "</cliptoonenote-pgTitle>";
	var pg_URL = "<cliptoonenote-pgURL>" + pg_URL2 + "</cliptoonenote-pgURL>";
	var htmlCnt = "<BASE href='" + pg_URL2 + "' /> " + source + "<br>" + pg_Title + pg_URL;
	
	
	
	var theTextArea = document.getElementById("cliptoonenoteCbrd");
	theTextArea.value = htmlCnt;
	theTextArea.select();
	document.execCommand("Copy");
	theTextArea.value = '';
	
	//Call to server
	var errMsg = "Clip to OneNote Encountered an Error:\n\nPlease confirm whether:\n* The listener is running. (It is recommended to start it with windows)\n*The listener port is set correctly\n*You can download the listener using the link in the options page (http://j.madharasan.com/c21nl)";
	if (localStorage["cliptoonenotePort"] == undefined)
	{
		localStorage["cliptoonenotePort"] = '2866';
	}

	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function (data)
	{
		if (xhr.readyState == 4)
		{
			if (xhr.status == 200)
			{
				if (xhr.responseText.trim() != "success")
					alert(xhr.responseText);
			}
			else
				alert(errMsg);
		}
	}
	var url = 'http://localhost:' + localStorage["cliptoonenotePort"] + '/ClipToOneNote';
	xhr.open('GET', url, true);
	xhr.send();
}