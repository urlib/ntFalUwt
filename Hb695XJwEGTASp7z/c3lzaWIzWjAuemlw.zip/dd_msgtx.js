var SelParm = null;

var statue = '';
var statueNum = '';

var HYChane1 = '',HYChane2 = '',HYChane3 = '';
var CCHYChane1= '',CCHYChane2= '',CCHYChane3= '';

var sday='';
var eday='';

var bdccbz = false;
var bdyqbz = false;

//=====================================================合约有调整提醒=====================================================
var mygrid1=false;
var pageNav1=null;

function getcchylist1(pos)
{
	if(pos==undefined){
		pos="";
	}
	
	var _ix = new IXContent();
	
	SelParm = "Select FID_QQHYDM From 667038 ";
	_ix.Set('@COND',SelParm);	
	_ix.Set('@COUNT', '100');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('DestFBDM', User.yyb);
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('@MAC', '##MAC##');
	Win_CallTQL('ret_cchylist1', '667038', _ix );
}

function ret_cchylist1(_fromid,_funid,_flagtype,_json) {	
	if(_funid == '667038'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
				CCHYChane1 = data.rows;
				FindHy1();
				}
		 else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
		}
	}
}

function FindHy1()
{
	var tmp = [];	
	for(var j=0;j<CCHYChane1.length;j++)
	{
		for(var i=0;i<HYChane1.length;i++)
		{
			if(CCHYChane1[j].FID_QQHYDM == HYChane1[i].FID_QQHYDM)
			{
				if(HYChane1[i].FID_DQBH == '1')
				{
					tmp[tmp.length]=HYChane1[i];
					break;
				}
			}	
		}
	}
	create_bjk1(tmp);
}

//查询请求
function get_orderlist1(pos) {

	if(pos==undefined){
		pos="";
	}

	var _ix = new IXContent();
	
	SelParm = "Select FID_QQHYDM,FID_QQHYMC,FID_TZMS From 667023 Where FID_TZMS = '1'";
	_ix.Set('@COND',SelParm);
	_ix.Set('@COUNT', '2000');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('DestFBDM', User.yyb);

	if(mygrid1)	
		$("#mygrid1").datagrid("loading");
	else
		$("#tdx_center1").addClass("loading");
	$("#tdx_center1 p.empty").remove();

	Win_CallTQL('ret_orderlist1', '667023', _ix );
}

function ret_orderlist1(_fromid,_funid,_flagtype,_json) {
	$("#mygrid1").datagrid("loaded");
	$("#tdx_center1").removeClass("loading");
	if(_funid == '667023'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
			if(data.Num==0 && pageNav1.pageIndex==0){
				$("#mygrid1").datagrid("loadData",{rows:[]});
				$("<p class='empty' style='text-align:center;margin-top:5%;'>暂无记录</p>").appendTo($("#tdx_center1 .datagrid-body"));
			}
				else{
					HYChane1 = data.rows;
					getcchylist1();
				}
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
			else{
				if(mygrid1)
					$("#mygrid1").datagrid("loadData",{rows:[]});
				else
					$("#tdx_center1").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
			}
		}
	}
}

function create_bjk1(tmp)
{
	var tmpstring='',RiskKeyString='';
	for(var i =0; i < tmp.length; i++){
		tmpstring = $.trim(tmp[i].FID_QQHYDM)+','+$.trim(tmp[i].FID_QQHYMC)+','+$.trim(tmp[i].FID_DQRQ)+','+'快到期'+'\r\n'+'\r\n';
		RiskKeyString +=tmpstring;
	}
	document.getElementById("wbk1").value=RiskKeyString;
}

//=====================================================合约快到期提醒=====================================================
//全部2一把
var mygrid2=false;
var pageNav2=null;

//查询请求
function getcchylist2(pos)
{
	if(pos==undefined){
		pos="";
	}
	
	var _ix = new IXContent();
	
	SelParm = "Select FID_QQHYDM From 667038 ";
	_ix.Set('@COND',SelParm);	
	_ix.Set('@COUNT', '100');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('DestFBDM', User.yyb);
	_ix.Set('FID_KHH', User.khh);
	Win_CallTQL('ret_cchylist2', '667038', _ix);
}

function ret_cchylist2(_fromid,_funid,_flagtype,_json) {	
	if(_funid == '667038'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
			CCHYChane2 = data.rows;
			FindHy2();
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
		}
	}
}

function FindHy2()
{
	var tmp = [];

	for(var j=0;j<CCHYChane2.length;j++)
	{
		for(var i=0;i<HYChane2.length;i++)
		{
			if(CCHYChane2[j].FID_QQHYDM == HYChane2[i].FID_QQHYDM)
			{
				if(HYChane2[i].FID_TZMS == '1')
				{
					tmp[tmp.length]=HYChane2[i];
					break;
				}
			}	
		}
	}
	create_bjk2(tmp)
}

//查询请求
function get_orderlist2(pos) {

	if(pos==undefined){
		pos="";
	}

	var _ix = new IXContent();
	
	SelParm = "Select FID_QQHYDM,FID_QQHYMC,FID_DQBH,FID_DQRQ,FID_XGRQ,FID_XQJG From 667023 Where FID_DQBH = '1'";
	_ix.Set('@COND',SelParm);
	_ix.Set('@COUNT', '2000');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('DestFBDM', User.yyb);

	if(mygrid2)
		$("#mygrid2").datagrid("loading");
	else
		$("#tdx_center2").addClass("loading");
	$("#tdx_center2 p.empty").remove();

	Win_CallTQL('ret_orderlist2', '667023', _ix );
}

function ret_orderlist2(_fromid,_funid,_flagtype,_json) {
	$("#mygrid2").datagrid("loaded");
	$("#tdx_center2").removeClass("loading");
	if(_funid == '667023'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
				if(data.Num==0 && pageNav2.pageIndex==0){
					$("#mygrid2").datagrid("loadData",{rows:[]});
					$("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>").appendTo($("#tdx_center2 .datagrid-body"));
				}
				else{
					HYChane2 = data.rows;
					getcchylist2();
				}
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
			else{
				if(mygrid2)
					$("#mygrid2").datagrid("loadData",{rows:[]});
				else
					$("#tdx_center2").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
			}
		}
	}
}

function create_bjk2(tmp)
{
	var tmpstring='',RiskKeyString='';
	for(var i =0; i < tmp.length; i++){
		tmpstring = $.trim(tmp[i].FID_QQHYDM)+','+$.trim(tmp[i].FID_QQHYMC)+','+$.trim(tmp[i].FID_DQRQ)+','+'有近期调整'+'\r\n'+'\r\n';
		RiskKeyString +=tmpstring;
	}
	document.getElementById("wbk2").value=RiskKeyString;
}

//=====================================================被指派行权提醒====================================================
var mygrid3=false;
var pageNav3=null;

function get_orderlist3(pos) {

	if(pos==undefined){
		pos="";
	}

	var _ix = new IXContent();
	
	_ix.Set('FID_KPBZ ','X');
	_ix.Set('@COUNT', '100');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('@MAC', '##MAC##');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('DestFBDM', User.yyb);
	_ix.Set('FID_KHH', User.khh);

	if(mygrid3)
		$("#mygrid3").datagrid("loading");
	else
		$("#tdx_center3").addClass("loading");
	$("#tdx_center3 p.empty").remove();

	Win_CallTQL('ret_orderlist3', '667112', _ix );
}

function ret_orderlist3(_fromid,_funid,_flagtype,_json) {
	$("#mygrid3").datagrid("loaded");
	$("#tdx_center3").removeClass("loading");
	if(_funid == '667112'){
		var data = FormatResult(_json,1);
		if(data.ErrorCode == 0)
		{
			statue = data.rows;
			statueNum = data.Num;
		}
		if (data.ErrorCode == 0) {
				if(data.Num==0 && pageNav3.pageIndex==0){
					$("#mygrid3").datagrid("loadData",{rows:[]});
					$("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>").appendTo($("#tdx_center3 .datagrid-body"));
				}
				else
					create_bjk3();
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
			else{
				if(mygrid3)
					$("#mygrid3").datagrid("loadData",{rows:[]});
				else
					$("#tdx_center3").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
			}
		}
	}
}

function create_bjk3()
{
	var tmpstring='',RiskKeyString='';
	var tmpUnits='';
	for(var i =0;i < statueNum; i++){
		if((statue[i].FID_QQHYDM).length==6)
			tmpUnits='股';
		else
			tmpUnits='张';
		tmpstring = $.trim(statue[i].FID_QQHYDM)+','+$.trim(statue[i].FID_QQHYMC)+','+$.trim(statue[i].FID_CJSL)+tmpUnits+','+$.trim(statue[i].FID_CJRQ)+','+'有被指派的行权'+'\r\n'+'\r\n';
		RiskKeyString +=tmpstring;
	};
	document.getElementById("wbk3").value=RiskKeyString;	
}

//=====================================================备兑持仓不足提醒=====================================================
var mygrid4=false;
var pageNav4=null;

var HYChane4 = '';
var CCHYChane4 = '';
var BDHY='';

function get_orderlist4(pos)
{
	if(pos==undefined){
		pos="";
	}

	var _ix = new IXContent();

	_ix.Set('FID_TZLB', '2');   //通知类别
	_ix.Set('FID_KSRQ', sday);  //开始日 期
	_ix.Set('FID_JSRQ', eday);  //结束日期
	_ix.Set('@MAC', '##MAC##');

	if(mygrid4)
		$("#mygrid4").datagrid("loading");
	else
		$("#tdx_center4").addClass("loading");
	$("#tdx_center4 p.empty").remove();

	Win_CallTQL('ret_orderlist4', '667171', _ix);
}

function ret_orderlist4(_fromid,_funid,_flagtype,_json) {
	$("#mygrid4").datagrid("loaded");
	$("#tdx_center4").removeClass("loading");
	if(_funid == '667171'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
				if(data.Num==0 && pageNav4.pageIndex==0){
					$("#mygrid4").datagrid("loadData",{rows:[]});
					$("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>").appendTo($("#tdx_center4 .datagrid-body"));
				}
				else{
					HYChane4 = data.rows;
					getcchylist4();
				}			
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
			else{
				if(mygrid4)
					$("#mygrid4").datagrid("loadData",{rows:[]});
				else
					$("#tdx_center4").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
			}
		}
	}
}

function getcchylist4(pos)
{
	if(pos==undefined){
		pos="";
	}
	
	var _ix = new IXContent();
	
	SelParm = "Select FID_QQHYDM From 667018 ";
	_ix.Set('@COND',SelParm);	
	_ix.Set('@COUNT', '100');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('DestFBDM', User.yyb);
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('@MAC', '##MAC##');
	Win_CallTQL('ret_cchylist4', '667018', _ix );
}

function ret_cchylist4(_fromid,_funid,_flagtype,_json) {	
	if(_funid == '667018'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
				CCHYChane4 = data.rows;
				FindHy4();
				}
		 else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
		}
	}
}

function FindHy4()
{
	var tmp = [];	
	for(var j=0;j<CCHYChane4.length;j++)
	{
		for(var i=0;i<HYChane4.length;i++)
		{
			if(CCHYChane4[j].FID_GDH+CCHYChane4[j].FID_ZZHBM == HYChane4[i].FID_GDH)
				bdccbz = true;				
		}
	}
	create_bdyq();
}

// //=====================================================备兑预期不足提醒=====================================================
var mygrid5=false;
var HYChane5 = '';
var CCHYChane5 = '';
//查询请求

function get_orderlist5(pos)
{
	if(pos==undefined){
		pos="";
	}

	var _ix = new IXContent();

	_ix.Set('FID_TZLB', '3');   //通知类别
	_ix.Set('FID_KSRQ', sday);  //开始日 期
	_ix.Set('FID_JSRQ', eday);  //结束日期
	_ix.Set('@MAC', '##MAC##');

	if(mygrid5)
		$("#mygrid5").datagrid("loading");
	else
		$("#tdx_center5").addClass("loading");
	$("#tdx_center5 p.empty").remove();

	Win_CallTQL('ret_orderlist5', '667171', _ix);
}

function ret_orderlist5(_fromid,_funid,_flagtype,_json) {
	$("#mygrid5").datagrid("loaded");
	$("#tdx_center4").removeClass("loading");
	if(_funid == '667171'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
				if(data.Num==0 && pageNav4.pageIndex==0){
					$("#mygrid5").datagrid("loadData",{rows:[]});
					$("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>").appendTo($("#tdx_center4 .datagrid-body"));
				}
				else{
					HYChane5 = data.rows;
					getcchylist5();
				}			
		} else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
			else{
				if(mygrid5)
					$("#mygrid5").datagrid("loadData",{rows:[]});
				else
					$("#tdx_center4").html("<p class='empty' style='text-align:center;margin-top:15%;'>暂无记录</p>");
			}
		}
	}
}

function getcchylist5(pos)
{
	if(pos==undefined){
		pos="";
	}
	
	var _ix = new IXContent();
	
	SelParm = "Select FID_QQHYDM From 667018 ";
	_ix.Set('@COND',SelParm);	
	_ix.Set('@COUNT', '100');
	_ix.Set('@POS', pos);
	_ix.Set('NODE', '');
	_ix.Set('WTFS', '32');
	_ix.Set('FBDM', User.yyb);
	_ix.Set('DestFBDM', User.yyb);
	_ix.Set('FID_KHH', User.khh);
	_ix.Set('@MAC', '##MAC##');
	Win_CallTQL('ret_cchylist5', '667018', _ix );
}

function ret_cchylist5(_fromid,_funid,_flagtype,_json) {	
	if(_funid == '667018'){
		var data = FormatResult(_json,1);
		if (data.ErrorCode == 0) {
				CCHYChane5 = data.rows;
				FindHy5();
				}
		 else {
			if(data.ErrorInfo.indexOf("没有查询数据")==-1){
				alert(data.ErrorInfo);
			}
		}
	}
}

function FindHy5()
{
	var tmp = [];	
	for(var j=0;j<CCHYChane5.length;j++)
	{
		for(var i=0;i<HYChane5.length;i++)
		{
			if(CCHYChane5[j].FID_GDH+CCHYChane5[j].FID_ZZHBM == HYChane5[i].FID_GDH)
				bdyqbz = true;				
		}
	}
	create_bdyq();
}

function create_bdyq()
{
	 var tmpstring1='',tmpstring1='',RiskKeyString='';
	 if(bdccbz)
	 	tmpstring1 = '备兑持仓不足!';
	 if(bdyqbz)
	 	tmpstring2 = '您的合约持仓中有合约近期会有调整，可能导致备兑持仓不足！';
	RiskKeyString = tmpstring1 + '\r\n' + tmpstring2;
	document.getElementById("wbk4").value=RiskKeyString;	
}

//======================================================初始化===========================================================
function PageInit(){
	
	//================================合约调整提醒初始化

	pageNav1=new PageNav("pagebox1");
	pageNav1.Request=function(pos){
		get_orderlist1(pos);
	}
	pageNav1.LoadData=function(data){
		$("#mygrid1").datagrid("loadData",data);
	}
	get_orderlist1();

	//================================合约快到期提醒初始化

	pageNav2=new PageNav("pagebox2");
	pageNav2.Request=function(pos){
		get_orderlist2(pos);
	}
	pageNav2.LoadData=function(data){
		$("#mygrid2").datagrid("loadData",data);
	}
	get_orderlist2();

	//=================================被指派行权提醒初始化

	pageNav3=new PageNav("pagebox3");
	pageNav3.Request=function(pos){
		get_orderlist3(pos);
	}
	pageNav3.LoadData=function(data){
		$("#mygrid3").datagrid("loadData",data);
	}
	get_orderlist3();
	
	//=================================备兑持仓不足提醒

	pageNav4=new PageNav("pagebox4");
	pageNav4.Request=function(pos){
		get_orderlist4(pos);
	}
	pageNav4.LoadData=function(data){
		$("#mygrid4").datagrid("loadData",data);
	}
	get_orderlist4();
	
	//=================================备兑预期不足提醒

	pageNav5=new PageNav("pagebox5");
	pageNav5.Request=function(pos){
		get_orderlist5(pos);
	}
	pageNav5.LoadData=function(data){
		$("#mygrid5").datagrid("loadData",data);
	}
	get_orderlist5();

	//初始化时间
	var now=new Date();
	eday=formatDate(now,'-');
	sday=formatDate(now,'-');//开始和结束都是当天日期

	eday = eday.replace(/-/g, "");
	sday = sday.replace(/-/g, "");

}