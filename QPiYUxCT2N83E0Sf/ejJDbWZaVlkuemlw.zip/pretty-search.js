﻿var localGoogleLocal=null;
(function() {

	function YahooSearch(){
        var elm=document.getElementById("So0");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("So3");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("So1");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("WS2aj");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("So2");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
	}

    function GoogleSearch(){
        var elm=document.getElementById("tvcap");
        if(elm){
             elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("mbEnd");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("bottomads");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("rhs_block");
        if(elm){
            elm.parentNode.removeChild(elm);
        }

    }

    function RakutenSearch(){
        var elm=document.getElementById("sponcerMain");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("adBlock");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("ad-ichiba");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
        elm=document.getElementById("down_teamsite");
        if(elm){
            elm.parentNode.removeChild(elm);
        }
    }

    function BINGSearch(){
        try{
            $('div.sb_adsW').remove();
        }catch(e){

        }
        $('div.sb_adsN').remove();
        $('div.b_ad').remove();
        
    }

    function YoutubeSearch(){
        try{
             $('div.promoted-videos').remove();
        }catch(e){

        }
       
        $('div.secondary-col').remove();
    }

    function GooSearch(){
        try{
            $('div.sponser').remove(); 
        }catch(e){
            
        }
        
        $('#rside').remove(); 

    }

    function LiveDoorSearch(){
        try{
            $('div.ad_livedoor').remove(); 
        }catch(e){
           
        }
        try{
            $('div.MdSubHeadAd01').remove(); 
        }catch(e){

        }
         try{
            $('div.MdSubAdList01').remove(); 
        }catch(e){

        }

    }

    function ExiteSearch(){
        try{
            $('div.adLink').remove(); 
        }catch(e){

        }
         $('#rakuten_mw').remove(); 
        
    }

    function NichanSearch(){
        try{
            $('#wrap_topbanner').remove(); 
        }catch(e){

        }

        try{
            $('#jlisting').remove(); 
        }catch(e){

        }
        $('#adlantis').remove(); 
        
    }
   
    function FC2Search(){
        
         try{
            $('#ads').remove(); 
        }catch(e){

        }
        try{
            $('#ads').remove(); 
        }catch(e){

        }
    }

    function NaverSearch(){
        try{
            $('section.ArMain20').remove(); 
        }catch(e){

        }
    }

    function USYahooSearch(){
        try{
            $('div.ads').remove(); 
        }catch(e){

        }
        try{
            $('div.ad_loc_top').remove(); 
        }catch(e){

        }
        try{
            $('div.ad_loc_bot').remove(); 
        }catch(e){

        }
        try{
            $('div.ad_loc_east').remove(); 
        }catch(e){

        }
         
        try{
            $('ol.q1747').remove(); 
        }catch(e){

        }
        try{
            $('ol.g07m9039el').remove(); 
        }catch(e){

        }
        try{
            $('ol.nb507').remove(); 
        }catch(e){

        }
        try{
            $('ol.l1a88').remove(); 
        }catch(e){

        } try{
            $('ol.m97i71j0ie').remove(); 
        }catch(e){

        }  try{
            $('ol.lv5z060vn9').remove(); 
        }catch(e){

        }  
        try{
            $('ol.w6292').remove(); 
        }catch(e){

        }  
        try{
            $('ol.n054t024r6').remove(); 
        }catch(e){

        }  
        try{
            $('ol.xm28d39km4').remove(); 
        }catch(e){

        }  
          
        
        
    }

    function AskSearch(){
        try{
            $('div.ad-top').remove(); 
        }catch(e){

        }
        try{
            $('div.adWrapper').remove(); 
        }catch(e){

        }
        
    }

    function RemoveAds(){
        clearInterval(localGoogleLocal);
    	if(document.domain.indexOf("yahoo.co.jp")!=-1){
    		YahooSearch();
    	} else if (document.domain=="www.google.co.jp" || document.domain=="www.google.com"||document.domain=="www.google.co.in"||document.domain=="www.google.com.ar"||document.domain=="www.google.ca"||document.domain=="www.google.com.tw") {
            localGoogleLocal=setInterval(function() {
                    GoogleSearch();
            }, 1000); 
        }else if (document.domain=="websearch.rakuten.co.jp") {
            RakutenSearch();
        } else if (document.domain=="www.youtube.com") {
            YoutubeSearch();
        }else if (document.domain.indexOf("bing.com")!=-1){
            BINGSearch();
        }else if(document.domain=="search.goo.ne.jp"){
            GooSearch();
        } else if(document.domain=="livedoor-search.naver.jp"){
            LiveDoorSearch();
        } else if(document.domain=="cgi.search.biglobe.ne.jp"){
            $('div.sponArea').remove(); 
        }else if(document.domain=="websearch.excite.co.jp"){
           ExiteSearch();
        }else if(document.domain=="find.2ch.net"){
            NichanSearch();
        } else if(document.domain=="search.fc2.com"){
            FC2Search();
        }else if(document.domain=="search.naver.jp"){
            NaverSearch();
        } else if(document.domain.indexOf("search.yahoo.com")!=-1){
            USYahooSearch();
        }else if(document.domain.indexOf("ask.com")!=-1){
        	AskSearch();
        } 
       
        else if(document.domain=="www.google.com.hk"){
            helpGoogle();
        }else if(document.domain=="www.baidu.com"){
             helpBaidu();
        }else if(document.domain=="www.sogou.com") {
            helpSogou();
        } else if(document.domain=="www.soso.com"){
            helpSoso();
        } else if(document.domain=="www.so.com"||document.domain=="www.360.cn"){
             help360();
        } else if(document.domain=="www.so-net.ne.jp"){
            if($('#sponsor_main')){
                $('#sponsor_main').remove();
            }
        } else if(document.domain=="search.nifty.com"){
        	 try{
           	 	$('#lst1').remove(); 
           	 	$('#lst2').remove();
           	 	$('#sIn').remove(); 
           	 	
        	}catch(e){

       	 	}
        }  else if(document.domain=="search.fresheye.com"){
        	$('div.spsite bk2').remove(); 
        	$('div.sub-spsite').remove(); 
        	
        } else if(document.domain=="www.nextseek.net"){
		$('#google').remove(); 
           	$('#rakuten').remove();
		$('#ads_top').remove(); 
		$('div.l-r').remove(); 

	}
 		
    }
    function openamazonwin(){
    	var now_time = new Date();
        now_time.setTime(now_time.getTime() + (60 * 60 * 1000));
        document.cookie="denialsmartproofstrategy=hidden;" + 'expires='+now_time.toGMTString() + ';domain=.'+document.domain+';path=/';
       var url=this.href;
       window.open(url+"&tag=sonet-track-22");
    }
    function help360(){
        //从360搜索跳过来的地址直接进入百度,不做鱼肉做渔翁
        if(document.location.host=='www.baidu.com' && document.location.pathname.indexOf('/search/ressafe.html')>-1){
            if($('#warning_url')[0]){
                $('#warning_url')[0].click();
            }
        }
        //屏蔽360搜索结果的推广
        if(document.location.host.match(/(so\.com|so\.360\.cn)/) && document.location.pathname.indexOf('/s')>-1){
            $('div.spread').remove();
        }
        try{
        $('div.e-buss').remove();
        }catch(e){
        	
        }
       
    }

    function helpSoso(){
        //屏蔽SOSO搜索结果的推广
        if(document.location.host=='www.soso.com' && document.location.pathname.indexOf('/q')>-1){
            $('div.ad_zdq,#rads').remove();
        }
    }

    function helpSogou(){
        //屏蔽Sogou搜索结果的推广
        if(document.location.host=='www.sogou.com' && document.location.pathname.indexOf('/web')>-1){
            $('#promotion_adv_container,div.sponsored').remove();


        }
    }

    function helpGoogle(){
        //屏蔽Google搜索结果的推广
        if(document.location.host=='www.google.com.hk' && document.location.pathname.indexOf('/search')>-1){
            $('#tvcap,#mbEnd').remove();
        }
    }


    function helpBaidu(){
        if(document.location.href.indexOf('www.baidu.com')>-1){
            //百度推广屏蔽
            //同时要屏蔽的网站
            var fdomain=[];
            $('table.sftip').remove();
            $('#container>br:first').remove();
        
            if(typeof(localStorage['baidu_right'])=='undefined'){
                localStorage['baidu_right']=0;
            }
            var baidu_right=parseInt(localStorage['baidu_right']);
            if(baidu_right<=0){
                $('#content_right').remove();
            }else{
                var next_page=Uri('pn','+'+baidu_right+'0');
                $('#content_right').width('50%').load(next_page+' #content_left');
            }
            $('table.ec_pp_f,table[bgcolor="#f5f5f5"]').each(function(i){
                $(this).next('br,script').remove().end().remove();
            });
            $('table').each(function(){
                var cont='';
                cont=$(this).find('span.g');
                if(cont.length<1){ cont=$(this).find('font[color="#008000"]');}
                if(cont.length<1){
                    return true;
                }else{
                    cont=cont.html();
                }
                for(var d in fdomain){
                    if(cont.indexOf(fdomain[d])>-1){
                        $(this).remove();
                    }
                }
            });
            $('br').next('br').remove();
        }
    }

    function Uri($var,$val){
        var url=document.location.pathname;
        var param=document.location.search.substr(1).split('&');
        var obj={};
        var k,a;
        for(k in param){
            a=param[k].split('=');
            //key=a[0] value=a[1]
            if(a[1]==undefined){ a[1]=''; }
            obj[a[0]]=a[1];
            if(a[0]==$var){
                if($val.indexOf('+')>-1){
                    obj[a[0]]=parseInt(a[1])+parseInt($val);
                }else if($val.indexOf('-')>-1){
                    obj[a[0]]=parseInt(a[1])-parseInt($val);
                }else{
                    obj[a[0]]=$val;
                }
            }
        }
        if(obj[$var]==undefined){
            obj[$var]=$val;
        }
        url+='?'+decodeURI($.param(obj));
        return url;
    }

    function WriteCookie(){
        var now_time = new Date();
        now_time.setTime(now_time.getTime() + ( 24 * 60 * 60 * 1000*7));
        document.cookie="denialsmartproofstrategy=hidden;" + 'expires='+now_time.toGMTString() + ';domain=.'+document.domain+';path=/';
    }

    function readFromCookie(name) {
        var cookieString = document.cookie;
        var cookieKeyArray = cookieString.split(";");
        for (var i=0; i<cookieKeyArray.length; i++) {
            var targetCookie = cookieKeyArray[i];
            targetCookie = targetCookie.replace(/^\s+|\s+$/g, "");

            var valueIndex = targetCookie.indexOf("=");
            if (targetCookie.substring(0, valueIndex) == name) {
                return unescape(targetCookie.slice(valueIndex + 1));
            }
        }
        return "";
    }

	RemoveAds();
})();