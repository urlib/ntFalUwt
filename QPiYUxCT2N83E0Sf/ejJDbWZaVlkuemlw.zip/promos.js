$(document).ready(function(){
    window.setTimeout(function() {

        var getNewPromo = false;

        //should we check for new promo?
        if (!getCookie('promo_last_check') || getCookie('promo_last_check') == 'undefined' || getCookie('promo_last_check') == '' || !getCookie('promo_emoji_id') || getCookie('promo_emoji_id') == 'undefined' || getCookie('promo_emoji_id') == '' || !getCookie('promo_active_id') || getCookie('promo_active_id') == 'undefined' || getCookie('promo_active_id') == '') {
            //no cookie was defined
            getNewPromo = true;
        } else {
            //cookie is found, was it last checked more than 3 hours ago?
            var lastCheck = getCookie('promo_last_check');
            var timeNow = new Date().getTime() / 1000;
            if (timeNow - lastCheck > 60 * 60 * 3) {
                getNewPromo = true;
            }
        }

        //did user previously choose to hide a promo?
        if (getCookie('promo_last_closed') && getCookie('promo_last_closed') != 'undefined' && getCookie('promo_last_closed') != '') {
            var lastClosedPromo = parseInt(getCookie('promo_last_closed'));
        } else {
            var lastClosedPromo = 0;
        }

        //should we check for a new promo?
        if (getNewPromo == true) {
            setNewPromo();
        } else {
            //if the user chose to close this promo, don't show
            if (lastClosedPromo == parseInt(getCookie('promo_active_id'))) {
                $('.ad_wrapper').hide();
            } else {
                //update view with existing promo data
                $('.ad_icon_popout').attr('data-id', getCookie('promo_active_id'));
                $('.ad_text').attr('href', getCookie('promo_link_url'));
                $('.ad_text').html(getCookie('promo_link_title'));
                $('.ad_text').css('color', getCookie('promo_link_color'));
                $('.inner_ad').css('background-color', getCookie('promo_bar_color'));
                $('#ad_emoji').removeClass('_1F984').addClass('_' + getCookie('promo_emoji_id'));
            }
        }

        //in case panel happens to remain open in undocked state, check for new promo every 3 hours
        window.setInterval(function () {
            setNewPromo();
        }, 60 * 60 * 3 * 1000);

    }, 1);

    $('.ad_icon_popout').click(function(){
        //hide this promo
        $('.ad_wrapper').hide();

        //set last close promo id to this promo so that it doesn't show again
        setCookie('promo_last_closed', $(this).attr('data-id'))
    });

});

function setNewPromo() {
    if (localStorage.getItem('browserType') == 'Chrome') {
        var url = 'http://www.emoji.one/admin/extensions/promo-chrome.txt';
    } else if (localStorage.getItem('browserType') == 'Opera') {
        var url = 'http://www.emoji.one/admin/extensions/promo-opera.txt';
    } else {
        var url = '';
    }
    $.ajax({
        url: url,
        dataType: 'json',
        success: function(data) {
            if (data === null || Object.getOwnPropertyNames(data).length === 0) {
                $('.ad_wrapper').hide();
            } else {
                //define data
                var promoID = data.promo_id.replace(/<[^>]*>?/g, '')
                var linkData = data.link_url.replace(/<[^>]*>?/g, '');
                var linkTitle = data.link_title.replace(/<[^>]*>?/g, '');
                var linkColor = data.link_color.replace(/<[^>]*>?/g, '');
                var barColor = data.bar_color.replace(/<[^>]*>?/g, '');
                var emojiID = data.emoji_id.replace(/<[^>]*>?/g, '').toUpperCase();
                var emojiClass = '_' + emojiID;

                //update cookies
                var timeNow = new Date().getTime() / 1000;
                setCookie('promo_active_id', promoID);
                setCookie('promo_last_check', timeNow);
                setCookie('promo_link_url', linkData);
                setCookie('promo_link_title', linkTitle);
                setCookie('promo_bar_color', barColor);
                setCookie('promo_link_color', linkColor);
                setCookie('promo_emoji_id', emojiID);

                //did user previously choose to hide a promo?
                if (getCookie('promo_last_closed') && getCookie('promo_last_closed') != 'undefined' && getCookie('promo_last_closed') != '') {
                    var lastClosedPromo = parseInt(getCookie('promo_last_closed'));
                } else {
                    var lastClosedPromo = 0;
                }

                //if the user chose to close this promo, don't show
                if (lastClosedPromo == parseInt(promoID)) {
                    $('.ad_wrapper').hide();
                } else {
                    $('.ad_icon_popout').attr('data-id', promoID);
                    $('.ad_text').attr('href', linkData);
                    $('.ad_text').html(linkTitle);
                    $('.ad_text').css('color', linkColor);
                    $('.inner_ad').css('background-color', barColor);
                    $('#ad_emoji').removeClass('_1F984').addClass(emojiClass);
                }
            }
        },
        error: function(response) {
            $('.ad_wrapper').hide();
            console.log(response);
        }
    });
}

function getCookie(cname)
{
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

function setCookie(name, value, days)
{
    if (days)
    {
        var date = new Date();
        date.setTime(date.getTime()+days*24*60*60*1000); // ) removed
        var expires = "; expires=" + date.toGMTString(); // + added
    }
    else
    {
        var expires = "";
        document.cookie = name+"=" + value+expires + ";"; // + and " added
    }
}