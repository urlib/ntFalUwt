chrome.browserAction.onClicked.addListener(function(tab) {
	  chrome.tabs.create({url: chrome.i18n.getMessage("extStartLink") });
});
