window.settingsOnly = true;
