window.monoExtension = window.monoExtension || {
  addListener: function(listener) {
    if (chrome != undefined && chrome.runtime != undefined && chrome.runtime.onMessage != undefined) {
      chrome.runtime.onMessage.addListener(listener);
      return;
    }
    else {
      window.monoExtension.listeners.push(listener);
    }
  },

  sendMessage: function(message, responseCallback) {
    if (chrome != undefined && chrome.runtime != undefined && chrome.runtime.onMessage != undefined) {
      // console.log("sendMessage " + chrome.runtime);
      chrome.runtime.sendMessage(message, responseCallback);
      return;
    }
    for (var key in this.listeners) {
      var listener = this.listeners[key];
      console.log("listener: ", listener);
      listener(message, "sender", responseCallback);
    }
  },
  listeners: []
};

window.emojiOneSettingsController = window.emojiOneSettingsController || {
  // constants
  webRequestURL: "http://emojione/settings",
  settingsMessage: "settingsMessage",
  // variables
  settings: {},
  shouldAutoReplaceEmojis: true,
  autoReplaceSize: '100',
  blacklistedDomains: '',
  // init
  initRunOnce: false,
  init: function () {
    if (this.initRunOnce) {
      return;
    }
    else {
      this.initRunOnce = true;
    }

    if (location.protocol == 'chrome-extension:' || location.protocol == 'moz-extension:') {
      // Background code
      // this.installXMLHttpRequestIntercept();
      this.installMessageRequestHandler();
    } else {
      // Content script code
      // this.synchronousLoad();
      // this.asynchronousLoadWithIntercept();
      this.asynchronousLoadWithExtensionMessage();
    }

  }, // init
  // settings update callbacks
  settingsUpdateListeners: [],
  addSettingsUpdateListener: function (listener) {
    this.settingsUpdateListeners.push(listener);
  },
  notifyUpdateListeners: function () {
    for (var key in this.settingsUpdateListeners) {
      var listener = this.settingsUpdateListeners[key];
      listener(this);
    }
  },
  hydrateSettings: function() {
    var settings = this.settings;
    if (typeof settings.autoReplace == "string") {
      if (settings.autoReplace == "off") {
        this.shouldAutoReplaceEmojis = false;
      }
    }
    this.blacklistedDomains = settings.blacklistedDomains;
    this.autoReplaceSize = settings.autoReplaceSize;
    this.notifyUpdateListeners();
  }, // hydrateSettings

  // load settings synchronously with local storage
  synchronousLoad: function () {
    this.synchronousLoadWithInterceptedXMLHTTPRequest();
    this.hydrateSettings();
  }, // synchronousLoad

  synchronousLoadWithInterceptedXMLHTTPRequest: function () {
    // we use chrome.webRequest.onBeforeRequest to intercept
    // an XMLHttpRequest, redirect with a URL.createObjectURL of
    // the settings in JSON format
    // and then revoke the object

    var request = new XMLHttpRequest();
    var isAsynchronous = false;
    var url = this.webRequestURL;
    console.log("loading: ", url);
    request.open('GET', url, isAsynchronous);
    try {
      request.send(null);
    }
    catch (exception) {
      console.log("exception in web request: ", exception);
      return;
    }
    var blobURL = request.responseURL;
    console.log("url: ", blobURL);
    var blobResponse = request.response;
    console.log("response: ", blobResponse);
    var response = JSON.parse(blobResponse);

    this.settings = response;
    window.URL.revokeObjectURL(blobURL);
    console.log("loaded settings: ", this.settings);
  }, // synchronousLoadWithInterceptedXMLHTTPRequest
  // read settings while running in background script
  backgroundScriptSettings: function () {
    var settings = "{}";
    if (typeof localStorage['settings'] == "string") {
      settings = localStorage['settings'];
    }

    return settings;
  }, // backgroundScriptSettings
  installXMLHttpRequestIntercept: function () {
    var callback = function(details) {
      var response = {};
      console.log("matches settings url!");
      var settings = this.backgroundScriptSettings();
      console.log("settings: ", settings);
      var blob = new Blob([settings], {type: "application/json"});
      console.log("blob: ", blob);
      var blobURL = window.URL.createObjectURL(blob);
      response.redirectUrl = blobURL;

      console.log("response: ", response);

      return response;
    };
    var filter = {
      urls: [
        this.webRequestURL
      ]
    };
    var opt_extraInfoSpec = [ 'blocking' ];
    chrome.webRequest.onBeforeRequest.addListener(callback, filter, opt_extraInfoSpec);
    console.log("added webrequest listener: ", filter);
  }, // installXMLHttpRequestIntercept

  installMessageRequestHandler: function() {
    var callback = function(message, sender, sendResponse) {
      if (message == this.settingsMessage) {
        var settings = this.backgroundScriptSettings();
        sendResponse(settings);
      }
    }
    callback = callback.bind(this);

    window.monoExtension.addListener(callback);
  }, // installMessageRequestHandler

  asynchronousLoadWithExtensionMessage: function() {
    var message = this.settingsMessage;
    var responseCallback = function (response) {
      var settings = JSON.parse(response);
      this.settings = settings;
      this.hydrateSettings();
    }

    responseCallback = responseCallback.bind(this);
    window.monoExtension.sendMessage(message, responseCallback);
  }, // asynchronousLoadWithExtensionMessage

  // Loading settings asynchronously can be done in a few different way
  // Refresh Method
  asynchronousLoadWithRefresh: function() {
    // we remove everything from the page, do an asychronous request for data,
    // store it into localStorage, and then refresh the page
  }, // asynchronousLoadWithRefresh

  asynchronousLoadWithIntercept: function() {
    var request = new XMLHttpRequest();
    var isAsynchronous = true;
    var url = this.webRequestURL;
    console.log("loading: ", url);
    request.onload = function (event) {
      var blobURL = request.responseURL;
      console.log("url: ", blobURL);
      var blobResponse = request.response;
      console.log("response: ", blobResponse);
      var response = JSON.parse(blobResponse);

      this.settings = response;
      window.URL.revokeObjectURL(blobURL);
      console.log("loaded settings: ", this.settings);
    };
    request.open('GET', url, isAsynchronous);
    request.responseType = 'blob';
    request.send(null);
  }
}

window.emojiOneSettingsController.init();

// define(function() {
/* Key Simulators */
 window.emojiOneKeySynthesizer = window.emojiOneKeySynthesizer ||  {
simulatePasteKeysDown: function simulatePasteKeysDown() {
  this.simulateKeyDown({
    code: "ControlLeft",
    location: KeyboardEvent.DOM_KEY_LOCATION_LEFT,
    keyCode: 17,
    ctrlKey: true
  });
  this.simulateKeyDown({
    code: "KeyV",
    ctrlKey: true,
    keyCode: 86
  });
  this.simulateKeyPress({
    code: "KeyV",
    ctrlKey: true,
    keyCode: 86
  });

},
simulatePasteKeysUp: function simulatePasteKeysUp() {
  this.simulateKeyUp({
    key: "KeyV",
    location: KeyboardEvent.DOM_KEY_LOCATION_LEFT,
    ctrlKey: true,
    keyCode: 86
  });
  this.simulateKeyUp({
    key: "ControlLeft",
    location: KeyboardEvent.DOM_KEY_LOCATION_LEFT,
    keyCode: 17
  });
},

simulateKeyDown: function simulateKeyDown(KeyboardEventInit) {
  var activeElement = document.activeElement;
  var keyboardEvent = new KeyboardEvent('keydown', KeyboardEventInit);
  activeElement.dispatchEvent(keyboardEvent);
},

simulateKeyUp: function simulateKeyUp(KeyboardEventInit) {
  var activeElement = document.activeElement;
  var keyboardEvent = new KeyboardEvent('keyup', KeyboardEventInit);
  activeElement.dispatchEvent(keyboardEvent);
},
simulateKeyPress: function simulateKeyPress(KeyboardEventInit) {
  var activeElement = document.activeElement;
  var keyboardEvent = new KeyboardEvent('keypress', KeyboardEventInit);
  activeElement.dispatchEvent(keyboardEvent);
}
};
// return module;
// });

// check if HMR is enabled
// if (module && module.hot) {
//     // accept itself
//     module.hot.accept();
//     console.log("HMRInjectionKit: change accepted!");
// }

var keySynthesize = window.emojiOneKeySynthesizer;
/* Debugging */
var textDebugging = true;
if (textDebugging) {
  textDebugging = function () {
      delete console.log;
      console.log.apply(console, arguments)
    }
  window.textDebugging = textDebugging;
}
else {
  textDebugging = function () {}
}

if (window.serializedRunLoop) {
  if (window.serializedRunLoop.callbackTimer) {
    clearTimeout(window.serializedRunLoop.callbackTimer);
  }
  delete window.serializedRunLoop;
}

/* Serialized Run Loop */
window.serializedRunLoop = {
  queue: [],
  callbackTimer: null,
  running: true,
  resume: function () {
    this.running = true;
  },
  pause: function () {
    this.running = false;
  },
  scheduledCallback: function () {
    // delete exception handler
    delete window.onerror;
    //console.log("scheduled callback!");
    var self = this;
    self.callbackTimer = null;

    if (!self.running) {
      //console.log("NOT RUNNING");
      self.scheduleTimer();
      return;
    }

    console.timeEnd('queueRun');

    var queueItem = self.queue.shift();
    var targetFunction = queueItem.targetFunction;
    targetFunction();
    var promise = queueItem.promise;

    // queue promise next
    if (promise) {
      self.insertAtBeginningOfQueue(promise);
    }

    if (self.queue.length > 0) {
      self.scheduleTimer();
    }
    else {
      self.callbackTimer = null;
    }
  },
  insertAtBeginningOfQueue: function (targetFunction, configuration) {
    delete window.onerror;
    var self = this;
    var queueItem = self.queueItemFromFunction(targetFunction, configuration);
    self.queue.unshift(queueItem);
    self.scheduleTimer();
  },
  addToQueue: function (targetFunction, configuration) {
    //console.log("addToQueue");
    console.time('queueRun');
    var self = this;
    var queueItem = self.queueItemFromFunction(targetFunction, configuration);
    self.queue.push(queueItem);
    self.scheduleTimer();
  },
  queueItemFromFunction: function (targetFunction, configuration) {
    var queueItem = {
      targetFunction: targetFunction
    };
    //console.log("queue item!");
    if (configuration != undefined) {
      var promise = configuration.promise;
      if (promise != undefined) {
          queueItem.promise = promise;
      }
    }

    return queueItem;
  },
  scheduleTimer: function() {
    var self = this;
    if (self.callbackTimer == null) {
      var milliseconds = 1;
      // don't take up CPU if we're not running
      if (self.running == false) {
        milliseconds = 100;
      }
      self.callbackTimer = setTimeout(self.scheduledCallback, milliseconds);
      //console.log("timer scheduled");
      // self.callbackTimer = window.requestAnimationFrame(self.scheduledCallback);
      // console.log("callback: ", self.callbackTimer)

    }
  },
  setup: function () {
    // bind self to functions
    var self = window.serializedRunLoop;
    self.insertAtBeginningOfQueue = self.insertAtBeginningOfQueue.bind(self);
    self.addToQueue = self.addToQueue.bind(self);
    self.scheduledCallback = self.scheduledCallback.bind(self);
    self.scheduleTimer = self.scheduleTimer.bind(self);
    self.pause = self.pause.bind(self);
    self.resume = self.resume.bind(self);
  }
};
// perform bindings
window.serializedRunLoop.setup();

/* Timeout Clearing */
function clearAllTimeouts() {
  // Set a fake timeout to get the highest timeout id
  var highestTimeoutId = setTimeout(";");
  for (var i = 0; i < highestTimeoutId; i++) {
      clearTimeout(i);
  }
}

function elementIsInput(element) {
  if (element.nodeName == "INPUT" && element.type == "text") {
    return true;
  }

  if (element.nodeName == "TEXTAREA") {
    return true;
  }

  if (element.isContentEditable) {
    return true;
  }

  return false;
}

/* Text Inserters */
function insertTextWithTextInputEvent(text) {

  var activeElement = document.activeElement;
  if ( location.hostname.indexOf('twitter.com') > -1 ) {
    if ( activeElement.classList.contains("tweet-box") ) {
      //grab inner div as active element
      activeElement = activeElement.firstChild;
      //grab cursor pos
      var selection = getSelection();
      var pos = selection.anchorOffset;
      var content = activeElement.innerHTML;
      //define new content
      //if the last char is a space character (&nbsp;) AND cursor is at last position, we need to move cursor up 5 positions
      if (content.substring(content.length - 6, content.length) == "&nbsp;") {
        if(pos == content.length - 5)
          pos = pos + 6;
      }
      var newContent = content.substr(0, pos) + text + content.substr(pos);
      activeElement.innerHTML = newContent;
      //increment cursor pos
      $(activeElement).selectRange(pos + 1);
    }
  } else {
    //initialize the input event
    console.log('input event');
    var inputEvent = document.createEvent('TextEvent');
    //if (window.chrome) {
    inputEvent.initTextEvent('textInput', true, true, window, text);
    keySynthesize.simulatePasteKeysDown();
    activeElement.dispatchEvent(inputEvent);
    keySynthesize.simulatePasteKeysUp();
  }
  //}

    /**/
  /*ANOTHER WAY TO DO THE SAME THING AS ABOVE
  function dispatch(target, eventType, char) {
    var evt = document.createEvent("TextEvent");
    evt.initTextEvent (eventType, true, true, window, char, 0, "en-US");
    target.focus();
    target.dispatchEvent(evt);
  }
  dispatch(document.activeElement.firstChild, "textInput", text);*/
}

function getCaretCharOffsetInDiv(element) {
  var caretOffset = 0;
  if (typeof window.getSelection != "undefined") {
    var range = window.getSelection().getRangeAt(0);
    var preCaretRange = range.cloneRange();
    preCaretRange.selectNodeContents(element);
    preCaretRange.setEnd(range.endContainer, range.endOffset);
    caretOffset = preCaretRange.toString().length;
  }
  else if (typeof document.selection != "undefined" && document.selection.type != "Control")
  {
    var textRange = document.selection.createRange();
    var preCaretTextRange = document.body.createTextRange();
    preCaretTextRange.moveToElementText(element);
    preCaretTextRange.setEndPoint("EndToEnd", textRange);
    caretOffset = preCaretTextRange.text.length;
  }
  return caretOffset;
}

function getCaretPosition() {
  var x = 0;
  var y = 0;
  var sel = window.getSelection();

  if ( sel.rangeCount ){
    var range = sel.getRangeAt(0).cloneRange();
    if ( range.getClientRects() ) {
      range.collapse(true);
      var rect = range.getClientRects()[0];
      if ( rect ) {
        x = rect.left;
        y = rect.top;
      }
    }
  }

  return  {
    x: x,
    y: y
  };
}

(function ($, undefined) {
  $.fn.getCursorPosition = function () {
    var el = $(this).get(0);
    var pos = 0;
    if ('selectionStart' in el) {
      pos = el.selectionStart;
    } else if ('selection' in document) {
      el.focus();
      var Sel = document.selection.createRange();
      var SelLength = document.selection.createRange().text.length;
      Sel.moveStart('character', -el.value.length);
      pos = Sel.text.length - SelLength;
    }
    return pos;
  }
})(jQuery);

$.fn.selectRange = function(start, end) {
  if(end === undefined) {
    end = start;
  }
  return this.each(function() {
    if('selectionStart' in this) {
      this.selectionStart = start;
      this.selectionEnd = end;
    } else if(this.setSelectionRange()) {
      this.setSelectionRange(start, end);
    } else if(this.createTextRange) {
      var range = this.createTextRange();
      range.collapse(true);
      range.moveEnd('character', end);
      range.moveStart('character', start);
      range.select();
    }
  });
}

function insertTextWithInsertHTMLExecCommand(text) {
  document.execCommand("insertHTML", false, text);
}

function insertTextWithRangeReplacement(text) {
  var activeElement = document.activeElement;
  var ownerDocument = activeElement.ownerDocument;
  activeElement.focus();
  var selection = ownerDocument.getSelection();
  var range = ownerDocument.createRange();
  range.collapse(false);
  range.text = text;
}

function clone(object) {
  clone = {};
  for (var p in object) {
      if (object.hasOwnProperty(p)) {
          clone[p] = object[p];
      }
  }
  return clone
}
window.clone = clone;

// on focus callback
function insertTextOnFocusEvent(text) {
  var activeElement = document.activeElement;
  window.setTimeout(function() { activeElement.focus(); }, 0);
  if (activeElement.isContentEditable) {
      var selection = getSelection();
      //var focusOffset = 0;
      console.log("focus event");
      var focusNode = null;
      if (selection != undefined) {
        focusNode = selection.focusNode;
        //focusOffset = focusNode.focusOffset;
        if (focusNode) {
          // baseNode.nodeType == Node.TEXT_NODE
          //console.log("cloning window");
          var clone = window.clone;
          textDebugging("selection:", selection);
          textDebugging("focusNode: ", {node:focusNode});
          //textDebugging("focus offset:", selection.focusOffset);
          /*console.log("selection: ", selection);
          console.log("focusNode: ", {node:focusNode});
          console.log("focus offset:", selection.focusOffset);*/
          console.log(focusNode);
          var nodeValue = focusNode.nodeValue;
          if (nodeValue) {
            // var length = nodeValue.length;
            // var range = document.createRange()
            // range.setStart(currentNode, length);
            // range.setEnd(currentNode, length);
            // selection.removeAllRanges();
            // selection.addRange(range);
            // textDebugging("set range:", range);
          }
        }
        else {
          textDebugging("current node:", focusNode);
          textDebugging("selection: ", selection);
        }
      }
      else {
        textDebugging("selection undefined, active element: ", {activeElement: activeElement});
      }
      // insertTextWithInserHTMLExecCommand(text);
      // insertTextWithRangeReplacement(text);
      insertTextWithTextInputEvent(text);

      // fix Facebook bug of first insertion not getting insertion caret advanced
      // correctly
      if (focusNode != null) {
        var listenerWrapper = {};
        listenerWrapper.focusListener = function (event) {
          // delete exception handler
          delete window.onerror;

          activeElement.removeEventListener("focus", listenerWrapper.focusListener, true);

          textDebugging("this: ", this);
          var selection = getSelection();
          if (!selection) {
            textDebugging("no selection", selection);
            return;
          }
          var focusNode = selection.focusNode;
          textDebugging("advancing selection", selection);

          if (focusNode) {
            var range = document.createRange();
            var length = 0;
            if (focusNode.nodeValue) {
              length = focusNode.nodeValue.length;
              textDebugging("focus node length: ", length);
            }
            else if (focusNode.textContent) {
              length = focusNode.textContent.length;
            }


            textDebugging("node:", {node:focusNode});
            // range.setStart(focusNode, length);
            // range.setEnd(focusNode, length);
            range.setStartAfter(focusNode);
            range.setEndAfter(focusNode);

            selection.removeAllRanges();
            selection.addRange(range);
            textDebugging("setting range start to: ", length);
          }

        };
        textDebugging("setting focus listener");
        // activeElement.addEventListener("focus", listenerWrapper.focusListener, true);
        window.serializedRunLoop.insertAtBeginningOfQueue(function () {
          activeElement.blur();
          activeElement.focus();
          window.serializedRunLoop.insertAtBeginningOfQueue(function () {
            listenerWrapper.focusListener();

          });
        });

      }
      return;
    } // isContentEditable


    if ( location.hostname.indexOf('tweetdeck.twitter') > -1 ) {
      console.log("Emoji input currently disabled for Tweetdeck.");
    } else {
      if (activeElement) {
        var selectionIndex = activeElement.selectionStart;
        if (activeElement.value) {
          var value = activeElement.value;
          var pre = value.slice(0, selectionIndex);
          var post = value.slice(selectionIndex);
          var replacement = pre + '' + text + '' + post;
          activeElement.value = replacement;
        }

        // move cursor after the new emoticon
        var selection = selectionIndex + text.length;
        activeElement.setSelectionRange(selection, selection);

        // set active position
        window.serializedRunLoop.insertAtBeginningOfQueue(function () {
          activeElement.blur();
          activeElement.focus();
        });
      }
    }
}

function getCaretPositionInText(editableDiv) {
  var caretPos = 0,
      sel, range;
  if (window.getSelection) {
    sel = window.getSelection();
    if (sel.rangeCount) {
      range = sel.getRangeAt(0);
      if (range.commonAncestorContainer.parentNode == editableDiv) {
        caretPos = range.endOffset;
      }
    }
  } else if (document.selection && document.selection.createRange) {
    range = document.selection.createRange();
    if (range.parentElement() == editableDiv) {
      var tempEl = document.createElement("span");
      editableDiv.insertBefore(tempEl, editableDiv.firstChild);
      var tempRange = range.duplicate();
      tempRange.moveToElementText(tempEl);
      tempRange.setEndPoint("EndToEnd", range);
      caretPos = tempRange.text.length;
    }
  }
  return caretPos;
}

function insertTextAtCursor(text) {

  if (document.activeElement.id == 'extension_promo_ad_emoji') {
    var bgAdminMessage = chrome.runtime.connect({
      name: 'emoji_admin_set'
    });
    bgAdminMessage.postMessage({
      doc: document
    });
    bgAdminMessage.onMessage.addListener(function(msg) {
      document.getElementById('extension_promo_ad_emoji').setAttribute('data-id', msg.unicode);
    });
    document.activeElement.value = text;
  } else {

    if (navigator.userAgent.indexOf('Chrome') > -1) {
      var browser = 'chrome';
    } else if (navigator.userAgent.indexOf('Firefox') > -1) {
      var browser = 'firefox';
    } else {
      var browser = 'other';
    }

    var activeElement = document.activeElement;
    var isTweetBox = false;
    var isTweetReply = false;
    var isTwitterSearch = false;
    var isTweetDeck = false;

    if (location.hostname.indexOf('twitter.com') > -1) {
      if (location.hostname.indexOf('tweetdeck.twitter') > -1) {
        isTweetDeck = true;
      } else if (activeElement.classList.contains("tweet-box")) {
        if (activeElement.innerHTML.indexOf('twitter-atreply') !== -1) {
          isTweetReply = true;
        } else {
          isTweetBox = true;
        }
      } else {
        isTwitterSearch = true;
      }
    }

    var stillRunInsert = true; //in certain instances (e.g. twitter), we handle inserts inline

    if (browser == 'firefox' && isTweetBox) {
      //this is specific case of firefox unable to manage the main twitter tweetbox properly
      var contents = activeElement.innerHTML;
      if (contents == '<br>') {
        //this indicates that the box was blank, just set contents to the emoji
        activeElement.innerHTML = text;
      } else {
        //box was not blank...append emoji
        activeElement.innerHTML = '';
        var newContents = contents.replace('<br>', '');
        activeElement.innerHTML = newContents + '' + text;
      }
    } else {
      //for chrome/opera
      if (isTweetBox) { //specific actions for tweetbox
        if (activeElement.innerHTML == '<div><br></div>') { //tweet is blank
          activeElement.innerHTML = text;
          stillRunInsert = false;
        } else { //tweet is not blank
          //to overcome the fact that twitter now replaces native unicode with twemoji, we'll now append
          // all inserted emoji as span elements AFTER all other message box content
          activeElement.setAttribute("tabindex", "0");
          var eSpan = $('<span/>').html(text);
          $(activeElement).find('div').append(eSpan);
          stillRunInsert = false;
        }
      } else if (isTweetReply) { //specific actions for tweet reply
        activeElement.setAttribute("tabindex", "0");
        var eSpan = $('<span/>').html(text);
        $(activeElement).find('div').append(eSpan);
        stillRunInsert = false;
      } else if (isTwitterSearch) { //specific actions for twitter search
        if (document.getElementById('search-query').value == '') {
          document.getElementById('search-query').value = text;
          stillRunInsert = false;
        }
      } else { //most other input boxes work fine with standard logic
        if (activeElement.value == '') { //if it's blank, set value to current emoji
          activeElement.value = text;
          stillRunInsert = false;
        }
      }

      if (stillRunInsert) {
        var previousOnFocus = null;
        var fireOnce = false;
        //initialize onFocus event
        function onFocus(event) {

          if (isTweetBox) {
            //Tweet-box specific focusing event
            function addEvent(elem, event, fn) {
              if (elem.addEventListener) {
                elem.addEventListener(event, fn, false);
              } else {
                elem.attachEvent("on" + event,
                    function () {
                      return (fn.call(elem, window.event));
                    });
              }
            };

            addEvent(activeElement, 'focus', function () {
              //set focus to end:
              this.selectionStart = this.selectionEnd = 0;
            });
          }
          else {
            if (fireOnce) {
              return;
            }
            fireOnce = true;

            if (previousOnFocus) {
              textDebugging("previous on focus!");
              previousOnFocus(event);
            }
            activeElement.onfocus = previousOnFocus;
            // clear waiting timer
            clearTimeout(focusTimer);
          }

          window.serializedRunLoop.insertAtBeginningOfQueue(function () {
            if (location.href.indexOf('calendar.google.com') > -1) {
              insertTextWithTextInputEvent(text);
            } else {
              insertTextOnFocusEvent(text);
            }
          });
          // resume execution queue
          window.serializedRunLoop.resume();

        } // onFocus

        // pause execution queue so the next insertion doesn't bind
        window.serializedRunLoop.pause();

        if (!isTweetBox) {
          previousOnFocus = activeElement.onfocus;
          activeElement.onfocus = onFocus;
          activeElement.blur();
          activeElement.focus();
        }
        // in case onfocus doesn't fire
        var focusTimer = setTimeout(onFocus, 1);
      } //if value is blank*/
    } //end check for specific firefox/tweet-box

  } //unique case within emoji.one admin

} // insertTextAtCursor
// delete overridden console.log!
//delete console.log;
// delete exception handler
delete window.onerror;


// clearAllTimeouts();

//   var module = {
//     insertTextAtCursor: insertTextAtCursor,
//     elementIsInput: elementIsInput
//   };
//   return module;
// });
//set default script timers
var startupOnce = false;
var scale = 1;
var scalePercent = 100;
var blacklistedDomains = '';
var iconMatches = [];
var entityMatches = [];
var aEmoji = [];
var aFix = [];
window.emojiOneReplacementEngine = window.emojiOneReplacementEngine || {
      runOnce: false,
      init: function() {
        if (!this.runOnce) {
          this.runOnce = true;
          // check if we're running in development mode
          if (location.hostname.indexOf('emojiresearch.local') != -1) {
            this.startupTasks();
          }
          else {
            this.waitForSettingsUpdate();
          }
        }

        /*var eStartChar = 0;
        var eStartSearch = false;
        var tooltipOpen = false;

       window.setInterval(function(){
          var activeElement = document.activeElement;
          var elem = activeElement.value;
          if (eStartSearch) {
            var val = elem.substring(eStartChar);
            if (!tooltipOpen) {
              console.log('init tooltip');
              emojiTooltip(val, activeElement, eStartChar, false);
              tooltipOpen = true;
            } else {
              console.log('tool tip open, refresh search');
              //refresh tooltip data
              emojiTooltip(val, activeElement, eStartChar, true);
            }
          } else {
            if (elem.slice(-2) == ' :') {
              console.log('start listening for emoji name');
              eStartSearch = true;
              eStartChar = elem.length;
            }
          }
        }, 100);

        //build function to create temporary tool tip
        function emojiTooltip(searchVal, activeElement, offset, update) {
          if (update) {
            $('#emojione_tooltip_main').html('Searching for: ' + searchVal);
          } else {
            //locate activeElement position
            var leftPos = activeElement.getBoundingClientRect().left + $(window)['scrollLeft']();
            var rightPos = activeElement.getBoundingClientRect().right + $(window)['scrollLeft']();
            var topPos = activeElement.getBoundingClientRect().top + $(window)['scrollTop']();
            var bottomPos = activeElement.getBoundingClientRect().bottom + $(window)['scrollTop']();

            var main = $('<div/>').attr('id', 'emojione_tooltip_main').css({
              'position': 'absolute',
              'height': '30px',
              'width': '150px',
              'background-color': 'black',
              'color': 'white',
              'z-index': '500',
              'top': bottomPos + 5,
              'left': leftPos + offset * 3
            }).html('Searching for: ' + searchVal);
            //var inner = $('<div/>').addClass('emojione_tooltip_inner');
            //var emoji = $('<div/>').addClass('emojione_tooltip_emoji');
            $(document.body).append(main);
          }
        }*/
      },
      waitForSettingsUpdate: function() {
        var listener = function (settingsController) {
          if (settingsController.shouldAutoReplaceEmojis) {
            if (settingsController.autoReplaceSize) {
              scale = (settingsController.autoReplaceSize / 100).toFixed(4);
              scalePercent = settingsController.autoReplaceSize;
            }
            blacklistedDomains = settingsController.blacklistedDomains;
            //init skipped domains
            var bShouldRun = true;
            if ( (location.hostname.indexOf('esportspedia') == -1) && (location.host.indexOf('docs.google') == -1) && (location.host.indexOf('sheets.google') == -1) && (location.hostname.indexOf('cincinnati.com') == -1) && (location.hostname.indexOf('moodle.net') == -1) && (location.hostname.indexOf('uphe.com') == -1)) {
              //if this is not one of our hard-coded blacklist domains
              if (blacklistedDomains) {
                if (blacklistedDomains != '' && blacklistedDomains != 'undefined') {
                  var aBlacklist = blacklistedDomains.split(',');
                  for (var b = 0; b < aBlacklist.length; b++) {
                    //derive hostname from provided val
                    var thisDomain = aBlacklist[b];
                    if (thisDomain.indexOf(location.hostname) > -1 || location.hostname.indexOf(thisDomain) > -1) {
                      bShouldRun = false;
                    } //if should run
                  } //for
                } //if blacklist is set
              } //if blaklistedDomains

              if (bShouldRun) {
                //Run default tasks for case-by-case emoji replacement
                this.startupTasks();

                //apply custom font to entire page
                /*$("head").append("<style type=\"text/css\">" +
                  "@font-face {\n" +
                  "\tfont-family: \"EmojiOneColor\";\n" +
                  "\tsrc: url('https://github.com/Ranks/emojione/raw/master/assets/fonts/emojione-svg.otf') format('opentype');\n" +
                  "}\n" +
                  "\tbody {\n" +
                  "\tfont-family: EmojiOneColor !important;\n" +
                  "}\n" +
                  "</style>");*/
              }
            }
          }
        };
        listener = listener.bind(this);
        window.emojiOneSettingsController.addSettingsUpdateListener(listener);
      },
      //startupOnce: false,
      startupTasks: function() {
        if (!this.startupOnce) {
          this.startupOnce = true;
          this.hydrateEmojiList();
          this.appendSVGToDocument();
          //this.monitorNodeMutations();
          this.replaceEmojisInDocument();
          //this.displayScriptTimes();
        }
      },
      hydrateEmojiList: function () {
        if (typeof window.emojiOneJSON == "undefined") {
          //console.log("Emoji One: Error hydrating emoji list, missing data.");
          return;
        }

        this.emojiList = Object.keys(window.emojiOneJSON);
        // sort by length so that when the regex gets generated, longer emoji codes
        // get matched first, thus skin toned emojis will get matched correctly
        var sortByLength = function (string1, string2) {
          return string2.length - string1.length;
        };

        this.emojiList.sort(sortByLength);

        this.asciiList = {
          '<3':'2764',
          '&lt;3':'2764',
          '</3':'1f494',
          '&lt;/3':'1f494',
          ':\')':'1f602',
          ':\'-)':'1f602',
          ':D':'1f603',
          ':-D':'1f603',
          '=D':'1f603',
          ':)':'1f642',
          ':-)':'1f642',
          '=]':'1f642',
          '=)':'1f642',
          ':]':'1f642',
          '\':)':'1f605',
          '\':-)':'1f605',
          '\'=)':'1f605',
          '\':D':'1f605',
          '\':-D':'1f605',
          '\'=D':'1f605',
          '>:)':'1f606',
          '>;)':'1f606',
          '>:-)':'1f606',
          '>=)':'1f606',
          ';)':'1f609',
          ';-)':'1f609',
          '*-)':'1f609',
          '*)':'1f609',
          ';-]':'1f609',
          ';]':'1f609',
          ';D':'1f609',
          ';^)':'1f609',
          '\':(':'1f613',
          '\':-(':'1f613',
          '\'=(':'1f613',
          ':*':'1f618',
          ':-*':'1f618',
          '=*':'1f618',
          ':^*':'1f618',
          '>:P':'1f61c',
          'X-P':'1f61c',
          'x-p':'1f61c',
          '>:[':'1f61e',
          ':-(':'1f61e',
          ':(':'1f61e',
          ':-[':'1f61e',
          ':[':'1f61e',
          '=(':'1f61e',
          '>:(':'1f620',
          '>:-(':'1f620',
          ':@':'1f620',
          ':\'(':'1f622',
          ':\'-(':'1f622',
          ';(':'1f622',
          ';-(':'1f622',
          '>.<':'1f623',
          'D:':'1f628',
          ':$':'1f633',
          '=$':'1f633',
          '#-)':'1f635',
          '#)':'1f635',
          '%-)':'1f635',
          '%)':'1f635',
          'X)':'1f635',
          'X-)':'1f635',
          '*\\0/*':'1f646',
          '\\0/':'1f646',
          '*\\O/*':'1f646',
          '\\O/':'1f646',
          'O:-)':'1f607',
          '0:-3':'1f607',
          '0:3':'1f607',
          '0:-)':'1f607',
          '0:)':'1f607',
          '0;^)':'1f607',
          'O:)':'1f607',
          'O;-)':'1f607',
          'O=)':'1f607',
          '0;-)':'1f607',
          'O:-3':'1f607',
          'O:3':'1f607',
          'B-)':'1f60e',
          'B)':'1f60e',
          '8)':'1f60e',
          '8-)':'1f60e',
          'B-D':'1f60e',
          '8-D':'1f60e',
          '-_-':'1f611',
          '-__-':'1f611',
          '-___-':'1f611',
          '>:\\':'1f615',
          '>:/':'1f615',
          ':-/':'1f615',
          ':-.':'1f615',
          ':/':'1f615',
          ':\\':'1f615',
          '=/':'1f615',
          '=\\':'1f615',
          ':L':'1f615',
          '=L':'1f615',
          ':P':'1f61b',
          ':-P':'1f61b',
          '=P':'1f61b',
          ':-p':'1f61b',
          ':p':'1f61b',
          '=p':'1f61b',
          ':-Þ':'1f61b',
          ':Þ':'1f61b',
          ':þ':'1f61b',
          ':-þ':'1f61b',
          ':-b':'1f61b',
          ':b':'1f61b',
          'd:':'1f61b',
          ':-O':'1f62e',
          ':O':'1f62e',
          ':-o':'1f62e',
          ':o':'1f62e',
          'O_O':'1f62e',
          '>:O':'1f62e',
          ':-X':'1f636',
          ':X':'1f636',
          ':-#':'1f636',
          ':#':'1f636',
          '=X':'1f636',
          '=x':'1f636',
          ':x':'1f636',
          ':-x':'1f636',
          '=#':'1f636'
        };

        this.emojiSymbolsString = this.emojiList.join(this.emojiSymbolsSeparator);
        var escape = function (text) {
          return text.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
        };
        var regex = this.emojiList.map(escape).join("|");
        this.emojiRegex = new RegExp("(" + regex + ")", "ig");
        var asciis = [];
        for ( var k in this.asciiList ) {
          if ( this.asciiList.hasOwnProperty(k) ) {
            asciis.push('&nbsp;' + k.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&") + '&nbsp;');
          }
        }
        var asciiRxp = asciis.join("|");
        this.asciiRegex = new RegExp("(" + asciiRxp + ")", "ig");
      },
      emojiSymbolsSeparator: "|",
      emojiSymbolsString: null,
      SVGAppended: false,
      appendSVGToDocument: function () {
        if (self.SVGAppended) {
          //prevent duplication
          return true;
        }

        if (!document.body) {
          return;
        }

        self.SVGAppended = true;

        //as of 1-15-16 svg sprite is being requested independently of emojiData.js
        var spriteURL = chrome.extension.getURL("data/emojione.sprites.svg");
        var rawFile = new XMLHttpRequest();
        rawFile.open("GET", spriteURL, true);
        rawFile.onreadystatechange = function ()
        {
          if(rawFile.readyState === 4)
          {
            var sprite = rawFile.responseText;
            $(document.body).prepend(
                $("<div/>", { style: "display:none;" }).html(sprite)
            );
          }
        }
        rawFile.send();
      },

      replaceEmojisInDocument: function () {
        var rootNode = document;
        this.replaceEmojisInNode(rootNode);
        this.monitorNodeMutations();
      },
      replaceEmojisInNode: function (node) {

        if (location.hostname.indexOf('twitter') > -1) {
          this.replaceTwitterEmojisInNode(node);
        } else if (location.hostname.indexOf('google') > -1) {
          if (location.href.indexOf('www.google.com') > -1) {
            this.targetGoogleSearchNodes(node);
          } else if (location.href.indexOf('plus.google.com') > -1) {
            //this.targetGooglePlusNodes(node);
          } else if (location.href.indexOf('hangouts.google.com') > -1) {
            this.replaceGoogleEmojisInNode(node);
            this.replaceGoogleHangoutsEmojisInNode(node);
          } else if (location.href.indexOf('calendar.google.com') > -1) {
            this.replaceGoogleCalendarEmojis(node);
          }
        } else if (location.hostname.indexOf('youtube.com') > -1) {
          this.replaceYoutubeEmojis(node);
        } else if (location.hostname.indexOf('unicode.org') > -1) {
          this.replaceUnicodeEmojis(node);
        } else if (location.hostname.indexOf('facebook.com') > -1) {
          this.replaceFacebookEmojis(node);
        } else if (location.href.indexOf('web.whatsapp') > -1) {
          this.replaceWhatsAppEmojis(node);
        } else if (location.href.indexOf('instagram.com') > -1) {
          this.replaceInstagramEmojis(node);
        } else if (location.href.indexOf('twitch.tv') > -1) {
          this.replaceTwitchEmojis(node);
        } else if (location.href.indexOf('emojipedia.org') > -1) {
          this.replaceEmojipedia(node);
        }
        else {
          //chrome, or others
          /*if (node.nodeType) {
            if (node.nodeType == Node.TEXT_NODE) {
              return this.replaceEmojiInTextNode(node);
            }
            else {
              var skipElements = ['script', 'style', 'iframe', 'canvas', 'noscript', 'img', 'textarea', 'input'];
              var child = node.firstChild;
              if (child != null) {
                while (child) {
                  switch (child.nodeType) {
                    case Node.ELEMENT_NODE: // An Element node such as <p> or <div>.
                      if (skipElements.indexOf(child.tagName.toLowerCase()) > -1) {
                        break;
                      }
                      if (child.isContentEditable) {
                        break;
                      }
                      this.replaceEmojisInNode(child);
                      break;
                    case Node.TEXT_NODE: // The actual Text of Element or Attr.
                      return this.replaceEmojiInTextNode(child);
                      break;
                  } // switch nodeType
                  child = child.nextSibling;
                }
              }
            }
          }*/
          if (node.nodeType == 3) {
            this.replaceEmojiInTextNode(node);
          } else {
            for (var child in node.childNodes) {
              this.replaceEmojisInNode(child);
            }
          }
        }
      }, // replaceEmojis
      targetGoogleSearchNodes: function (node) {
        var thisDoc = this;
        $('.st').each(function() {
            if (!$(this).hasClass('emojiOne')) {
                $(this).addClass('emojiOne');
                thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
            }
        });
        $('.r').each(function() {
            if (!$(this).hasClass('emojiOne')) {
                $(this).addClass('emojiOne');
                thisDoc.replaceEmojisWithMatchAndLoop($(this).find('a')[0]);
            }
        });
      },
      targetGooglePlusNodes: function (node) {
        var thisDoc = this;
        $('.Ct').each(function() {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
          }
        });
        //for new google plus interface (released summer '16)
        $('.wftCae').each(function() {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
          }
        });
        $('.UT3bRd').find('span').each(function() {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
          }
        });
      },
      replaceGoogleCalendarEmojis: function (node) {
        var thisDoc = this;
        $('.evt-lk').each(function () {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
          }
        });
      },
      replaceYoutubeEmojis: function (node) {
        var thisDoc = this;
        $('.comment-renderer-text-content').each(function() {
            if (!$(this).hasClass('emojiOne')) {
                $(this).addClass('emojiOne');
                thisDoc.replaceEmojisWithRegexAndIterativeSpans($(this)[0]);
            }
        });
      },
      replaceInstagramEmojis: function (node) {
        var thisDoc = this;
        $('._nk46a').each(function () {
          if ( !$(this).hasClass('emojiOne') ) {
            $(this).addClass('emojiOne');
            var comment = $(this).find('h1');
            var comment2 = $(this).find('h1').find('span');
            var comment3 = $(this).find('span');
            if (comment) {
              thisDoc.replaceEmojisWithMatchAndLoop(comment[0]);
            }
            if (comment2) {
              thisDoc.replaceEmojisWithMatchAndLoop(comment2[0]);
            }
            if (comment3) {
              thisDoc.replaceEmojisWithMatchAndLoop(comment3[0]);
            }
          }
        });
      },
      replaceUnicodeEmojis: function (node) {
        var thisDoc = this;
        $('.chars').each(function () {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            var symbol = $(this).html();
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).removeClass('chars').addClass('recharred');
              $(this).html(newNode);
            }
          }
        });
      },
      replaceTwitterEmojisInNode: function (node) {
        var thisDoc = this;
        $('.Emoji--forText').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            var symbol = $(this).attr('alt');
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).replaceWith(newNode);
            }
          }
        });
        //.Emoji--forLinks represents emoji symbols within a user's name
        $('.Emoji--forLinks').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            //glyphs are tucked in a unique location:
            //var symbol = $(this).parent().find('.visuallyhidden').html();
            var symbol = $(this).next().html();
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).replaceWith(newNode);
            }
          }
        });
        //TweetDeck replacement
        $('.emoji').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            var symbol = $(this).attr('alt');
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).replaceWith(newNode);
            }
          }
        });
      },
      replaceFacebookEmojis: function (node) {
        var thisDoc = this;
        $('._4ay8').each(function () {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            var symbol = $(this).html();
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).replaceWith(newNode);
            }
          }
        });
        $('._47e3').each(function () {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            var symbol = $(this).find('._7oe').html();
            //check for larger font size
            var fontSize = $(this).parent().parent().css('font-size');
            if (fontSize == '24px') {
              var isLarge = true;
            } else {
              var isLarge = false;
            }
            var newNode = thisDoc.createIconNode(symbol, isLarge);
            if (newNode != null) {
              $(this).replaceWith(newNode);
            }
          }
        });
        //specific to about blocks, where emojis are rendered inline
        $('._c24').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
          }
        });
        $('._4wyf').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
          }
        });

        //additional post elements
        $('._5pbx').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            var fontSize = $(this).find('._58jw').css('font-size');
            if (fontSize == '24px') {
              var isLarge = true;
            } else {
              var isLarge = false;
            }
            var dataNode = $(this).find('p')[0];
            thisDoc.replaceEmojisWithMatchAndLoop(dataNode, isLarge);
            $(this).addClass('emojiOne');
          }
        });
        $('._58jw').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            var fontSize = $(this).css('font-size');
            if (fontSize == '24px') {
              var isLarge = true;
            } else {
              var isLarge = false;
            }
            var dataNode = $(this).find('p')[0];
            thisDoc.replaceEmojisWithMatchAndLoop(dataNode, isLarge);
            $(this).addClass('emojiOne');
          }
        });
      },
      replaceGoogleEmojisInNode: function (node) {
        var thisDoc = this;
        $('[goomoji]').each(function () {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            var symbol = $(this).attr('alt');
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).replaceWith(newNode);
            }
          }
        });
      }, // replaceGoogleEmojisInNode
      replaceGoogleHangoutsEmojisInNode: function (node) {
        var thisDoc = this;
        $('span[data-emo]').each(function () {
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            var symbol = $(this).data('emo');
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).replaceWith(newNode);
            }
          }
        });
      }, // replaceGoogleHangoutsEmojisInNode
      replaceWhatsAppEmojis: function (node) {
        var thisDoc = this;
        $('.emoji').each(function () {
          if ( !$(this).parent().hasClass('input') ) {
            if (!$(this).hasClass('emojiOne')) {
              $(this).addClass('emojiOne');
              var symbol = $(this).attr('alt');
              var newNode = thisDoc.createIconNode(symbol);
              if (newNode != null) {
                $(this).replaceWith(newNode);
              }
            }
          }
        });
      },
      replaceTwitchEmojis: function(node) {
        var thisDoc = this;
        $('.activity-body--comment p').each(function(){
          if (!$(this).hasClass('emojiOne')) {
            $(this).addClass('emojiOne');
            thisDoc.replaceEmojisWithMatchAndLoop($(this)[0]);
          }
        });
      },
      replaceEmojipedia: function (node) {
        var thisDoc = this;
        $('.emoji').each(function () {
          if ( !$(this).hasClass('emojiOne') ) {
            $(this).addClass('emojiOne');
            var symbol = $(this).html();
            var newNode = thisDoc.createIconNode(symbol);
            if (newNode != null) {
              $(this).html(newNode);
            }
          }
        });
      },
      replaceEmojiInTextNode: function (node) {
        if (node.nodeType != Node.TEXT_NODE) {
          return false
        }
        if (node.parentNode && node.parentNode.isContentEditable) {
          return false
        }
        if (node.parentNode && node.parentNode.nodeName.toLowerCase() == 'emoji-description'){
          return false;
        }
        if (node.data.indexOf('function(') > -1) {
          return false;
        }

        var text = node.data;
        if (text.trim().length != 0) {
          this.replaceAllEmojisWithSVGReferencesInTextNode(node);
          return true;
        }

        return true;
      }, // replaceEmojiInTextNode

      replaceAllEmojisWithSVGReferencesInTextNode: function (node) {
        // regex
        this.replaceAllEmojisWithSVGreferencesInTextNodeWithRegex(node);
      },  // textWithAllEmojiOccurencesReplacedWithEmojiOneSVGReferences

      /*replaceEmojiWithCharLoop: function (node) {
        str = node.innerHTML;
        console.log("Loop..................................");
        var i = str.length;
        while (i--) {
          if ( str.charCodeAt(i) > 50000 ) {
            //console.log(str.charAt(i));
            //console.log(str.charCodeAt(i));
            codePoint = (str.charCodeAt(i) - 0xD800) * 0x400 + str.charCodeAt(i+1) - 0xDC00 + 0x10000;
            console.log(codePoint);
            i++;
          }
        }

      },*/

      replaceAllEmojisWithSVGreferencesInTextNodeByIteratingThroughSymbols: function (node) {
        var text = node.data || node.innerHTML;
        var offset = 0;
        var emojiList = this.emojiList;

        for (var symbol in text) {
          if (symbol == this.emojiSymbolsSeparator) {
            continue;
          }
          if (emojiList.indexOf(symbol) != -1) {
            // console.log("found symbol:", symbol);
            var newTextNode = node.splitText(offset);
            // remove emoji
            newTextNode.data = newTextNode.data.substr(symbol.length);

            // insert icon node
            var iconNode = this.createIconNode(symbol);
            //console.log("icon node is: "+iconNode);
            var parentNode = node.parentNode;
            parentNode.insertBefore(iconNode, newTextNode);

            // do the rest of the processing on this new node
            this.replaceAllEmojisWithSVGreferencesInTextNodeByIteratingThroughSymbols(newTextNode);
            return;
          }

          offset += symbol.length;
        }
      },

      replaceAllEmojisWithSVGreferencesInTextNodeWithRegex: function (node) {
        var text = node.data || node.innerHTML;
        var bk = 0;
        var parent = node.parentNode;
        if ( !parent ) {
          //console.log('no parent node');
        } else {
          var self = this;
          text.replace(this.emojiRegex, function (match, p1, offset, string) {
            var newTextNode = node.splitText(offset + bk);
            bk -= node.data.length + match.length;
            newTextNode.data = newTextNode.data.substr(match.length);
            var nodeToInsert; //= document.createElement('span');
            nodeToInsert = self.createIconNode(match);
            parent.insertBefore(nodeToInsert, newTextNode);
            node = newTextNode;
            //}
            //setTimeout(function () {
            //    //console.log("new node ",nodeToInsert, nodeToInsert.clientHeight);
            //    h = (nodeToInsert.clientHeight + 4) + 'px';
            //    nodeToInsert.style.height = h;
            //    nodeToInsert.style.width = h;
            //
            //})
          });
        }
      },

      /*replaceAllEmojisWithSVGreferencesWithTargetedRegex: function (node) {
        if ( node && typeof(node) != 'undefined' ) {
          var text = node.innerHTML || node.data;
          if ( typeof(text) != 'undefined' ) {
            var doReplaceNode = false;
            var self = this;
            text.replace(this.emojiRegex, function (match, p1, offset, string) {
              doReplaceNode = true;
              var newContainerNode = document.createElement("span");
              var aString = text.split(p1);
              for (var i = 0; i < aString.length; i++) {
                var newOuterNode = document.createElement("span");
                newOuterNode.innerHTML = aString[i];
                newContainerNode.appendChild(newOuterNode);
                if (i < aString.length) {
                  //if (!entityMatches[text]) {
                    //if (!iconMatches[p1]) {
                      doReplaceNode = true;
                      var newIconNode = self.createIconNode(p1);
                      if (newIconNode && newIconNode != '') {
                        newContainerNode.appendChild(newIconNode);
                        //iconMatches.push(p1);
                        iconMatches[p1] = newIconNode;
                        entityMatches.push(text);
                      }
                    //}
                  //}
                }
              }
            });
            if ( doReplaceNode ) {
              node.innerHTML = '';
              node.appendChild(newContainerNode);
            }
          }
        }
      },*/

      replaceEmojisWithMatchAndLoop: function (node, isLarge = false) {
        if ( node && typeof(node) != 'undefined' ) {
          var text = node.innerHTML || node.data;
          if ( typeof(text) != 'undefined' ) {
            var self = this;
            var matched = [];
            var foundMatch = false;
            
            //handle unicode matches
            text.replace(this.emojiRegex, function (match, p1, offset, string) {
              matched.push(p1);
              foundMatch = true;
            });

            //handle ascii matches
            text.replace(this.asciiRegex, function (match, p1, offset, string) {
              matched.push(p1);
              foundMatch = true;
            });

            if ( foundMatch ) {
              //filter array for only unique elements
              var matchedUnique = matched.filter(function (e, i, matched) {
                return matched.lastIndexOf(e) === i;
              });
              var aLen = matchedUnique.length;
              for ( i  = 0; i < aLen; i++ ) {
                self.replaceSpecificEmoji(node, matchedUnique[i], isLarge);
              }
            }
          }
        }
      },

      replaceSpecificEmoji: function (node, emoji, isLarge) {
        if ( node && typeof(node) != 'undefined' ) {
          var text = node.innerHTML || node.data;
          if (text && typeof(text) != 'undefined') {
            var aText = text.split(emoji);
            if (aText.length > 1) {
              node.innerHTML = '';
              for (var i = 0; i < aText.length; i++) {
                var newNode = document.createElement("span");
                newNode.innerHTML = aText[i];
                node.appendChild(newNode);
                if (i < aText.length - 1) {
                  var newIconNode = this.createIconNode(emoji, isLarge);
                  node.appendChild(newIconNode);
                }
              }
            }
          }
        }
      },

      replaceEmojisWithRegexAndIterativeSpans: function (node) {
        var origText = node.innerHTML || node.data;
        if(origText && origText != 'undefined') {
          var text = origText.replace('&#65279;', '');
          var doReplace = false;

          //set array to track matches in string
          var aMatches = new Array;
          text.replace(this.emojiRegex, function (match, p1, offset, string) {
            aMatches[offset] = match;
            doReplace = true;
          });

          if (doReplace) {
            var newOuterNode = document.createElement("span");
            var self = this;
            var nextText = '';
            var prevOffset = 0;

            //loop through aMatches and parse this out
            var x = 1;
            for (var k in aMatches) {
              if (aMatches.hasOwnProperty(k)) {
                var key = k;
                var icon = aMatches[k];

                //set content and offset depending upon position within match array/loop
                if (aMatches.length == 1 || (aMatches.length > 1 && x == 1)) {
                  var thisString = text;
                  var thisOffset = key;
                } else {
                  var thisString = nextText;
                  var thisOffset = key - prevOffset + 1;
                }

                //always set the first inner node and append to the outer node (sometimes this will be blank
                var newInnerNodeOne = document.createElement("span");
                newInnerNodeOne.innerHTML = thisString.substr(0, thisOffset);
                newOuterNode.appendChild(newInnerNodeOne);

                //always set the emoji found in this sequence into the outer node
                var newIconNode = self.createIconNode(icon);
                newOuterNode.appendChild(newIconNode);

                //if this is the final emoji in the sequence, set remaining chars in span and append to outer node
                if (x == aMatches.length) {
                  var newInnerNodeTwo = document.createElement("span");
                  newInnerNodeTwo.innerHTML = thisString.substr(thisOffset + 2);
                  newOuterNode.appendChild(newInnerNodeTwo);
                } else {
                  nextText = thisString.substr(thisOffset + 2);
                }
                prevOffset = key;
                x++;
              }
            }
            //after newOuterNode has been completed, append to original node
            node.innerHTML = '';
            node.appendChild(newOuterNode);
          }
        }
      },

      replaceAllEmojisWithSVGreferencesWithTargetedRegexForFF: function (node) {
        var text = node.innerHTML || node.data;
        var self = this;
        text.replace(this.emojiRegex, function (match, p1, offset, string) {
          //node.textContent = '';
          node.innerHTML = '';
          var aString = text.split(p1);
          for (var i = 0; i < aString.length; i++) {
            var newOuterNode = document.createElement("span");
            newOuterNode.innerHTML = aString[i];
            /*var innerNode = document.createTextNode(aString[i]);
            newOuterNode.appendChild(innerNode);*/
            //node.appendChild(newOuterNode);
            //node.innerHTML = aString[i];
            if (i < aString.length) {
              if (!entityMatches[text]) {
                if (!iconMatches[p1]) {
                  var newIconNode = self.createIconNode(p1);
                  //node.appendChild(newIconNode);*/
                  node.innerHTML = newIconNode;
                  //iconMatches.push(p1);
                  iconMatches[p1] = newIconNode;
                  entityMatches.push(text);
                }
              }
            }
          }
        });
      },

      createIconNode: function (symbol, isLarge = false) {
        var thisNewIconNode = this.createIconNodeByCloningNode(symbol);
        //return this.createIconNodeByCloningNode(symbol);
        var iconSize = {width: ''+(1.1*scale)+'em', height: ''+(1.1*scale)+'em'};
        if (location.hostname.indexOf('facebook.com') > -1)
          if (isLarge) {
            iconSize = {width: '' + (24 * scale) + 'px', height: '' + (24 * scale) + 'px', padding: '0 3px'};
          } else {
            iconSize = {width: '' + (17 * scale) + 'px', height: '' + (17 * scale) + 'px', padding: '0 2px'};
          }
        if (location.hostname.indexOf('nstagram.com') > -1)
          iconSize = {width: ''+(1.25*scale)+'em', height: ''+(1.25*scale)+'em'};
        if (location.hostname.indexOf('twitter.com') > -1)
          iconSize = {width: ''+(1.25*scale)+'em', height: ''+(1.3*scale)+'em', padding: '0 .1em 0 .1em'};
        if (location.hostname.indexOf('google') > -1)
          iconSize = {width: ''+(24*scale)+'px', height: ''+(24*scale)+'px', padding: "0 .1em 0 .1em"};
        if (location.hostname.indexOf('unicode.org') > -1)
          iconSize = {width: ''+(2.5*scale)+'em', height: ''+(2.5*scale)+'em', top: '.1em'};

        var span = document.createElement("span");
        span.style.display = 'inline-block';
        span.style.lineHeight = 'normal';
        span.style.fontSize = 'inherit';
        span.style.verticalAlign = 'middle';
        //span.style.overflow = 'hidden';
        span.style.position = 'relative';
        span.style.width = iconSize.width;
        span.style.height = iconSize.height;
        if (location.hostname.indexOf('twitter.com') > -1) {
          span.style.zIndex = '3';
        } else {
          span.style.zIndex = '100';
        }
        if (iconSize.top)
          span.style.top = iconSize.top;
        if (iconSize.padding)
          span.style.padding = iconSize.padding;
        var dict = window.emojiOneJSON;
        var asciiDict = this.asciiList;
        var entry = dict[symbol];
        if (entry) {
          //span.innerHTML = '<svg style="padding: 0; margin: 0; width:100%; height:100%;" ><use xlink:href= "#emoji-' + entry.toLowerCase() + '"></use></svg><emoji-description style="width:0px;height:0px;font-size:0;line-height:0;">' + symbol + '</desc>';
          span.innerHTML = '<svg style="padding: 0; margin: 0; width:100%; height:100%;" ><use xlink:href= "#emoji-' + entry.toLowerCase() + '"></use></svg><emoji-description style="width:0px;height:0px;font-size:0;line-height:0;">emoji unicode: ' + entry.toLowerCase() + '</desc>';
        } else {
          if (asciiDict) {
            var entry = asciiDict[symbol];
            if (!entry) {
              //console.log("couldn't find symbol in ascii dict either");
              span = document.createElement('span');
              span.innerHTML = symbol;
            } else {
              //console.log("found in ascii dictionary");
              span.innerHTML = '<svg style="padding: 0; margin: 0; width:100%; height:100%;" ><use xlink:href= "#emoji-' + entry.toLowerCase() + '"></use></svg><emoji-description style="width:0px;height:0px;font-size:0;line-height:0;">emoji unicode: ' + entry.toLowerCase() + '</desc>';
            }
          } else {
            span = document.createElement('span');
            span.innerHTML = symbol;
          }
        }
        return span;
      }, // createIcon

      createIconNodeByCloningNode: function (symbol) {
        var dict = window.emojiOneJSON;
        var unicode = dict[symbol];
        if (!unicode) {
          //console.log("couldn't find unicode for symbol: ", symbol, "in dict :(");
          return null;
        }
        //we'll create one base node and clone that for additional nodes
        if (this.baseIconNode == null) {
          this.createBaseIconNode()
        }
        var iconNode = this.baseIconNode.cloneNode(true);
        var use = iconNode.firstChild.firstChild;
        use.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#emoji-" + unicode.toLowerCase());
        var description = iconNode.lastChild;
        /*var innerNode = document.createTextNode(symbol);
        description.appendChild(innerNode);*/
        description.textContent = symbol;
        // console.log("node: ", {iconNode: iconNode});*/
        return iconNode;
      }, // createIcon
// clonable icon node
      baseIconNode: null,
      createBaseIconNode: function () {
        var iconSize = {width: ''+(1.1*scale)+'em', height: ''+(1.1*scale)+'em'};
        if (location.hostname.indexOf('facebook.com') > -1)
          iconSize = {width: ''+(17*scale)+'px', height: ''+(17*scale)+'px', padding: '2px'};
        if (location.hostname.indexOf('nstagram.com') > -1)
          iconSize = {width: ''+(1.25*scale)+'em', height: ''+(1.25*scale)+'em'};
        if (location.hostname.indexOf('twitter.com') > -1)
          iconSize = {width: ''+(1.25*scale)+'em', height: ''+(1.3*scale)+'em', padding: '0 .1em 0 .1em'};
        if (location.hostname.indexOf('google') > -1)
          iconSize = {width: ''+(24*scale)+'px', height: ''+(24*scale)+'px', padding: "0 .1em 0 .1em"};
        if (location.hostname.indexOf('unicode.org') > -1)
          iconSize = {width: ''+(2.5*scale)+'em', height: ''+(2.5*scale)+'em', top: '.1em'};

        var span = document.createElement("span");
        span.style.display = 'inline-block';
        span.style.lineHeight = 'normal';
        span.style.fontSize = 'inherit';
        span.style.verticalAlign = 'middle';
        //span.style.overflow = 'hidden';
        span.style.position = 'relative';
        span.style.width = iconSize.width;
        span.style.height = iconSize.height;
        if (location.hostname.indexOf('twitter.com') > -1) {
          span.style.zIndex = '3';
        } else {
          span.style.zIndex = '100';
        }
        if (iconSize.top)
          span.style.top = iconSize.top;
        if (iconSize.padding)
          span.style.padding = iconSize.padding;

        var symbol = "emoji-symbol";
        var unicode = "EMOJI-UNICODE";
        // var fragment = document.createDocumentFragment();

        var svgNS = "http://www.w3.org/2000/svg";
        var xmlnsns = "http://www.w3.org/2000/xmlns/";
        var xlinkns = "http://www.w3.org/1999/xlink";

        var svg = document.createElementNS(svgNS, "svg");
        //svg.style = "padding: 0; margin: 0; width:"+100*scale+"%; height:"+100*scale+"%";
        svg.style = "padding: 0; margin: 0; width:100%; height:100%";
        var use = document.createElementNS(svgNS, "use");
        use.setAttributeNS(xmlnsns, "xmlns:xlink", xlinkns);
        // use.setAttributeNS("http://www.w3.org/2000/xmlns", "xlink", "http://www.w3.org/1999/xlink");
        use.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#emoji-" + unicode.toLowerCase());
        svg.appendChild(use);

        span.appendChild(svg);

        var emojiDescription = document.createElement("emoji-description");
        emojiDescription.style = "width:0px;height:0px;font-size:0;line-height:0;";
        var innerNode = document.createTextNode(symbol);
        emojiDescription.appendChild(innerNode);

        span.appendChild(emojiDescription);

        this.baseIconNode = span;
        return span;
      },
      emojiList: [],
      mutationsObserver: null,
      mutationsQueue: [],
      mutationDisableReEntry: false,
      mutationsInstantModification: true,
      mutationsNextRunLoopModification: false,
      mutationsRunLoopQueued: false,
      monitorNodeMutations: function() {
        var numNodes = 0;
        this.mutationsObserver = new MutationObserver(function (mutations) {
          // console.log("mutations: ", mutations);
          var self = window.emojiOneReplacementEngine;
          //var self = this;
          // disable re-entrant mutation
          if (self.mutationsDisableReEntry) {
            return false;
          }

          // perform instant emoji replacement
          if (self.mutationsInstantModification) {
            self.mutationsDisableReEntry = true;

            // append SVG to body ASAP
            if (!self.SVGAppended && document.body) {
              self.appendSVGToDocument();
            }
            var queue = [];
            var queueLength = 0;
            //console.log(mutations.length);
            for (var i = 0; i < mutations.length; i++) {
              var mutation = mutations[i];
              //var mutatedNode = mutation.target;
              // console.log("mutation: ", mutation);
              if (mutation.type == "childList") {
                if (mutation.addedNodes) {
                  for (var key in mutation.addedNodes) {
                    var addedNode = mutation.addedNodes[key];
                    if (queue.indexOf(addedNode) == -1) {
                      //hangs constantly: queue.push(addedNode);
                      //script doesn't run on certain pages with: setTimeout(function() { queue.push(addedNode) }, 10);
                      //runs the fastest and with least hanging, but slow still: queue[queue.length] = addedNode;
                      queue[queueLength] = addedNode;
                      queueLength++;
                    }
                  }
                }
              }
            }
            //setTimeout(function() { self.processMutationQueue(queue) }, 10);
            self.processMutationQueue(queue)

            self.mutationsDisableReEntry = false
          } // instant emoji replacement

          // schedule emoji replacement in next run loop
          if (self.mutationsNextRunLoopModification) {
            var mutationsLength = mutations.length;
            for (var i = 0; i < mutationsLength; i++) {
              if (self.mutationsQueue.indexOf(mutations[i].target) == -1) {
                self.mutationsQueue.push(mutations[i].target)
              }
            }

            if (self.mutationsRunLoopQueued == false) {
              self.mutationsRunLoopQueued = true;
              window.serializedRunLoop.addToQueue(function () {
                self.mutationsRunLoopQueued = false
                var queue = self.mutationsQueue;
                self.mutationsQueue = [];
                self.processMutationQueue(queue);
              });
            }
          }


          // console.log("mutations: ", mutations);
        }); // mutation observer

        this.monitorNodeMutationsBegin();
      },


      monitorNodeMutationsBegin: function () {
        var rootNode = document;
        this.mutationsObserver.observe(rootNode, {
          childList: true,
          subtree: true,
          characterData: true
        });
      },

      monitorNodeMutationsStop: function () {
        this.mutationsObserver.disconnect();
      },

      processMutationQueue: function (queue) {
        // body is root node
        if (!document.body) {
          return;
        }

        // append SVG to body ASAP
        if (!this.SVGAppended) {
          this.appendSVGToDocument();
        }

        if (queue.length == 0) {
          return;
        }

        // stop monitoring mutations while we replace emojis
        // so we don't record what we emit
        this.monitorNodeMutationsStop();

        var rootNode = document.body;
        if (this.mutationsQueue.indexOf(rootNode) > -1) {
          if (location.href.indexOf('www.google.com') > -1) {
            //this.targetGoogleSearchNodes(rootNode);
          } else {
            this.replaceEmojisInNode(rootNode);
          }
        } else {
          var count = 0;
          // queue = this.topMostNodesFromQueue(queue);
          while (queue.length > 0) {
            var node = queue.pop();
            if (node) {
              if (location.href.indexOf('www.google.com') > -1) {
                this.targetGoogleSearchNodes(node);
              } else {
                this.replaceEmojisInNode(node);
              }
            }

            count += 1;
          }
          // console.log(count + " mutated nodes");
        }
        this.monitorNodeMutationsBegin();
      }, // processMutationQueue
// filters out child nodes when parent node is already in queue
      topMostNodesFromQueue: function (queue) {
        var isAncestorNode = function(node, possibleAncestor) {
          var currentNode = node;
          while (currentNode.parentNode) {
            if (currentNode.parentNode == possibleAncestor) {
              return true;
            }
            currentNode = currentNode.parentNode;
          }
          return false;
        }
        var oldestAncestorInQueue = function (node, queue) {
          var topMostNode = node;
          for (var key in queue) {
            var thisNode = queue[key];
            if (thisNode == topMostNode) {
              continue;
            }

            if (isAncestorNode(topMostNode, node)) {
              // console.log("node:", node, "is ancestor of: ", topMostNode);
              topMostNode = node;
            }
          }
          return topMostNode;
        }

        var topMostQueue = [];
        for (var key in queue) {
          var node = queue[key];
          var oldestAncestor = oldestAncestorInQueue(node, queue);
          if (topMostQueue.indexOf(oldestAncestor) == -1) {
            topMostQueue.push(oldestAncestor);
          }
        }
        /*console.log(
         "queue length:", queue.length,
         "topmost queue length:", topMostQueue.length);
         console.log("queue: ", queue);
         console.log("topmost: ", topMostQueue);*/
        return topMostQueue;
      }, // topMostNodesFromQueue

    }; // emojiOneReplacementEngine
/*
import keySynthesize from './keySynthesize'
import inputInsertion from './inputInsertion'
import messageHandler from './messageHandler'
import emojiReplacement from './emojiReplacement'
import emojiData from './emojiData'
*/

var textDebugging = true;
if (textDebugging) {
  textDebugging = function () {
      console.log.apply(console, arguments)
    }
}
else {
  textDebugging = function () {}
}

window.emojiOneReplacementEngine.init();

window.monoExtension.addListener(function (request, sender, sendResponse) {
        if (request && request.autoReplace) {
            if (request.autoReplace == 'off') {
                // disconnect()
            } else {
                // queue.push(document.getElementsByTagName("body")[0]);
            }
        }
        if (request && request.emoji) {
            insertTextAtCursor(request.emoji)
        }
    }
);
